package com.adpulse.system.asset.controller;

import com.adpulse.system.application.dto.ApplicationDefinitionView;
import com.adpulse.system.application.service.ApplicationDefinitionService;
import com.adpulse.system.asset.dto.AssetRequests;
import com.adpulse.system.asset.dto.AssetViews;
import com.adpulse.system.asset.model.ApprovalGroup;
import com.adpulse.system.asset.service.AssetApprovalCommentService;
import com.adpulse.system.asset.service.AssetApprovalPrincipalService;
import com.adpulse.system.asset.service.AssetService;
import com.adpulse.system.asset.service.DynamicFormReferenceService;
import com.adpulse.system.asset.service.SiteNotificationService;
import com.adpulse.system.common.api.ApiResponse;
import com.adpulse.system.common.exception.BusinessException;
import com.adpulse.system.common.security.CurrentUser;
import com.adpulse.system.common.security.SecurityContextHelper;
import com.adpulse.system.operationlog.audit.OperationAudit;
import com.adpulse.system.operationlog.audit.OperationType;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.Valid;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

/** Dynamic form, multi-node approval and in-app notification endpoints. */
@RestController
@RequestMapping("/asset-flow-v2")
public class DynamicAssetFlowController {
    private static final Set<String> INVENTORY_TYPES =
            Set.of(
                    "PERSONAL",
                    "BM",
                    "PIXEL",
                    "TG",
                    "PAGE",
                    "COMPUTER",
                    "MOBILE",
                    "STATIC_IP",
                    "EMAIL");
    private static final Set<String> CATEGORIES =
            Set.of("advertising", "office", "finance", "social");
    private static final Map<String, List<String>> LEGACY_ACCOUNT_FIELD_APPLICATIONS =
            Map.of(
                    "amount", List.of("ACCOUNT_RECHARGE", "ACCOUNT_DEDUCTION"),
                    "applyReason", List.of("ACCOUNT_ACTIVE_CLEAR", "ACCOUNT_ACTIVE_CLEAR_RECYCLE"),
                    "originalAuthAccount", List.of("ACCOUNT_REBIND"),
                    "authAccount", List.of("ACCOUNT_UNBIND", "ACCOUNT_REBIND"),
                    "remark",
                            List.of(
                                    "ACCOUNT_ACTIVE_CLEAR",
                                    "ACCOUNT_ACTIVE_CLEAR_RECYCLE",
                                    "ACCOUNT_RECYCLE"));
    private final JdbcTemplate jdbc;
    private final ObjectMapper json;
    private final AssetApprovalPrincipalService principalService;
    private final AssetApprovalCommentService commentService;
    private final AssetService assetService;
    private final DynamicFormReferenceService referenceService;
    private final SiteNotificationService notificationService;
    private final ApplicationDefinitionService applicationDefinitionService;

    public DynamicAssetFlowController(
            JdbcTemplate jdbc,
            ObjectMapper json,
            AssetApprovalPrincipalService principalService,
            AssetApprovalCommentService commentService,
            AssetService assetService,
            DynamicFormReferenceService referenceService,
            SiteNotificationService notificationService,
            ApplicationDefinitionService applicationDefinitionService) {
        this.jdbc = jdbc;
        this.json = json;
        this.principalService = principalService;
        this.commentService = commentService;
        this.assetService = assetService;
        this.referenceService = referenceService;
        this.notificationService = notificationService;
        this.applicationDefinitionService = applicationDefinitionService;
    }

    @GetMapping("/approval-configs")
    public ApiResponse<List<Map<String, Object>>> configs() {
        return ApiResponse.success(queryConfigs(false));
    }

    /** 返回审批管理页使用的完整配置，包括已停用和仅管理员可见的配置。 */
    @GetMapping("/approval-configs/manage")
    public ApiResponse<List<Map<String, Object>>> managedConfigs() {
        return ApiResponse.success(queryConfigs(true));
    }

    /** 返回审批管理页的全部分组，包括尚未包含审批配置的空分组。 */
    @GetMapping("/approval-groups/manage")
    public ApiResponse<List<AssetViews.ApprovalGroupView>> approvalGroups() {
        return ApiResponse.success(assetService.approvalGroups());
    }

    @PostMapping("/approval-groups")
    @OperationAudit(
            module = "ASSET",
            type = OperationType.CREATE,
            name = "新建审批分组",
            targetType = "media_approval_group")
    public ApiResponse<AssetViews.ApprovalGroupView> createApprovalGroup(
            @Valid @RequestBody AssetRequests.ApprovalGroupCreate request) {
        return ApiResponse.success(assetService.createApprovalGroup(request));
    }

    @PutMapping("/approval-groups/order")
    @OperationAudit(
            module = "ASSET",
            type = OperationType.UPDATE,
            name = "调整审批分组顺序",
            targetType = "media_approval_group")
    public ApiResponse<List<AssetViews.ApprovalGroupView>> reorderApprovalGroups(
            @Valid @RequestBody AssetRequests.ApprovalGroupOrder request) {
        return ApiResponse.success(assetService.reorderApprovalGroups(request));
    }

    @DeleteMapping("/approval-groups/{id}")
    @OperationAudit(
            module = "ASSET",
            type = OperationType.DELETE,
            name = "删除审批分组",
            targetType = "media_approval_group",
            targetIdParameter = "id")
    public ApiResponse<Void> deleteApprovalGroup(@PathVariable Long id) {
        assetService.deleteApprovalGroup(id);
        return ApiResponse.success();
    }

    @PutMapping("/approval-configs")
    @Transactional
    public ApiResponse<Map<String, Object>> saveConfig(@RequestBody Map<String, Object> body) {
        String type = configKey(required(body, "assetType"));
        String requestedCategory = required(body, "category");
        if (!CATEGORIES.contains(requestedCategory)) throw validation("不支持的申请分类");
        String name = required(body, "name");
        ApprovalGroup group = assetService.requireApprovalGroup(number(body.get("groupId")));
        List<Map<String, Object>> fields = list(body.get("formSchema"));
        List<Map<String, Object>> nodes = list(body.get("nodes"));
        validateTemplate(fields, nodes);
        Map<String, Object> settings = map(body.get("settings"));
        Map<String, Object> handlerAction = map(settings.get("handlerAction"));
        validateHandlerAction(handlerAction);
        long handlerId = number(body.get("handlerId"));
        String handlerName = required(body, "handlerName");
        if (handlerId <= 0 || !activeUser(handlerId)) throw validation("流程处理人不存在或已停用");
        nodes.forEach(
                node -> {
                    node.put("handlerId", handlerId);
                    node.put("handlerName", handlerName);
                    node.put("handlerAction", handlerAction);
                    node.remove("handlerIsApprover");
                });
        Map<String, Object> first = nodes.get(0);
        long operator = SecurityContextHelper.currentUserId();
        boolean enabled = !Boolean.FALSE.equals(body.get("enabled"));
        jdbc.update(
                """
            INSERT INTO media_approval_config
              (asset_type, category, approver_id, approver_name, cc_user_ids, flow_name, description,
               group_id, group_name, icon, visibility, settings, sort_order, form_schema, nodes, enabled,
               created_by, updated_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE approver_id=VALUES(approver_id), approver_name=VALUES(approver_name),
              cc_user_ids=VALUES(cc_user_ids), flow_name=VALUES(flow_name), form_schema=VALUES(form_schema),
              nodes=VALUES(nodes), category=VALUES(category), description=VALUES(description),
              group_id=VALUES(group_id), group_name=VALUES(group_name), icon=VALUES(icon), visibility=VALUES(visibility),
              settings=VALUES(settings), sort_order=VALUES(sort_order), enabled=VALUES(enabled),
              updated_by=VALUES(updated_by)
            """,
                type,
                requestedCategory,
                number(first.get("approverId")),
                required(first, "approverName"),
                Objects.toString(body.get("ccUserIds"), ""),
                name,
                Objects.toString(body.get("description"), ""),
                group.getId(),
                group.getName(),
                Objects.toString(body.get("icon"), "lucide:workflow"),
                "admins".equals(body.get("visibility")) ? "admins" : "all",
                stringify(settings),
                intValue(body.get("sortOrder"), 0),
                stringify(fields),
                stringify(nodes),
                enabled ? 1 : 0,
                operator,
                operator);
        Map<String, Object> savedConfig = findConfig(type);
        if (body.containsKey("applicationDefinitionIds")) {
            applicationDefinitionService.replaceApprovalConfigApplications(
                    number(savedConfig.get("id")),
                    applicationDefinitionIds(body.get("applicationDefinitionIds")));
            savedConfig = findConfig(type);
        }
        return ApiResponse.success(savedConfig);
    }

    @DeleteMapping("/approval-configs/{id}")
    @OperationAudit(
            module = "ASSET",
            type = OperationType.DELETE,
            name = "删除审批配置",
            targetType = "media_approval_config",
            targetIdParameter = "id")
    public ApiResponse<Void> deleteConfig(@PathVariable Long id) {
        assetService.deleteApprovalConfig(id);
        return ApiResponse.success();
    }

    @PostMapping("/applications")
    @Transactional
    public ApiResponse<Map<String, Object>> apply(@RequestBody Map<String, Object> body) {
        String type = configKey(required(body, "assetType"));
        Map<String, Object> config = findConfig(type);
        if (!Boolean.TRUE.equals(config.get("enabled"))) throw conflict("该流程已停用");
        Map<String, Object> data = map(body.get("formData"));
        long definitionId = number(data.get("applicationDefinitionId"));
        if (definitionId <= 0) throw validation("请从申请中心选择具体申请");
        ApplicationDefinitionView definition =
                applicationDefinitionService.requireEnabledForSubmission(
                        definitionId, number(config.get("id")));
        data.put("applicationDefinitionId", definition.id());
        data.put("applicationCode", definition.applicationCode());
        data.put("applicationName", definition.applicationName());
        List<Map<String, Object>> completeFormSchema = list(config.get("formSchema"));
        List<Map<String, Object>> formSchema =
                applicableFormSchema(completeFormSchema, definition.applicationCode());
        removeInapplicableValues(completeFormSchema, formSchema, data);
        populateControlledAutoFill(formSchema, data);
        normalizeFormData(formSchema, data);
        validateForm(formSchema, data);
        referenceService.enrichSystemOptionSnapshots(formSchema, data);
        if (data.get("channelId") != null && !data.get("channelId").toString().isBlank()) {
            String channelId = data.get("channelId").toString();
            String channelName = Objects.toString(data.get("channelName"), "");
            data.put("channelId", channelId);
            data.put("channelName", channelName);
            // 旧字段暂时保留为渠道镜像，兼容存量审批记录与前端读模型。
            data.put("projectId", channelId);
            data.put("projectName", channelName);
        }
        data.put("_ccUserIds", Objects.toString(config.get("ccUserIds"), ""));
        List<Map<String, Object>> nodes = list(config.get("nodes"));
        nodes.forEach(principalService::normalizeAndResolve);
        String approvalType =
                Objects.toString(map(config.get("settings")).get("approvalType"), "manual");
        CurrentUser user = SecurityContextHelper.currentUser();
        String no =
                "AST"
                        + LocalDateTime.now()
                                .format(DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS"));
        long operator = user.userId();
        jdbc.update(
                """
            INSERT INTO media_asset_application
              (application_no, asset_type, title, quantity, reason, status, requester_id,
               requester_name, approver_id, approver_name, form_data, form_schema_snapshot,
               nodes_snapshot, current_node_index, created_by, updated_by)
            VALUES (?, ?, ?, ?, ?, 'PENDING', ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
            """,
                no,
                type,
                definition.applicationName(),
                intValue(data.get("quantity"), 1),
                Objects.toString(
                        data.get("purpose"), Objects.toString(data.get("description"), "")),
                user.userId(),
                user.displayName(),
                number(nodes.get(0).get("approverId")),
                required(nodes.get(0), "approverName"),
                stringify(data),
                stringify(formSchema),
                stringify(nodes),
                operator,
                operator);
        Long id = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Long.class);
        jdbc.update(
                """
            INSERT INTO media_asset_approval_log
              (application_id, action, actor_id, actor_name, remark, node_index, node_name)
            VALUES (?, 'SUBMITTED', ?, ?, ?, -1, '发起申请')
            """,
                id,
                user.userId(),
                user.displayName(),
                Objects.toString(data.get("purpose"), ""));
        if ("auto-reject".equals(approvalType)) {
            jdbc.update(
                    """
                UPDATE media_asset_application
                   SET status='REJECTED', decision_remark='系统按审批配置自动驳回', decided_at=NOW(),
                       updated_by=?
                 WHERE id=? AND status='PENDING'
                """,
                    operator,
                    id);
            jdbc.update(
                    """
                INSERT INTO media_asset_approval_log
                  (application_id, action, actor_id, actor_name, remark, node_index, node_name)
                VALUES (?, 'REJECTED', ?, '系统自动审批', '系统按审批配置自动驳回', 0, '自动驳回')
                """,
                    id,
                    operator);
        } else if ("auto-approve".equals(approvalType)) {
            Map<String, Object> handler = workflowHandler(nodes);
            jdbc.update(
                    """
                UPDATE media_asset_application
                   SET status='PROCESSING', approver_id=?, approver_name=?, updated_by=?
                 WHERE id=? AND status='PENDING'
                """,
                    number(handler.get("handlerId")),
                    required(handler, "handlerName"),
                    operator,
                    id);
            jdbc.update(
                    """
                INSERT INTO media_asset_approval_log
                  (application_id, action, actor_id, actor_name, remark, node_index, node_name)
                VALUES (?, 'APPROVED', ?, '系统自动审批', '系统按审批配置自动通过', 0, '自动通过')
                """,
                    id,
                    operator);
            notifyUser(
                    number(handler.get("handlerId")),
                    "待处理申请",
                    body.get("title") + " 已自动通过审批，请进行业务处理",
                    "/workbench/approvals?id=" + id,
                    "PROCESSING",
                    id);
        } else {
            notifyNode(nodes.get(0), id, required(body, "title"));
        }
        return ApiResponse.success(findApplication(id));
    }

    @GetMapping("/applications/mine")
    public ApiResponse<List<Map<String, Object>>> myApplications() {
        return ApiResponse.success(
                queryApplications("requester_id=?", SecurityContextHelper.currentUserId()));
    }

    /** 返回当前流程参与人可见的最新申请详情与完整审批轨迹。 */
    @GetMapping("/applications/{id}")
    public ApiResponse<Map<String, Object>> application(@PathVariable Long id) {
        commentService.requireParticipant(id);
        return ApiResponse.success(findApplication(id));
    }

    /** 查询当前流程参与人可见的评论。 */
    @GetMapping("/applications/{id}/comments")
    public ApiResponse<List<AssetViews.ApprovalCommentView>> comments(@PathVariable Long id) {
        return ApiResponse.success(commentService.comments(id));
    }

    /** 以当前用户在流程中的真实身份发布评论。 */
    @PostMapping("/applications/{id}/comments")
    public ApiResponse<AssetViews.ApprovalCommentView> comment(
            @PathVariable Long id,
            @Valid @RequestBody AssetRequests.ApprovalCommentCreate request) {
        return ApiResponse.success(commentService.comment(id, request));
    }

    @GetMapping("/approvals")
    public ApiResponse<List<Map<String, Object>>> approvals() {
        long userId = SecurityContextHelper.currentUserId();
        return ApiResponse.success(
                queryApplications("status IN ('PENDING','PROCESSING')").stream()
                        .filter(
                                item -> {
                                    if ("PROCESSING".equals(item.get("status"))) {
                                        return userId == number(item.get("handlerId"));
                                    }
                                    List<Map<String, Object>> nodes = list(item.get("nodes"));
                                    int index = intValue(item.get("currentNodeIndex"), 0);
                                    if (index >= nodes.size()) return false;
                                    Map<String, Object> node = nodes.get(index);
                                    return principalService.canApprove(node, userId);
                                })
                        .toList());
    }

    @PostMapping("/approvals/{id}/approve")
    @Transactional
    public ApiResponse<Map<String, Object>> approve(
            @PathVariable Long id, @RequestBody(required = false) Map<String, Object> body) {
        Map<String, Object> request = body == null ? Map.of() : body;
        return decide(id, true, Objects.toString(request.get("remark"), ""));
    }

    @PostMapping("/approvals/{id}/reject")
    @Transactional
    public ApiResponse<Map<String, Object>> reject(
            @PathVariable Long id, @RequestBody Map<String, Object> body) {
        return decide(id, false, required(body, "remark"));
    }

    @PostMapping("/approvals/{id}/complete")
    @Transactional
    public ApiResponse<Map<String, Object>> complete(
            @PathVariable Long id, @RequestBody Map<String, Object> body) {
        return completeProcessing(
                id,
                required(body, "remark"),
                longList(body.get("assetIds")),
                map(body.get("actionData")));
    }

    /** 返回当前用户是否存在未读通知，用于顶部导航红点。 */
    @GetMapping("/notifications/unread-status")
    public ApiResponse<AssetViews.NotificationUnreadStatus> notificationUnreadStatus() {
        return ApiResponse.success(notificationService.unreadStatus());
    }

    /** 分页返回当前用户的站内通知。 */
    @GetMapping("/notifications")
    public ApiResponse<AssetViews.NotificationPage> notifications(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "20") int pageSize) {
        return ApiResponse.success(notificationService.notifications(page, pageSize));
    }

    @PutMapping("/notifications/{id}/read")
    public ApiResponse<Void> read(@PathVariable Long id) {
        notificationService.markRead(id);
        return ApiResponse.success();
    }

    @PutMapping("/notifications/read-all")
    public ApiResponse<Void> readAll() {
        notificationService.markAllRead();
        return ApiResponse.success();
    }

    private ApiResponse<Map<String, Object>> decide(Long id, boolean approved, String remark) {
        List<Map<String, Object>> lock =
                jdbc.queryForList(
                        "SELECT id FROM media_asset_application WHERE id=? AND deleted_at=0 FOR UPDATE",
                        id);
        if (lock.isEmpty()) throw notFound("申请单");
        Map<String, Object> application = findApplication(id);
        if (!"PENDING".equals(application.get("status"))) throw conflict("申请已处理");
        List<Map<String, Object>> nodes = list(application.get("nodes"));
        int index = intValue(application.get("currentNodeIndex"), 0);
        Map<String, Object> node = nodes.get(index);
        long userId = SecurityContextHelper.currentUserId();
        principalService.requireCanApprove(node, userId);
        CurrentUser actor = SecurityContextHelper.currentUser();
        jdbc.update(
                """
            INSERT INTO media_asset_approval_log
              (application_id, action, actor_id, actor_name, remark, node_index, node_name)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
                id,
                approved ? "APPROVED" : "REJECTED",
                actor.userId(),
                actor.displayName(),
                remark,
                index,
                Objects.toString(node.get("name"), "审批节点"));
        if (!approved) {
            jdbc.update(
                    """
                UPDATE media_asset_application SET status='REJECTED', decision_remark=?, decided_at=NOW(),
                  updated_by=? WHERE id=? AND status='PENDING'
                """,
                    remark,
                    userId,
                    id);
            notifyUser(
                    number(application.get("requesterId")),
                    "申请已驳回",
                    application.get("title") + "：" + remark,
                    "/workbench/applications?id=" + id,
                    "APPLICATION",
                    id);
        } else if (index + 1 < nodes.size()) {
            Map<String, Object> next = nodes.get(index + 1);
            principalService.normalizeAndResolve(next);
            jdbc.update(
                    """
                UPDATE media_asset_application SET current_node_index=?, approver_id=?, approver_name=?,
                  updated_by=? WHERE id=? AND status='PENDING'
                """,
                    index + 1,
                    number(next.get("approverId")),
                    required(next, "approverName"),
                    userId,
                    id);
            notifyNode(next, id, Objects.toString(application.get("title"), ""));
        } else {
            Map<String, Object> handler = workflowHandler(nodes);
            jdbc.update(
                    """
                UPDATE media_asset_application SET status='PROCESSING', approver_id=?, approver_name=?,
                  updated_by=? WHERE id=? AND status='PENDING'
                """,
                    number(handler.get("handlerId")),
                    required(handler, "handlerName"),
                    userId,
                    id);
            notifyUser(
                    number(handler.get("handlerId")),
                    "待处理申请",
                    application.get("title") + " 已完成全部审批，请按办理节点配置完成业务操作",
                    "/workbench/approvals?id=" + id,
                    "PROCESSING",
                    id);
        }
        return ApiResponse.success(findApplication(id));
    }

    private ApiResponse<Map<String, Object>> completeProcessing(
            Long id, String remark, List<Long> selectedAssetIds, Map<String, Object> actionData) {
        List<Map<String, Object>> lock =
                jdbc.queryForList(
                        "SELECT id FROM media_asset_application WHERE id=? AND deleted_at=0 FOR UPDATE",
                        id);
        if (lock.isEmpty()) throw notFound("申请单");
        Map<String, Object> application = findApplication(id);
        if (!"PROCESSING".equals(application.get("status"))) throw conflict("申请不在待处理阶段");
        long userId = SecurityContextHelper.currentUserId();
        if (userId != number(application.get("handlerId"))) throw conflict("您不是该流程的处理人");
        validateHandlerActionData(application, actionData, userId);
        List<Map<String, Object>> allocatedAssetSnapshots =
                allocateAssets(application, selectedAssetIds, userId);
        Map<String, Object> persistedActionData = new LinkedHashMap<>(actionData);
        if (!allocatedAssetSnapshots.isEmpty()) {
            // 办理记录保留非敏感分配快照，资产后续回收解绑后仍可审计原办理结果。
            persistedActionData.put("_allocatedAssets", allocatedAssetSnapshots);
        }
        CurrentUser actor = SecurityContextHelper.currentUser();
        jdbc.update(
                """
            INSERT INTO media_asset_approval_log
              (application_id, action, actor_id, actor_name, remark, action_data, node_index, node_name)
            VALUES (?, 'COMPLETED', ?, ?, ?, ?, ?, '业务办理')
            """,
                id,
                actor.userId(),
                actor.displayName(),
                remark,
                stringify(persistedActionData),
                list(application.get("nodes")).size());
        jdbc.update(
                """
            UPDATE media_asset_application SET status='APPROVED', decision_remark=?, decided_at=NOW(),
              updated_by=? WHERE id=? AND status='PROCESSING'
            """,
                remark,
                userId,
                id);
        notifyCompletion(application, id);
        return ApiResponse.success(findApplication(id));
    }

    private List<Map<String, Object>> allocateAssets(
            Map<String, Object> application, List<Long> selectedAssetIds, long operatorId) {
        String applicationType = Objects.toString(application.get("assetType"), "");
        Map<String, Object> handlerAction = map(application.get("handlerAction"));
        Map<String, Object> assignment = map(handlerAction.get("resourceAssignment"));
        // 兼容配置改造前已发起的存量申请；新申请完全由办理节点快照控制。
        boolean legacyInventoryFlow =
                handlerAction.isEmpty() && INVENTORY_TYPES.contains(applicationType);
        if (!Boolean.TRUE.equals(assignment.get("enabled")) && !legacyInventoryFlow) {
            if (!selectedAssetIds.isEmpty()) throw validation("当前办理节点未配置资源分配");
            return List.of();
        }
        Map<String, Object> applicationData = map(application.get("formData"));
        AssetService.InventorySelection inventorySelection =
                assetService.resolveInventorySelection(
                        applicationType, applicationData, assignment);
        String quantityFieldKey =
                Objects.toString(assignment.get("quantityFieldKey"), "quantity").trim();
        int quantity = intValue(applicationData.get(quantityFieldKey), 1);
        if (selectedAssetIds.size() != quantity) {
            throw validation("请选择" + quantity + "个可用资产后再完成处理");
        }
        long assigneeId = number(applicationData.get("resourceAssigneeId"));
        String assigneeName =
                Objects.toString(applicationData.get("resourceAssigneeName"), "").trim();
        if (assigneeId <= 0 || assigneeName.isBlank()) {
            assigneeId = number(application.get("requesterId"));
            assigneeName = Objects.toString(application.get("requesterName"), "");
        }
        String placeholders = String.join(",", Collections.nCopies(selectedAssetIds.size(), "?"));
        List<Map<String, Object>> selectedAssets =
                jdbc.queryForList(
                        """
            SELECT id, asset_type assetType, asset_name assetName, asset_code assetCode,
                   channel_id channelId, channel_name channelName,
                   project_id projectId, project_name projectName, secret_data secretData, status
              FROM media_asset
             WHERE id IN (%s) AND deleted_at=0 FOR UPDATE
            """
                                .formatted(placeholders),
                        selectedAssetIds.toArray());
        if (selectedAssets.size() != selectedAssetIds.size()) {
            throw conflict("所选资产不存在或已删除，请刷新后重新选择");
        }
        if (selectedAssets.stream()
                .anyMatch(
                        asset ->
                                !inventorySelection
                                        .assetType()
                                        .equals(Objects.toString(asset.get("assetType"), "")))) {
            throw conflict("所选资产类型与申请类型不一致");
        }
        if (!inventorySelection.subtype().isBlank()
                && selectedAssets.stream()
                        .anyMatch(
                                asset ->
                                        !assetService.matchesInventorySubtype(
                                                Objects.toString(asset.get("secretData"), null),
                                                inventorySelection.subtype()))) {
            throw conflict("所选资产与申请的社交资产类型不一致");
        }
        String channelFieldKey =
                Objects.toString(assignment.get("channelFieldKey"), "channelId").trim();
        String expectedChannelId =
                channelFieldKey.isBlank()
                        ? ""
                        : Objects.toString(applicationData.get(channelFieldKey), "").trim();
        if (!expectedChannelId.isBlank()
                && selectedAssets.stream()
                        .anyMatch(
                                asset ->
                                        !expectedChannelId.equals(
                                                Objects.toString(asset.get("channelId"), "")))) {
            throw conflict("所选资产不属于申请渠道，请刷新后重新选择");
        }
        if (selectedAssets.stream()
                .anyMatch(
                        asset -> !"AVAILABLE".equals(Objects.toString(asset.get("status"), "")))) {
            throw conflict("所选资产已被分配，请刷新后重新选择");
        }
        for (Long assetId : selectedAssetIds) {
            int updated =
                    jdbc.update(
                            """
                UPDATE media_asset SET status='ASSIGNED', application_id=?, assignee_id=?, assignee_name=?,
                  updated_by=? WHERE id=? AND status='AVAILABLE' AND deleted_at=0
                """,
                            application.get("id"),
                            assigneeId,
                            assigneeName,
                            operatorId,
                            assetId);
            if (updated != 1) throw conflict("所选资产状态已变化，请刷新后重新选择");
        }
        return selectedAssets.stream()
                .map(
                        asset -> {
                            Map<String, Object> snapshot = new LinkedHashMap<>();
                            snapshot.put("id", number(asset.get("id")));
                            snapshot.put("assetType", asset.get("assetType"));
                            snapshot.put("assetName", asset.get("assetName"));
                            snapshot.put("assetCode", asset.get("assetCode"));
                            snapshot.put("channelName", asset.get("channelName"));
                            snapshot.put("projectName", asset.get("projectName"));
                            return snapshot;
                        })
                .toList();
    }

    private void notifyCompletion(Map<String, Object> application, Long id) {
        notifyUser(
                number(application.get("requesterId")),
                "申请已完成",
                application.get("title") + " 已完成处理与分配",
                "/workbench/applications?id=" + id,
                "APPLICATION",
                id);
        for (String cc :
                Objects.toString(map(application.get("formData")).get("_ccUserIds"), "")
                        .split(",")) {
            long ccId = number(cc.trim());
            if (ccId > 0)
                notifyUser(
                        ccId,
                        "审批抄送",
                        application.get("title") + " 已完成处理与分配",
                        "/workbench/applications?id=" + id,
                        "CC",
                        id);
        }
    }

    private Map<String, Object> findConfig(String type) {
        List<Map<String, Object>> rows =
                jdbc.queryForList(
                        """
            SELECT id, asset_type assetType, category, flow_name name, description,
                   group_id groupId, group_name groupName, icon, visibility, settings, sort_order sortOrder,
                   form_schema formSchema, nodes, cc_user_ids ccUserIds, enabled, updated_at updatedAt
              FROM media_approval_config
             WHERE asset_type=? AND deleted_at=0
            """,
                        type);
        if (rows.isEmpty()) throw conflict("该审批配置不存在或已删除");
        return decodeConfig(rows.get(0));
    }

    private Map<String, Object> findApplication(Long id) {
        List<Map<String, Object>> rows = queryApplications("id=?", id);
        if (rows.isEmpty()) throw notFound("申请单");
        return rows.get(0);
    }

    private List<Map<String, Object>> queryApplications(String where, Object... args) {
        return jdbc
                .queryForList(
                        """
            SELECT id, application_no applicationNo, asset_type assetType, title, quantity, reason,
                   status, requester_id requesterId, requester_name requesterName, approver_id approverId,
                   approver_name approverName, decision_remark decisionRemark, form_data formData,
                   form_schema_snapshot formSchema, nodes_snapshot nodes,
                   current_node_index currentNodeIndex, created_at createdAt, updated_at updatedAt
              FROM media_asset_application WHERE deleted_at=0 AND
            """
                                + where
                                + " ORDER BY id DESC",
                        args)
                .stream()
                .map(this::decodeApplication)
                .toList();
    }

    /** 查询审批配置；管理视图保留停用项，申请视图只返回当前用户可发起的已启用项。 */
    private List<Map<String, Object>> queryConfigs(boolean managementView) {
        long userId = SecurityContextHelper.currentUserId();
        String visibilityClause =
                managementView
                        ? ""
                        : """
                           AND c.enabled=1
                           AND (c.visibility='all' OR EXISTS (
                               SELECT 1
                                 FROM sys_user_role ur
                                 JOIN sys_role r ON r.id=ur.role_id AND r.deleted_at=0 AND r.status=1
                                WHERE ur.user_id=? AND ur.deleted_at=0
                                  AND UPPER(r.role_code) IN ('ADMIN','SUPER_ADMIN','SYSTEM_ADMIN')
                           ))
                           """;
        List<Object> args = new ArrayList<>();
        args.add(userId);
        if (!managementView) args.add(userId);
        return jdbc
                .queryForList(
                        """
             SELECT c.id, c.asset_type assetType, c.category, c.flow_name name, c.description,
                    c.group_id groupId, c.group_name groupName, c.icon, c.visibility, c.settings, c.sort_order sortOrder,
                    c.form_schema formSchema, c.nodes, c.cc_user_ids ccUserIds, c.enabled,
                    c.updated_at updatedAt,
                    (SELECT GROUP_CONCAT(d.id ORDER BY d.sort_order, d.id)
                       FROM media_application_definition d
                      WHERE d.approval_config_id=c.id AND d.deleted_at=0) applicationDefinitionIds,
                    (SELECT COUNT(*) FROM media_asset_application a
                      WHERE a.asset_type=c.asset_type AND a.requester_id=? AND a.deleted_at=0) usageCount
               FROM media_approval_config c
              WHERE c.deleted_at=0
             """
                                + visibilityClause
                                + " ORDER BY c.sort_order, c.id",
                        args.toArray())
                .stream()
                .map(this::decodeConfig)
                .toList();
    }

    private Map<String, Object> decodeConfig(Map<String, Object> row) {
        row.put("formSchema", parse(row.get("formSchema"), List.of()));
        row.put("nodes", parse(row.get("nodes"), List.of()));
        row.put("settings", parse(row.get("settings"), Map.of()));
        Map<String, Object> handler = workflowHandler(list(row.get("nodes")));
        row.put("handlerId", number(handler.get("handlerId")));
        row.put("handlerName", Objects.toString(handler.get("handlerName"), ""));
        row.put("enabled", intValue(row.get("enabled"), 0) == 1);
        String storedCategory = Objects.toString(row.get("category"), "");
        row.put("category", CATEGORIES.contains(storedCategory) ? storedCategory : "advertising");
        row.put("usageCount", number(row.get("usageCount")));
        row.put("groupId", Objects.toString(row.get("groupId"), ""));
        row.put("sortOrder", intValue(row.get("sortOrder"), 0));
        String definitionIds = Objects.toString(row.get("applicationDefinitionIds"), "");
        row.put(
                "applicationDefinitionIds",
                definitionIds.isBlank() ? List.of() : Arrays.asList(definitionIds.split(",")));
        row.put("status", "published");
        return row;
    }

    private Map<String, Object> decodeApplication(Map<String, Object> row) {
        row.put("formData", parse(row.get("formData"), Map.of()));
        row.put("formSchema", parse(row.get("formSchema"), List.of()));
        row.put("nodes", parse(row.get("nodes"), List.of()));
        Map<String, Object> handler = workflowHandler(list(row.get("nodes")));
        row.put("handlerId", number(handler.get("handlerId")));
        row.put("handlerName", Objects.toString(handler.get("handlerName"), ""));
        row.put("handlerAction", map(handler.get("handlerAction")));
        row.put("approvalLogs", approvalLogs(number(row.get("id"))));
        row.put("allocatedAssets", allocatedAssets(number(row.get("id"))));
        return row;
    }

    /** 返回按发生顺序排列的完整审批轨迹，供申请详情、审计和看板复用。 */
    private List<Map<String, Object>> approvalLogs(long applicationId) {
        return jdbc
                .queryForList(
                        """
            SELECT id, action, actor_id actorId, actor_name actorName, remark, action_data actionData,
                   node_index nodeIndex, node_name nodeName, created_at createdAt
              FROM media_asset_approval_log
             WHERE application_id=? ORDER BY id
            """,
                        applicationId)
                .stream()
                .peek(log -> log.put("actionData", parse(log.get("actionData"), Map.of())))
                .toList();
    }

    /** 返回办理阶段实际分配的非敏感资产摘要，供申请详情回显。 */
    private List<Map<String, Object>> allocatedAssets(long applicationId) {
        return jdbc.queryForList(
                """
            SELECT id, asset_type assetType, asset_name assetName, asset_code assetCode,
                   channel_name channelName, project_name projectName
              FROM media_asset
             WHERE application_id=? AND deleted_at=0
             ORDER BY id
            """,
                applicationId);
    }

    private Map<String, Object> workflowHandler(List<Map<String, Object>> nodes) {
        if (nodes.isEmpty()) return Map.of("handlerId", 0L, "handlerName", "");
        Map<String, Object> last = nodes.get(nodes.size() - 1);
        long handlerId = number(last.get("handlerId"));
        String handlerName = Objects.toString(last.get("handlerName"), "");
        if (handlerId <= 0) {
            handlerId = number(last.get("approverId"));
            handlerName = Objects.toString(last.get("approverName"), "");
        }
        Map<String, Object> handler = new LinkedHashMap<>();
        handler.put("handlerId", handlerId);
        handler.put("handlerName", handlerName);
        handler.put("handlerAction", map(last.get("handlerAction")));
        return handler;
    }

    private void notifyNode(Map<String, Object> node, Long id, String title) {
        principalService
                .normalizeAndResolve(node)
                .eligibleUserIds()
                .forEach(
                        userId ->
                                notifyUser(
                                        userId,
                                        "待审批申请",
                                        title + " 已到达「" + node.get("name") + "」",
                                        "/workbench/approvals?id=" + id,
                                        "APPROVAL",
                                        id));
    }

    private void notifyUser(
            long userId, String title, String content, String path, String type, Long businessId) {
        if (userId <= 0) return;
        jdbc.update(
                """
            INSERT INTO system_notification
              (user_id, title, content, target_path, business_type, business_id)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
                userId,
                title,
                content,
                path,
                type,
                businessId);
    }

    /** 申请表中的接口回填只允许受控数据源，并在服务端重新计算，避免篡改只读值。 */
    private void populateControlledAutoFill(
            List<Map<String, Object>> fields, Map<String, Object> data) {
        Map<Long, Map<String, Object>> paymentContexts = new HashMap<>();
        for (Map<String, Object> field : fields) {
            Map<String, Object> autoFill = map(field.get("autoFill"));
            if (autoFill.isEmpty()) continue;
            if (!"channel-payment-context".equals(autoFill.get("source"))) {
                throw validation("不支持的接口联动数据源");
            }
            long channelId = number(data.get(required(autoFill, "triggerFieldKey")));
            if (channelId <= 0) continue;
            Map<String, Object> context =
                    paymentContexts.computeIfAbsent(channelId, this::loadChannelPaymentContext);
            String resultKey = required(autoFill, "resultKey");
            if (!Set.of("channelYesterdayCost", "paymentAddress").contains(resultKey)) {
                throw validation("不支持的接口回填结果");
            }
            data.put(required(field, "key"), context.get(resultKey));
        }
    }

    private Map<String, Object> loadChannelPaymentContext(long channelId) {
        List<Map<String, Object>> channels =
                jdbc.queryForList(
                        """
            SELECT payment_address paymentAddress
              FROM media_channel
             WHERE id=? AND status=1 AND deleted_at=0
            """,
                        channelId);
        if (channels.isEmpty()) throw validation("所选渠道不存在或已停用");
        Map<String, Object> context = new LinkedHashMap<>(channels.get(0));
        Object spend =
                jdbc.queryForObject(
                        """
            SELECT COALESCE(SUM(s.spend_amount), 0)
              FROM media_channel_campaign_spend s
              JOIN media_channel_account a
                ON a.account_id=s.account_id AND a.deleted_at=0
             WHERE a.channel_id=? AND s.spend_date=DATE_SUB(CURDATE(), INTERVAL 1 DAY)
               AND s.deleted_at=0
            """,
                        Object.class,
                        channelId);
        context.put("channelYesterdayCost", spend);
        return context;
    }

    private void validateHandlerAction(Map<String, Object> handlerAction) {
        if (handlerAction.isEmpty()) return;
        Map<String, Object> assignment = map(handlerAction.get("resourceAssignment"));
        if (Boolean.TRUE.equals(assignment.get("enabled"))) {
            if (!"application".equals(assignment.get("assetTypeSource"))) {
                throw validation("资源分配类型必须跟随申请类型");
            }
            validateFieldKey(
                    Objects.toString(assignment.get("quantityFieldKey"), "quantity"), "数量字段");
            String assetTypeKey = Objects.toString(assignment.get("assetTypeFieldKey"), "");
            if (!assetTypeKey.isBlank()) validateFieldKey(assetTypeKey, "实际资产类型字段");
            String channelKey = Objects.toString(assignment.get("channelFieldKey"), "");
            if (!channelKey.isBlank()) validateFieldKey(channelKey, "渠道字段");
        }
        List<Map<String, Object>> fields = list(handlerAction.get("formSchema"));
        Set<String> keys = new HashSet<>();
        for (Map<String, Object> field : fields) {
            String key = required(field, "key");
            validateFieldKey(key, "办理字段");
            if (!keys.add(key)) throw validation("办理表单字段标识不能重复：" + key);
            required(field, "label");
            String type = required(field, "type");
            if (!Set.of("image-upload", "number", "text", "textarea").contains(type)) {
                throw validation("不支持的办理控件类型：" + type);
            }
            long maxLength = number(field.get("maxLength"));
            if (maxLength < 0 || maxLength > 10000) {
                throw validation(field.get("label") + "的最大长度必须在 1 到 10000 之间");
            }
            if (field.get("minValue") != null
                    && field.get("maxValue") != null
                    && decimal(field.get("minValue")) > decimal(field.get("maxValue"))) {
                throw validation(field.get("label") + "的最小值不能大于最大值");
            }
            if ("image-upload".equals(type)) {
                int maxCount = intValue(field.get("maxCount"), 1);
                int maxFileSizeMb = intValue(field.get("maxFileSizeMb"), 3);
                if (maxCount < 1 || maxCount > 9) throw validation("图片数量必须在 1 到 9 之间");
                if (maxFileSizeMb < 1 || maxFileSizeMb > 20) {
                    throw validation("单张图片大小必须在 1MB 到 20MB 之间");
                }
                if (!Objects.toString(field.get("accept"), "image/*").startsWith("image/")) {
                    throw validation("图片上传控件只允许配置图片类型");
                }
            }
        }
    }

    private void validateFieldKey(String key, String label) {
        if (!key.matches("^[A-Za-z][A-Za-z0-9_]{0,39}$")) {
            throw validation(label + "标识仅支持字母、数字和下划线，且必须以字母开头");
        }
    }

    private void validateHandlerActionData(
            Map<String, Object> application, Map<String, Object> actionData, long userId) {
        Map<String, Object> handlerAction = map(application.get("handlerAction"));
        List<Map<String, Object>> fields = list(handlerAction.get("formSchema"));
        Set<String> allowedKeys =
                fields.stream()
                        .map(field -> Objects.toString(field.get("key"), ""))
                        .collect(java.util.stream.Collectors.toSet());
        actionData.keySet().removeIf(key -> !allowedKeys.contains(key));
        validateForm(fields, actionData);
        for (Map<String, Object> field : fields) {
            if (!"image-upload".equals(field.get("type"))) continue;
            List<Long> fileIds = fileIdList(actionData.get(required(field, "key")));
            int maxCount = intValue(field.get("maxCount"), 1);
            if (fileIds.size() > maxCount) {
                throw validation(field.get("label") + "最多上传" + maxCount + "张图片");
            }
            if (fileIds.isEmpty()) continue;
            String placeholders = String.join(",", Collections.nCopies(fileIds.size(), "?"));
            List<Object> args = new ArrayList<>(fileIds);
            args.add(userId);
            Map<String, Object> fileSummary =
                    jdbc.queryForMap(
                            """
                SELECT COUNT(*) fileCount, COALESCE(MAX(o.file_size), 0) maxFileSize
                  FROM sys_file f
                  JOIN sys_file_object o ON o.id=f.file_object_id AND o.deleted_at=0
                 WHERE f.id IN (%s) AND f.uploader_id=? AND f.deleted_at=0
                   AND o.storage_status='AVAILABLE' AND o.mime_type LIKE 'image/%%'
                """
                                    .formatted(placeholders),
                            args.toArray());
            if (number(fileSummary.get("fileCount")) != fileIds.size()) {
                throw validation(field.get("label") + "包含无效图片，请重新上传");
            }
            long maxBytes = intValue(field.get("maxFileSizeMb"), 3) * 1024L * 1024L;
            if (number(fileSummary.get("maxFileSize")) > maxBytes) {
                throw validation(
                        field.get("label")
                                + "单张不能超过"
                                + intValue(field.get("maxFileSizeMb"), 3)
                                + "MB");
            }
        }
    }

    private List<Long> fileIdList(Object value) {
        if (!(value instanceof List<?> values)) return List.of();
        LinkedHashSet<Long> ids = new LinkedHashSet<>();
        for (Object item : values) {
            long id = number(item);
            if (id <= 0 || !ids.add(id)) throw validation("上传文件标识不合法");
        }
        return new ArrayList<>(ids);
    }

    private void validateTemplate(
            List<Map<String, Object>> fields, List<Map<String, Object>> nodes) {
        if (fields.isEmpty()) throw validation("动态表单至少需要一个字段");
        if (nodes.isEmpty()) throw validation("审批流至少需要一个审批节点");
        Set<String> keys = new HashSet<>();
        int inputFieldCount = 0;
        for (Map<String, Object> field : fields) {
            String key = required(field, "key");
            if (!key.matches("^[A-Za-z][A-Za-z0-9_]{0,39}$")) {
                throw validation("表单字段标识仅支持字母、数字和下划线，且必须以字母开头");
            }
            required(field, "label");
            String type = required(field, "type");
            if (!Set.of("date", "multi-select", "number", "section", "select", "text", "textarea")
                    .contains(type)) throw validation("不支持的表单控件类型：" + type);
            if (!keys.add(key)) throw validation("表单字段标识不能重复：" + key);
            if ("section".equals(type)) continue;
            inputFieldCount++;
            String source = Objects.toString(field.get("optionSource"), "custom");
            if (("select".equals(type) || "multi-select".equals(type))
                    && !Set.of(
                                    "custom",
                                    "departments",
                                    "users",
                                    "projects",
                                    "roles",
                                    "channels",
                                    "ad-accounts")
                            .contains(source)) {
                throw validation("不支持的下拉选项来源：" + source);
            }
            if (("select".equals(type) || "multi-select".equals(type))
                    && "custom".equals(source)
                    && stringList(field.get("options")).isEmpty()) {
                throw validation(field.get("label") + "至少需要一个自定义选项");
            }
            long maxLength = number(field.get("maxLength"));
            if (maxLength < 0 || maxLength > 10000) {
                throw validation(field.get("label") + "的最大长度必须在 1 到 10000 之间");
            }
        }
        if (inputFieldCount == 0) throw validation("动态表单至少需要一个可填写字段");
        for (Map<String, Object> field : fields) {
            if ("section".equals(field.get("type"))) continue;
            validateFieldCondition(field.get("visibleWhen"), keys, field.get("label"));
            validateFieldCondition(field.get("requiredWhen"), keys, field.get("label"));
            Map<String, Object> autoFill = map(field.get("autoFill"));
            if (!autoFill.isEmpty()) {
                if (!"channel-payment-context".equals(autoFill.get("source"))) {
                    throw validation("不支持的接口联动数据源");
                }
                String triggerFieldKey = required(autoFill, "triggerFieldKey");
                if (!keys.contains(triggerFieldKey)) throw validation("接口联动触发字段不存在");
                if (!Set.of("channelYesterdayCost", "paymentAddress")
                        .contains(required(autoFill, "resultKey"))) {
                    throw validation("不支持的接口回填结果");
                }
            }
        }
        for (Map<String, Object> node : nodes) {
            required(node, "name");
            principalService.normalizeAndResolve(node);
        }
    }

    private void validateFieldCondition(Object value, Set<String> keys, Object label) {
        if (!(value instanceof Map<?, ?>)) return;
        Map<String, Object> condition = map(value);
        String fieldKey = required(condition, "fieldKey");
        if (!keys.contains(fieldKey)) throw validation(label + "引用的条件字段不存在");
        String operator = required(condition, "operator");
        if (!Set.of("equals", "not-equals", "in").contains(operator)) {
            throw validation(label + "的条件运算符不受支持");
        }
    }

    private boolean activeUser(long id) {
        Integer count =
                jdbc.queryForObject(
                        "SELECT COUNT(*) FROM sys_user WHERE id=? AND status=1 AND deleted_at=0",
                        Integer.class,
                        id);
        return count != null && count == 1;
    }

    private void validateForm(List<Map<String, Object>> fields, Map<String, Object> data) {
        for (Map<String, Object> field : fields) {
            if ("section".equals(field.get("type"))) continue;
            if (field.get("visibleWhen") != null
                    && !conditionMatches(field.get("visibleWhen"), data)) continue;
            Object value = data.get(Objects.toString(field.get("key"), ""));
            boolean required =
                    Boolean.TRUE.equals(field.get("required"))
                            || conditionMatches(field.get("requiredWhen"), data);
            if (required && isEmptyValue(value)) {
                throw validation("请填写" + field.get("label"));
            }
            if (isEmptyValue(value)) continue;
            long maxLengthValue = number(field.get("maxLength"));
            int maxLength = maxLengthValue > 0 ? Math.toIntExact(maxLengthValue) : 0;
            if (maxLength > 0 && value.toString().length() > maxLength) {
                throw validation(field.get("label") + "不能超过" + maxLength + "个字符");
            }
            String rule = Objects.toString(field.get("validationRule"), "");
            String normalized = value.toString().replace('：', ':').replace('；', ';');
            if ("digit-list".equals(rule) && !validDigitList(normalized)) {
                throw validation(field.get("label") + "仅支持数字，多个值请用分号分隔");
            }
            if ("pixel-list".equals(rule) && !validPixelList(normalized)) {
                throw validation(field.get("label") + "格式错误，请按“像素名称:像素ID”填写");
            }
            if ("email".equals(rule) && !normalized.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
                throw validation(field.get("label") + "格式不正确");
            }
            if ("url".equals(rule) && !normalized.matches("^https?://.+")) {
                throw validation(field.get("label") + "仅支持 http 或 https 链接");
            }
            if ("positive-money".equals(rule) && decimal(value) <= 0) {
                throw validation(field.get("label") + "必须大于0");
            }
            if ("number".equals(field.get("type"))) {
                double numberValue = decimal(value);
                if (field.get("minValue") != null && numberValue < decimal(field.get("minValue"))) {
                    throw validation(field.get("label") + "不能小于" + field.get("minValue"));
                }
                if (field.get("maxValue") != null && numberValue > decimal(field.get("maxValue"))) {
                    throw validation(field.get("label") + "不能大于" + field.get("maxValue"));
                }
            }
            String source = Objects.toString(field.get("optionSource"), "custom");
            if (("select".equals(field.get("type")) || "multi-select".equals(field.get("type")))
                    && "custom".equals(source)) {
                Set<String> allowed = new LinkedHashSet<>(stringList(field.get("options")));
                List<String> selected =
                        value instanceof List<?> ? stringList(value) : List.of(value.toString());
                if (!allowed.containsAll(selected)) {
                    throw validation(field.get("label") + "包含无效选项，请重新选择");
                }
            }
        }
    }

    private boolean conditionMatches(Object value, Map<String, Object> data) {
        if (!(value instanceof Map<?, ?>)) return false;
        Map<String, Object> condition = map(value);
        String current = Objects.toString(data.get(condition.get("fieldKey")), "");
        String operator = Objects.toString(condition.get("operator"), "equals");
        Object expected = condition.get("value");
        if ("in".equals(operator)) return stringList(expected).contains(current);
        boolean equals = current.equals(Objects.toString(expected, ""));
        return "not-equals".equals(operator) ? !equals : equals;
    }

    /** 按稳定申请编码裁剪表单；未配置适用范围的历史字段默认对全部申请展示。 */
    private List<Map<String, Object>> applicableFormSchema(
            List<Map<String, Object>> fields, String applicationCode) {
        return fields.stream()
                .filter(
                        field ->
                                !(applicationCode.startsWith("ACCOUNT_")
                                        && "operationType".equals(field.get("key"))))
                .filter(
                        field -> {
                            List<String> codes =
                                    stringList(field.get("applicableApplicationCodes"));
                            if (codes.isEmpty()
                                    && applicationCode.startsWith("ACCOUNT_")
                                    && hasOperationTypeCondition(field)) {
                                codes =
                                        LEGACY_ACCOUNT_FIELD_APPLICATIONS.getOrDefault(
                                                Objects.toString(field.get("key"), ""), List.of());
                            }
                            return codes.isEmpty() || codes.contains(applicationCode);
                        })
                .map(
                        field -> {
                            if (!applicationCode.startsWith("ACCOUNT_")
                                    || !hasOperationTypeCondition(field)) return field;
                            Map<String, Object> normalized = new LinkedHashMap<>(field);
                            normalized.remove("visibleWhen");
                            normalized.remove("requiredWhen");
                            String key = Objects.toString(field.get("key"), "");
                            boolean required =
                                    !"remark".equals(key)
                                            || "ACCOUNT_RECYCLE".equals(applicationCode);
                            normalized.put("required", required);
                            return normalized;
                        })
                .toList();
    }

    private boolean hasOperationTypeCondition(Map<String, Object> field) {
        return "operationType"
                        .equals(Objects.toString(map(field.get("visibleWhen")).get("fieldKey"), ""))
                || "operationType"
                        .equals(
                                Objects.toString(
                                        map(field.get("requiredWhen")).get("fieldKey"), ""));
    }

    /** 删除不适用于当前申请的字段值，防止调用方绕过页面隐藏规则注入数据。 */
    private void removeInapplicableValues(
            List<Map<String, Object>> completeFields,
            List<Map<String, Object>> applicableFields,
            Map<String, Object> data) {
        Set<String> applicableKeys =
                applicableFields.stream()
                        .map(field -> Objects.toString(field.get("key"), ""))
                        .collect(java.util.stream.Collectors.toSet());
        completeFields.stream()
                .map(field -> Objects.toString(field.get("key"), ""))
                .filter(key -> !key.isBlank() && !applicableKeys.contains(key))
                .forEach(data::remove);
    }

    private double decimal(Object value) {
        if (value instanceof Number number) return number.doubleValue();
        try {
            return Double.parseDouble(Objects.toString(value, "0"));
        } catch (NumberFormatException exception) {
            return 0;
        }
    }

    private List<String> stringList(Object value) {
        if (!(value instanceof List<?> values)) return List.of();
        return values.stream()
                .map(item -> Objects.toString(item, "").trim())
                .filter(item -> !item.isBlank())
                .distinct()
                .toList();
    }

    /** 复用旧 MPower 表单的入库口径：兼容中文标点，并移除列表条目前后空格。 */
    private void normalizeFormData(List<Map<String, Object>> fields, Map<String, Object> data) {
        for (Map<String, Object> field : fields) {
            if ("section".equals(field.get("type"))) continue;
            String key = Objects.toString(field.get("key"), "");
            Object value = data.get(key);
            if (value == null || value instanceof List<?>) continue;
            String rule = Objects.toString(field.get("validationRule"), "");
            String normalized = value.toString().replace('：', ':').replace('；', ';');
            if ("digit-list".equals(rule)) {
                data.put(
                        key,
                        Arrays.stream(normalized.split(";"))
                                .map(String::trim)
                                .filter(item -> !item.isBlank())
                                .collect(java.util.stream.Collectors.joining(";")));
            } else if ("pixel-list".equals(rule)) {
                data.put(
                        key,
                        Arrays.stream(normalized.split("[;\\n\\r]+"))
                                .map(String::trim)
                                .filter(item -> !item.isBlank())
                                .map(
                                        item ->
                                                Arrays.stream(item.split(":", -1))
                                                        .map(String::trim)
                                                        .collect(
                                                                java.util.stream.Collectors.joining(
                                                                        ":")))
                                .collect(java.util.stream.Collectors.joining(";")));
            }
        }
    }

    private boolean validDigitList(String value) {
        List<String> items =
                Arrays.stream(value.split(";"))
                        .map(String::trim)
                        .filter(item -> !item.isBlank())
                        .toList();
        return !items.isEmpty() && items.stream().allMatch(item -> item.matches("[0-9]+"));
    }

    private boolean validPixelList(String value) {
        List<String> items =
                Arrays.stream(value.split("[;\\n\\r]+"))
                        .map(String::trim)
                        .filter(item -> !item.isBlank())
                        .toList();
        if (items.isEmpty()) return false;
        return items.stream()
                .allMatch(
                        item -> {
                            String[] parts = item.split(":", -1);
                            return parts.length == 2
                                    && !parts[0].trim().isBlank()
                                    && parts[1].trim().matches("[0-9]+");
                        });
    }

    private boolean isEmptyValue(Object value) {
        if (value == null) return true;
        if (value instanceof Collection<?> collection) return collection.isEmpty();
        return value.toString().isBlank();
    }

    private String configKey(String value) {
        String key = value.trim();
        if (!key.matches("[A-Za-z0-9_-]{1,24}")) throw validation("审批配置标识不合法");
        return key;
    }

    private String required(Map<String, Object> map, String key) {
        String value = Objects.toString(map.get(key), "").trim();
        if (value.isEmpty()) throw validation(key + "不能为空");
        return value;
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> list(Object value) {
        if (value instanceof List<?>) return (List<Map<String, Object>>) value;
        return (List<Map<String, Object>>) parse(value, List.of());
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> map(Object value) {
        return value instanceof Map<?, ?> ? (Map<String, Object>) value : new LinkedHashMap<>();
    }

    /** 将审批人选择的资产 ID 转成有序去重列表，禁止无效或重复 ID 绕过数量校验。 */
    private List<Long> longList(Object value) {
        if (!(value instanceof List<?> values)) return List.of();
        LinkedHashSet<Long> ids = new LinkedHashSet<>();
        for (Object item : values) {
            long id = number(item);
            if (id <= 0) throw validation("所选资产 ID 不合法");
            if (!ids.add(id)) throw validation("不能重复选择同一个资产");
        }
        return new ArrayList<>(ids);
    }

    private List<Long> applicationDefinitionIds(Object value) {
        if (!(value instanceof List<?> values)) return List.of();
        LinkedHashSet<Long> ids = new LinkedHashSet<>();
        for (Object item : values) {
            long id = number(item);
            if (id <= 0) throw validation("关联申请 ID 不合法");
            ids.add(id);
        }
        return new ArrayList<>(ids);
    }

    private long number(Object value) {
        if (value instanceof Number n) return n.longValue();
        try {
            return Long.parseLong(Objects.toString(value, "0"));
        } catch (NumberFormatException ignored) {
            return 0;
        }
    }

    private int intValue(Object value, int fallback) {
        long result = number(value);
        return result <= 0 ? fallback : Math.toIntExact(result);
    }

    private String stringify(Object value) {
        try {
            return json.writeValueAsString(value);
        } catch (JsonProcessingException exception) {
            throw validation("动态配置序列化失败");
        }
    }

    private Object parse(Object value, Object fallback) {
        if (value == null) return fallback;
        if (value instanceof List<?> || value instanceof Map<?, ?>) return value;
        try {
            return json.readValue(value.toString(), Object.class);
        } catch (JsonProcessingException exception) {
            return fallback;
        }
    }

    private BusinessException validation(String message) {
        return new BusinessException(422, message);
    }

    private BusinessException conflict(String message) {
        return new BusinessException(409, message);
    }

    private BusinessException notFound(String message) {
        return new BusinessException(404, message + "不存在");
    }
}
