package com.adpulse.system.asset.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.util.List;

/** 资产流程写接口的请求契约。 */
public final class AssetRequests {
    private AssetRequests() {}

    /** 创建或修改资产。 */
    public record AssetSave(
            @NotBlank String assetType,
            @NotBlank String assetName,
            @NotBlank String assetCode,
            String projectId,
            String projectName,
            String channelId,
            String channelName,
            String secretData,
            String remark,
            String status,
            Long assigneeId) {}

    /** 创建资源申请。 */
    public record ApplicationCreate(
            @NotBlank String assetType,
            @NotBlank String title,
            @NotNull @Min(1) @Max(100) Integer quantity,
            @NotBlank String reason) {}

    /** 保存审批人配置。 */
    public record ApprovalConfigSave(
            @NotBlank String assetType,
            @NotNull Long approverId,
            @NotBlank String approverName,
            String ccUserIds) {}

    /** 新建审批配置分组。 */
    public record ApprovalGroupCreate(@NotBlank @Size(max = 64) String name) {}

    /** 保存全部审批配置分组的展示顺序。 */
    public record ApprovalGroupOrder(@NotEmpty List<@NotNull Long> groupIds) {}

    /** 审批决定。 */
    public record Decision(String remark) {}

    /** 发布审批流程评论。 */
    public record ApprovalCommentCreate(@NotBlank @Size(max = 500) String content) {}
}
