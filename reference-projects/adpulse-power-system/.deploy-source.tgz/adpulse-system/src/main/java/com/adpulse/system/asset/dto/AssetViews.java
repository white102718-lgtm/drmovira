package com.adpulse.system.asset.dto;

import java.time.LocalDateTime;
import java.util.List;

/** 资产流程查询接口的响应契约。 */
public final class AssetViews {
    private AssetViews() {}

    /** 审批配置分组视图；ID 使用字符串避免前端大整数精度丢失。 */
    public record ApprovalGroupView(
            String id, String name, Integer sortOrder, LocalDateTime updatedAt) {}

    /** 审批流程评论视图；评论身份由服务端根据流程参与关系生成。 */
    public record ApprovalCommentView(
            String id, String actor, String actorRole, LocalDateTime at, String content) {}

    /** 顶部导航红点所需的轻量未读状态。 */
    public record NotificationUnreadStatus(boolean hasUnread) {}

    /** 站内通知列表项；ID 使用字符串避免前端大整数精度丢失。 */
    public record NotificationView(
            String id,
            String title,
            String message,
            String targetPath,
            String businessType,
            String businessId,
            boolean isRead,
            LocalDateTime createdAt) {}

    /** 站内通知分页结果，供前端滚动加载。 */
    public record NotificationPage(
            List<NotificationView> items, long total, int page, int pageSize, boolean hasMore) {}
}
