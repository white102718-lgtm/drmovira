package com.adpulse.system.asset.model;

import java.time.LocalDateTime;
import lombok.Data;

/** 审批配置分组；用于持久化空分组及分组展示顺序。 */
@Data
public class ApprovalGroup {
    private Long id;
    private String name;
    private Integer sortOrder;
    private LocalDateTime updatedAt;
}
