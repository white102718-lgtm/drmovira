package com.adpulse.system.menu.service;

import com.adpulse.system.common.exception.BusinessException;
import com.adpulse.system.common.security.SecurityContextHelper;
import com.adpulse.system.menu.dto.MenuSaveRequest;
import com.adpulse.system.menu.dto.UserMenuRoute;
import com.adpulse.system.menu.mapper.MenuMapper;
import com.adpulse.system.menu.model.Menu;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

/** 菜单树与按钮权限资源管理服务。 */
@Service
public class MenuService {

    private final MenuMapper mapper;

    public MenuService(MenuMapper mapper) {
        this.mapper = mapper;
    }

    /** 查询完整菜单权限树。 */
    public List<Menu> tree() {
        return buildTree(mapper.findAllActive());
    }

    /** 查询指定登录用户通过有效角色获得的前端导航菜单树。 */
    public List<UserMenuRoute> userMenuTree(Long userId) {
        return buildTree(mapper.findAuthorizedNavigationMenus(userId)).stream()
                .map(this::toUserRoute)
                .toList();
    }

    private List<Menu> buildTree(List<Menu> menus) {
        Map<Long, Menu> index = new LinkedHashMap<>();
        menus.forEach(
                menu -> {
                    menu.setChildren(new ArrayList<>());
                    index.put(menu.getId(), menu);
                });
        List<Menu> roots = new ArrayList<>();
        for (Menu menu : menus) {
            Menu parent = index.get(menu.getParentId());
            if (menu.getParentId() == 0 || parent == null) {
                roots.add(menu);
            } else {
                parent.getChildren().add(menu);
            }
        }
        return roots;
    }

    private UserMenuRoute toUserRoute(Menu menu) {
        String path =
                StringUtils.hasText(menu.getRoutePath())
                        ? menu.getRoutePath()
                        : "/" + menu.getMenuCode().toLowerCase(Locale.ROOT).replace('_', '-');
        String component = normalizeComponent(menu.getComponent());
        UserMenuRoute.Meta meta =
                new UserMenuRoute.Meta(
                        menu.getMenuName(),
                        menu.getIcon(),
                        menu.getSortOrder(),
                        menu.getVisible() != null && menu.getVisible() == 0,
                        menu.getCacheable() != null && menu.getCacheable() == 1,
                        menu.getExternalLink());
        return new UserMenuRoute(
                menu.getId().toString(),
                menu.getParentId() == 0 ? "" : menu.getParentId().toString(),
                menu.getMenuCode(),
                path,
                component,
                menu.getPermissionCode() == null ? "" : menu.getPermissionCode(),
                menu.getMenuType() == 1 ? "catalog" : "menu",
                meta,
                menu.getChildren().stream().map(this::toUserRoute).toList());
    }

    private String normalizeComponent(String component) {
        if (!StringUtils.hasText(component)
                || component.startsWith("/")
                || "BasicLayout".equals(component)
                || "IFrameView".equals(component)) {
            return component;
        }
        return "/" + component;
    }

    /** 新增菜单或按钮资源。 */
    @Transactional
    public Menu create(MenuSaveRequest request) {
        validateParent(null, request);
        Menu menu = new Menu();
        apply(menu, request);
        Long operatorId = SecurityContextHelper.currentUserId();
        menu.setCreatedBy(operatorId);
        menu.setUpdatedBy(operatorId);
        mapper.insert(menu);
        return mapper.findById(menu.getId());
    }

    /** 修改菜单并防止形成树环。 */
    @Transactional
    public Menu update(Long id, MenuSaveRequest request) {
        Menu menu = requireMenu(id);
        validateParent(menu, request);
        apply(menu, request);
        menu.setUpdatedBy(SecurityContextHelper.currentUserId());
        mapper.update(menu);
        return mapper.findById(id);
    }

    /** 软删除叶子菜单并同步软删除角色授权。 */
    @Transactional
    public void delete(Long id) {
        requireMenu(id);
        if (mapper.countChildren(id) > 0) {
            throw BusinessException.conflict("请先删除或移动子菜单");
        }
        long deletedAt = System.currentTimeMillis();
        mapper.softDeleteRoleRelations(id, deletedAt);
        mapper.softDelete(id, deletedAt, SecurityContextHelper.currentUserId());
    }

    private Menu requireMenu(Long id) {
        Menu menu = mapper.findById(id);
        if (menu == null) {
            throw BusinessException.notFound("菜单");
        }
        return menu;
    }

    private void validateParent(Menu current, MenuSaveRequest request) {
        if (request.parentId() == 0) {
            if (request.menuType() == 3) {
                throw BusinessException.conflict("按钮权限不能作为根节点");
            }
            return;
        }
        Menu parent = requireMenu(request.parentId());
        if (current != null && parent.getId().equals(current.getId())) {
            throw BusinessException.conflict("菜单不能以自身为父节点");
        }
        if (parent.getMenuType() == 3) {
            throw BusinessException.conflict("按钮资源下不能创建子节点");
        }
        if (request.menuType() == 3 && parent.getMenuType() != 2) {
            throw BusinessException.conflict("按钮权限必须挂在菜单下");
        }
        if (current != null && isDescendant(parent.getId(), current.getId())) {
            throw BusinessException.conflict("菜单不能移动到自身子树下");
        }
    }

    private boolean isDescendant(Long candidateId, Long ancestorId) {
        Long cursor = candidateId;
        while (cursor != 0) {
            Menu menu = mapper.findById(cursor);
            if (menu == null) {
                return false;
            }
            if (menu.getParentId().equals(ancestorId)) {
                return true;
            }
            cursor = menu.getParentId();
        }
        return false;
    }

    private void apply(Menu menu, MenuSaveRequest request) {
        menu.setParentId(request.parentId());
        menu.setMenuType(request.menuType());
        menu.setMenuCode(request.menuCode());
        menu.setMenuName(request.menuName());
        menu.setRoutePath(request.routePath());
        menu.setComponent(request.component());
        menu.setIcon(request.icon());
        menu.setPermissionCode(
                StringUtils.hasText(request.permissionCode())
                        ? request.permissionCode().trim()
                        : null);
        menu.setVisible(request.visible());
        menu.setCacheable(request.cacheable());
        menu.setExternalLink(request.externalLink());
        menu.setSortOrder(request.sortOrder() == null ? 0 : request.sortOrder());
        menu.setStatus(request.status());
        menu.setRemark(request.remark());
    }
}
