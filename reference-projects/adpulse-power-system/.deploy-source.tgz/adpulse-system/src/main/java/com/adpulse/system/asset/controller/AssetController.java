package com.adpulse.system.asset.controller;

import com.adpulse.system.asset.dto.AssetRequests;
import com.adpulse.system.asset.model.ApprovalConfig;
import com.adpulse.system.asset.model.AssetApplication;
import com.adpulse.system.asset.model.MediaAsset;
import com.adpulse.system.asset.service.AssetService;
import com.adpulse.system.common.api.ApiResponse;
import com.adpulse.system.operationlog.audit.OperationAudit;
import com.adpulse.system.operationlog.audit.OperationType;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** 资产管理、申请、审批和个人资产接口。 */
@RestController
@RequestMapping("/asset-flow")
@Tag(name = "资产流程", description = "个号、BM、像素和TG的申请审批闭环")
public class AssetController {
    private final AssetService service;

    public AssetController(AssetService service) {
        this.service = service;
    }

    @GetMapping("/assets")
    public ApiResponse<List<MediaAsset>> assets(
            @RequestParam(required = false) String assetType,
            @RequestParam(required = false) String channelId,
            @RequestParam(required = false) String projectId) {
        return ApiResponse.success(
                service.assets(assetType, channelId == null ? projectId : channelId));
    }

    @PostMapping("/assets")
    @OperationAudit(
            module = "ASSET",
            type = OperationType.CREATE,
            name = "新增资产",
            targetType = "media_asset")
    public ApiResponse<MediaAsset> createAsset(
            @Valid @RequestBody AssetRequests.AssetSave request) {
        return ApiResponse.success(service.createAsset(request));
    }

    @PutMapping("/assets/{id}")
    @OperationAudit(
            module = "ASSET",
            type = OperationType.UPDATE,
            name = "修改资产",
            targetType = "media_asset",
            targetIdParameter = "id")
    public ApiResponse<MediaAsset> updateAsset(
            @PathVariable Long id, @Valid @RequestBody AssetRequests.AssetSave request) {
        return ApiResponse.success(service.updateAsset(id, request));
    }

    @DeleteMapping("/assets/{id}")
    @OperationAudit(
            module = "ASSET",
            type = OperationType.DELETE,
            name = "删除资产",
            targetType = "media_asset",
            targetIdParameter = "id")
    public ApiResponse<Void> deleteAsset(@PathVariable Long id) {
        service.deleteAsset(id);
        return ApiResponse.success();
    }

    @GetMapping("/assets/mine")
    public ApiResponse<List<MediaAsset>> myAssets() {
        return ApiResponse.success(service.myAssets());
    }

    @GetMapping("/approval-configs")
    public ApiResponse<List<ApprovalConfig>> configs() {
        return ApiResponse.success(service.configs());
    }

    @PutMapping("/approval-configs")
    @OperationAudit(
            module = "ASSET",
            type = OperationType.UPDATE,
            name = "配置资产审批人",
            targetType = "media_approval_config")
    public ApiResponse<ApprovalConfig> saveConfig(
            @Valid @RequestBody AssetRequests.ApprovalConfigSave request) {
        return ApiResponse.success(service.saveConfig(request));
    }

    @PostMapping("/applications")
    @OperationAudit(
            module = "ASSET",
            type = OperationType.CREATE,
            name = "提交资产申请",
            targetType = "media_asset_application")
    public ApiResponse<AssetApplication> apply(
            @Valid @RequestBody AssetRequests.ApplicationCreate request) {
        return ApiResponse.success(service.apply(request));
    }

    @GetMapping("/applications/mine")
    public ApiResponse<List<AssetApplication>> myApplications() {
        return ApiResponse.success(service.myApplications());
    }

    @GetMapping("/approvals")
    public ApiResponse<List<AssetApplication>> approvals() {
        return ApiResponse.success(service.approvals());
    }

    @PostMapping("/approvals/{id}/approve")
    @OperationAudit(
            module = "ASSET",
            type = OperationType.UPDATE,
            name = "通过资产申请",
            targetType = "media_asset_application",
            targetIdParameter = "id")
    public ApiResponse<AssetApplication> approve(
            @PathVariable Long id, @RequestBody AssetRequests.Decision request) {
        return ApiResponse.success(service.approve(id, request));
    }

    @PostMapping("/approvals/{id}/reject")
    @OperationAudit(
            module = "ASSET",
            type = OperationType.UPDATE,
            name = "驳回资产申请",
            targetType = "media_asset_application",
            targetIdParameter = "id")
    public ApiResponse<AssetApplication> reject(
            @PathVariable Long id, @RequestBody AssetRequests.Decision request) {
        return ApiResponse.success(service.reject(id, request));
    }
}
