package com.adpulse.system.menu.mapper;

import com.adpulse.system.menu.model.Menu;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/** 菜单持久化访问接口。 */
@Mapper
public interface MenuMapper {
    List<Menu> findAllActive();

    List<Menu> findAuthorizedNavigationMenus(@Param("userId") Long userId);

    Menu findById(@Param("id") Long id);

    int insert(Menu menu);

    int update(Menu menu);

    int countChildren(@Param("id") Long id);

    int softDelete(
            @Param("id") Long id,
            @Param("deletedAt") long deletedAt,
            @Param("updatedBy") Long updatedBy);

    int softDeleteRoleRelations(@Param("menuId") Long menuId, @Param("deletedAt") long deletedAt);
}
