package com.adpulse.system.asset.mapper;

import com.adpulse.system.asset.model.ApprovalConfig;
import com.adpulse.system.asset.model.ApprovalGroup;
import com.adpulse.system.asset.model.AssetApplication;
import com.adpulse.system.asset.model.AssetApplicationComment;
import com.adpulse.system.asset.model.MediaAsset;
import com.adpulse.system.asset.model.SiteNotification;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/** 资产、申请和审批配置持久化接口。 */
@Mapper
public interface AssetMapper {
    List<MediaAsset> findAssets(
            @Param("assetType") String assetType,
            @Param("assigneeId") Long assigneeId,
            @Param("channelId") String channelId);

    MediaAsset findAsset(@Param("id") Long id);

    int insertAsset(MediaAsset asset);

    int updateAsset(MediaAsset asset);

    int softDeleteAsset(
            @Param("id") Long id,
            @Param("deletedAt") long deletedAt,
            @Param("operatorId") Long operatorId);

    List<ApprovalConfig> findConfigs();

    ApprovalConfig findConfig(@Param("assetType") String assetType);

    int countActiveUser(@Param("userId") Long userId);

    String findActiveUserName(@Param("userId") Long userId);

    int upsertConfig(@Param("config") ApprovalConfig config, @Param("operatorId") Long operatorId);

    int softDeleteConfig(
            @Param("id") Long id,
            @Param("deletedAt") long deletedAt,
            @Param("operatorId") Long operatorId);

    List<ApprovalGroup> findApprovalGroups();

    ApprovalGroup findApprovalGroup(@Param("id") Long id);

    Integer findMaxApprovalGroupSortOrder();

    int insertApprovalGroup(
            @Param("group") ApprovalGroup group, @Param("operatorId") Long operatorId);

    int updateApprovalGroupSortOrder(
            @Param("id") Long id,
            @Param("sortOrder") int sortOrder,
            @Param("operatorId") Long operatorId);

    int countConfigsByGroup(@Param("groupId") Long groupId);

    int softDeleteApprovalGroup(
            @Param("id") Long id,
            @Param("deletedAt") long deletedAt,
            @Param("operatorId") Long operatorId);

    int insertApplication(
            @Param("application") AssetApplication application,
            @Param("operatorId") Long operatorId);

    AssetApplication findApplication(@Param("id") Long id);

    List<AssetApplication> findApplications(
            @Param("requesterId") Long requesterId, @Param("approverId") Long approverId);

    List<MediaAsset> lockAvailableAssets(
            @Param("assetType") String assetType, @Param("quantity") int quantity);

    int assignAsset(
            @Param("id") Long id,
            @Param("applicationId") Long applicationId,
            @Param("assigneeId") Long assigneeId,
            @Param("assigneeName") String assigneeName,
            @Param("operatorId") Long operatorId);

    int decideApplication(
            @Param("id") Long id,
            @Param("status") String status,
            @Param("remark") String remark,
            @Param("operatorId") Long operatorId);

    int insertApprovalLog(
            @Param("applicationId") Long applicationId,
            @Param("action") String action,
            @Param("actorId") Long actorId,
            @Param("actorName") String actorName,
            @Param("remark") String remark);

    List<AssetApplicationComment> findApplicationComments(
            @Param("applicationId") Long applicationId);

    AssetApplicationComment findApplicationComment(@Param("id") Long id);

    int insertApplicationComment(AssetApplicationComment comment);

    List<SiteNotification> findNotifications(
            @Param("userId") Long userId,
            @Param("offset") int offset,
            @Param("pageSize") int pageSize);

    long countNotifications(@Param("userId") Long userId);

    boolean hasUnreadNotification(@Param("userId") Long userId);

    int markNotificationRead(@Param("id") Long id, @Param("userId") Long userId);

    int markAllNotificationsRead(@Param("userId") Long userId);
}
