package com.adpulse.system.asset.model;

import java.time.LocalDateTime;
import lombok.Data;

/** 九类可入库资源的统一资产记录，覆盖广告社媒资源与办公资产。 */
@Data
public class MediaAsset {
    private Long id;
    private String assetType;
    private String assetName;
    private String assetCode;
    private String projectId;
    private String projectName;
    private String channelId;
    private String channelName;
    private String secretData;
    private String status;
    private Long assigneeId;
    private String assigneeName;
    private Long applicationId;
    private String remark;
    private Long createdBy;
    private Long updatedBy;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
