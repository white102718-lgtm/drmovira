package com.adpulse.system.department.mapper;

import com.adpulse.system.department.model.Department;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/** 部门持久化访问接口。 */
@Mapper
public interface DepartmentMapper {
    List<Department> findAllActive();

    Department findById(@Param("id") Long id);

    int insert(Department department);

    int update(Department department);

    int updateSubtreePath(
            @Param("oldPrefix") String oldPrefix,
            @Param("newPrefix") String newPrefix,
            @Param("levelDelta") int levelDelta,
            @Param("updatedBy") Long updatedBy);

    int countChildren(@Param("id") Long id);

    int countUsers(@Param("id") Long id);

    int countScopes(@Param("id") Long id);

    int countActiveUser(@Param("userId") Long userId);

    int softDelete(
            @Param("id") Long id,
            @Param("deletedAt") long deletedAt,
            @Param("updatedBy") Long updatedBy);
}
