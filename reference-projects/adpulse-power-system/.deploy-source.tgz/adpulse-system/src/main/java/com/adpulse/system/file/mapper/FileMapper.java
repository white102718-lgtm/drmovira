package com.adpulse.system.file.mapper;

import com.adpulse.system.file.model.FileObject;
import com.adpulse.system.file.model.StoredFile;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/** 文件对象和用户文件记录持久化接口。 */
@Mapper
public interface FileMapper {
    FileObject findAvailableObject(
            @Param("contentHash") String contentHash, @Param("fileSize") long fileSize);

    int insertObject(FileObject fileObject);

    int incrementReference(@Param("id") Long id, @Param("operatorId") Long operatorId);

    int decrementReference(@Param("id") Long id, @Param("operatorId") Long operatorId);

    int insertFile(StoredFile file);

    StoredFile findOwnedFile(@Param("id") Long id, @Param("uploaderId") Long uploaderId);

    StoredFile findReadableFile(
            @Param("id") Long id,
            @Param("userId") Long userId,
            @Param("canManageFeedback") boolean canManageFeedback);

    int countActiveTaskBindings(@Param("fileId") Long fileId);

    int countActiveFeedbackBindings(@Param("fileId") Long fileId);

    int softDeleteFile(
            @Param("id") Long id,
            @Param("uploaderId") Long uploaderId,
            @Param("deletedAt") long deletedAt,
            @Param("operatorId") Long operatorId);
}
