package com.adpulse.system.user.service;

import com.adpulse.system.auth.service.SessionStore;
import com.adpulse.system.common.api.PageResult;
import com.adpulse.system.common.exception.BusinessException;
import com.adpulse.system.common.security.SecurityContextHelper;
import com.adpulse.system.user.dto.DepartmentScopeRequest;
import com.adpulse.system.user.dto.UserDetail;
import com.adpulse.system.user.dto.UserProfileResponse;
import com.adpulse.system.user.dto.UserProfileUpdateRequest;
import com.adpulse.system.user.dto.UserSaveRequest;
import com.adpulse.system.user.mapper.UserMapper;
import com.adpulse.system.user.model.UserAccount;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.util.matcher.IpAddressMatcher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

/** 用户主数据及角色、部门范围、IP规则的聚合服务。 */
@Service
public class UserService {

    private final UserMapper mapper;
    private final PasswordEncoder passwordEncoder;
    private final SessionStore sessionStore;

    public UserService(
            UserMapper mapper, PasswordEncoder passwordEncoder, SessionStore sessionStore) {
        this.mapper = mapper;
        this.passwordEncoder = passwordEncoder;
        this.sessionStore = sessionStore;
    }

    /** 分页查询用户。 */
    public PageResult<UserAccount> page(
            String keyword, Integer status, Long departmentId, int page, int pageSize) {
        int safePage = Math.max(page, 1);
        int safeSize = Math.min(Math.max(pageSize, 1), 200);
        return new PageResult<>(
                mapper.findPage(keyword, status, departmentId, (safePage - 1) * safeSize, safeSize),
                mapper.count(keyword, status, departmentId),
                safePage,
                safeSize);
    }

    /** 查询用户及全部系统管理关系。 */
    public UserDetail detail(Long id) {
        UserAccount user = requireUser(id);
        Set<String> roleIds =
                mapper.findRoleIds(id).stream().map(String::valueOf).collect(Collectors.toSet());
        return new UserDetail(
                user, roleIds, mapper.findDepartmentScopes(id), mapper.findPersonalIpCidrs(id));
    }

    /** 查询当前登录用户可展示的个人资料。 */
    public UserProfileResponse currentProfile() {
        Long userId = SecurityContextHelper.currentUserId();
        UserAccount user = requireUser(userId);
        String department = null;
        if (user.getPrimaryDepartmentId() != null) {
            department = mapper.findDepartmentName(user.getPrimaryDepartmentId());
        }
        return new UserProfileResponse(
                userId.toString(),
                user.getUsername(),
                user.getPhone(),
                user.getDisplayName(),
                user.getEnglishNickname(),
                user.getRealName(),
                user.getEmail(),
                user.getAvatarUrl(),
                department,
                mapper.findDepartmentNames(userId),
                mapper.findRoleNames(userId));
    }

    /** 修改当前登录用户资料；修改密码时校验旧密码并撤销全部会话。 */
    @Transactional
    public UserProfileResponse updateCurrentProfile(UserProfileUpdateRequest request) {
        Long userId = SecurityContextHelper.currentUserId();
        UserAccount user = requireUser(userId);
        boolean changesPassword = StringUtils.hasText(request.newPassword());
        if (changesPassword) {
            if (!StringUtils.hasText(request.oldPassword())
                    || !passwordEncoder.matches(request.oldPassword(), user.getPasswordHash())) {
                throw BusinessException.validation("旧密码不正确");
            }
            if (passwordEncoder.matches(request.newPassword(), user.getPasswordHash())) {
                throw BusinessException.validation("新密码不能与旧密码相同");
            }
        } else if (StringUtils.hasText(request.oldPassword())) {
            throw BusinessException.validation("请输入新密码");
        }

        user.setDisplayName(request.displayName().trim());
        user.setEnglishNickname(blankToNull(request.englishNickname()));
        user.setRealName(blankToNull(request.realName()));
        user.setEmail(blankToNull(request.email()));
        user.setAvatarUrl(blankToNull(request.avatarUrl()));
        user.setUpdatedBy(userId);
        if (mapper.updateProfile(user) != 1) {
            throw BusinessException.conflict("用户已停用或不存在");
        }
        if (changesPassword) {
            mapper.updatePassword(userId, passwordEncoder.encode(request.newPassword()), userId);
            sessionStore.revokeUser(userId);
        }
        return currentProfile();
    }

    /** 新建用户并原子写入关联关系。 */
    @Transactional
    public UserDetail create(UserSaveRequest request) {
        if (!StringUtils.hasText(request.password())) {
            throw BusinessException.validation("新建用户必须设置初始密码");
        }
        validateRelations(request);
        UserAccount user = new UserAccount();
        apply(user, request);
        user.setPasswordHash(passwordEncoder.encode(request.password()));
        Long operatorId = SecurityContextHelper.currentUserId();
        user.setCreatedBy(operatorId);
        user.setUpdatedBy(operatorId);
        mapper.insert(user);
        replaceRelations(user.getId(), request, operatorId);
        return detail(user.getId());
    }

    /** 修改用户与关联关系；安全状态变化后撤销全部会话。 */
    @Transactional
    public UserDetail update(Long id, UserSaveRequest request) {
        UserAccount user = requireUser(id);
        int oldStatus = user.getStatus();
        int oldIpMode = user.getIpAccessMode();
        validateRelations(request);
        apply(user, request);
        Long operatorId = SecurityContextHelper.currentUserId();
        user.setUpdatedBy(operatorId);
        mapper.update(user);
        if (StringUtils.hasText(request.password())) {
            mapper.updatePassword(id, passwordEncoder.encode(request.password()), operatorId);
        }
        replaceRelations(id, request, operatorId);
        if (oldStatus != request.status()
                || oldIpMode != request.ipAccessMode()
                || StringUtils.hasText(request.password())) {
            sessionStore.revokeUser(id);
        }
        return detail(id);
    }

    /** 重置用户密码并撤销该用户全部会话。 */
    @Transactional
    public void resetPassword(Long id, String newPassword) {
        requireUser(id);
        mapper.updatePassword(
                id, passwordEncoder.encode(newPassword), SecurityContextHelper.currentUserId());
        sessionStore.revokeUser(id);
    }

    /** 清理用户MFA绑定并撤销全部会话。 */
    @Transactional
    public void resetMfa(Long id) {
        requireUser(id);
        mapper.resetMfa(id, SecurityContextHelper.currentUserId());
        sessionStore.revokeUser(id);
    }

    /** 软删除用户和全部系统管理关系。 */
    @Transactional
    public void delete(Long id) {
        requireUser(id);
        if (SecurityContextHelper.currentUserId().equals(id)) {
            throw BusinessException.conflict("不能删除当前登录用户");
        }
        long deletedAt = System.currentTimeMillis();
        mapper.softDeleteRoles(id, deletedAt);
        mapper.softDeleteScopes(id, deletedAt);
        mapper.softDeletePersonalIps(id, deletedAt);
        mapper.softDelete(id, deletedAt, SecurityContextHelper.currentUserId());
        sessionStore.revokeUser(id);
    }

    private void validateRelations(UserSaveRequest request) {
        if (request.primaryDepartmentId() != null
                && mapper.countActiveDepartment(request.primaryDepartmentId()) != 1) {
            throw BusinessException.conflict("主部门不存在、已停用或已删除");
        }
        Set<Long> roleIds = request.roleIds() == null ? Set.of() : request.roleIds();
        if (!roleIds.isEmpty() && mapper.countActiveRoles(roleIds) != roleIds.size()) {
            throw BusinessException.conflict("角色包含不存在、已停用或已删除的数据");
        }
        Set<DepartmentScopeRequest> scopes =
                request.departmentScopes() == null ? Set.of() : request.departmentScopes();
        Set<Long> departmentIds =
                scopes.stream()
                        .map(DepartmentScopeRequest::departmentId)
                        .collect(Collectors.toSet());
        if (!departmentIds.isEmpty()
                && mapper.countActiveDepartments(departmentIds) != departmentIds.size()) {
            throw BusinessException.conflict("部门范围包含不存在、已停用或已删除的数据");
        }
        Set<String> cidrs = request.ipCidrs() == null ? Set.of() : request.ipCidrs();
        for (String cidr : cidrs) {
            try {
                new IpAddressMatcher(cidr);
            } catch (IllegalArgumentException exception) {
                throw BusinessException.validation("非法IP或CIDR: " + cidr);
            }
        }
        if (request.ipAccessMode() == 1 && mapper.countActiveGlobalIpRules() == 0) {
            throw BusinessException.conflict("仅通用白名单模式至少需要一条通用IP规则");
        }
        if (request.ipAccessMode() == 2
                && cidrs.isEmpty()
                && mapper.countActiveGlobalIpRules() == 0) {
            throw BusinessException.conflict("白名单模式至少需要一条个人或通用IP规则");
        }
    }

    private void replaceRelations(Long userId, UserSaveRequest request, Long operatorId) {
        long deletedAt = System.currentTimeMillis();
        Set<Long> roleIds = request.roleIds() == null ? Set.of() : request.roleIds();
        mapper.softDeleteRoles(userId, deletedAt);
        if (!roleIds.isEmpty()) {
            mapper.batchInsertRoles(userId, roleIds, operatorId);
        }

        Set<DepartmentScopeRequest> scopes =
                request.departmentScopes() == null
                        ? Set.of()
                        : new LinkedHashSet<>(request.departmentScopes());
        mapper.softDeleteScopes(userId, deletedAt);
        if (!scopes.isEmpty()) {
            mapper.batchInsertScopes(userId, scopes, operatorId);
        }

        Set<String> cidrs = request.ipCidrs() == null ? Set.of() : request.ipCidrs();
        mapper.softDeletePersonalIps(userId, deletedAt);
        if (!cidrs.isEmpty()) {
            mapper.batchInsertPersonalIps(userId, cidrs, operatorId);
        }
    }

    private UserAccount requireUser(Long id) {
        UserAccount user = mapper.findById(id);
        if (user == null) {
            throw BusinessException.notFound("用户");
        }
        return user;
    }

    private void apply(UserAccount user, UserSaveRequest request) {
        user.setUsername(blankToNull(request.username()));
        user.setPhone(request.phone());
        user.setDisplayName(request.displayName());
        user.setEnglishNickname(blankToNull(request.englishNickname()));
        user.setRealName(blankToNull(request.realName()));
        user.setPrimaryDepartmentId(request.primaryDepartmentId());
        user.setEmail(blankToNull(request.email()));
        user.setAvatarUrl(blankToNull(request.avatarUrl()));
        user.setStatus(request.status());
        user.setIpAccessMode(request.ipAccessMode());
        user.setRemark(request.remark());
    }

    private String blankToNull(String value) {
        return StringUtils.hasText(value) ? value.trim() : null;
    }
}
