package com.adpulse.system.asset.service;

import com.adpulse.system.asset.dto.AssetRequests;
import com.adpulse.system.asset.dto.AssetViews;
import com.adpulse.system.asset.mapper.AssetMapper;
import com.adpulse.system.asset.model.ApprovalConfig;
import com.adpulse.system.asset.model.ApprovalGroup;
import com.adpulse.system.asset.model.AssetApplication;
import com.adpulse.system.asset.model.MediaAsset;
import com.adpulse.system.auth.service.MfaSecretCipher;
import com.adpulse.system.common.exception.BusinessException;
import com.adpulse.system.common.security.CurrentUser;
import com.adpulse.system.common.security.SecurityContextHelper;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** 统一资产库存、申请、审批和发放业务。 */
@Service
public class AssetService {
    private static final Pattern INVENTORY_SUBTYPE_PATTERN =
            Pattern.compile("\\\"inventorySubtype\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
    private static final Set<String> TYPES =
            Set.of(
                    "PERSONAL",
                    "BM",
                    "PIXEL",
                    "TG",
                    "PAGE",
                    "COMPUTER",
                    "MOBILE",
                    "STATIC_IP",
                    "EMAIL");
    private final AssetMapper mapper;
    private final MfaSecretCipher secretCipher;

    public AssetService(AssetMapper mapper, MfaSecretCipher secretCipher) {
        this.mapper = mapper;
        this.secretCipher = secretCipher;
    }

    /** 查询全部资产库存。 */
    public List<MediaAsset> assets(String assetType, String channelId) {
        return reveal(mapper.findAssets(typeOrNull(assetType), null, textOrNull(channelId)));
    }

    /** 查询当前用户获批资产。 */
    public List<MediaAsset> myAssets() {
        return reveal(mapper.findAssets(null, SecurityContextHelper.currentUserId(), null));
    }

    /** 校验加密库存详情中的前端子类型；没有子类型的历史 PERSONAL 资产按 Facebook 账号处理。 */
    public boolean matchesInventorySubtype(String encryptedSecretData, String expectedSubtype) {
        if (expectedSubtype == null || expectedSubtype.isBlank()) return true;
        String actualSubtype = "personal";
        if (encryptedSecretData != null && !encryptedSecretData.isBlank()) {
            String secretData = secretCipher.decrypt(encryptedSecretData);
            Matcher matcher = INVENTORY_SUBTYPE_PATTERN.matcher(secretData);
            if (matcher.find()) actualSubtype = matcher.group(1).trim();
        }
        return expectedSubtype.trim().equalsIgnoreCase(actualSubtype);
    }

    /**
     * 从申请表快照解析办理阶段实际需要的库存类型。
     *
     * @param applicationType 审批配置类型
     * @param applicationData 申请表快照
     * @param assignment 办理节点资源分配配置
     * @return 库存主类型与可选子类型
     */
    public InventorySelection resolveInventorySelection(
            String applicationType,
            Map<String, Object> applicationData,
            Map<String, Object> assignment) {
        String fieldKey = Objects.toString(assignment.get("assetTypeFieldKey"), "").trim();
        if (fieldKey.isBlank() && applicationData.containsKey("socialAssetType")) {
            fieldKey = "socialAssetType";
        }
        if (fieldKey.isBlank()) return new InventorySelection(applicationType, "");

        String requestedType = Objects.toString(applicationData.get(fieldKey), "").trim();
        if (requestedType.isBlank()) throw BusinessException.validation("申请缺少社交资产类型");
        String normalized = requestedType.toLowerCase(Locale.ROOT).replace(" ", "");
        if (Set.of("tg", "tg号", "telegram").contains(normalized)) {
            return new InventorySelection("TG", "");
        }
        if (Set.of("微信", "微信号", "wechat").contains(normalized)) {
            return new InventorySelection("PERSONAL", "wechat");
        }
        if (Set.of("facebook", "facebook账号", "facebookaccount", "personal", "个号")
                .contains(normalized)) {
            return new InventorySelection("PERSONAL", "personal");
        }
        String inventoryType = requestedType.toUpperCase(Locale.ROOT);
        if (!TYPES.contains(inventoryType)) throw BusinessException.validation("不支持的社交资产类型");
        return new InventorySelection(inventoryType, "");
    }

    /** 办理阶段使用的库存主类型与 PERSONAL 子类型。 */
    public record InventorySelection(String assetType, String subtype) {}

    /** 新增资产。 */
    @Transactional
    public MediaAsset createAsset(AssetRequests.AssetSave request) {
        MediaAsset asset = apply(new MediaAsset(), request);
        Long userId = SecurityContextHelper.currentUserId();
        asset.setCreatedBy(userId);
        asset.setUpdatedBy(userId);
        try {
            mapper.insertAsset(asset);
        } catch (DuplicateKeyException exception) {
            throw BusinessException.conflict("资产标识已存在");
        }
        return reveal(mapper.findAsset(asset.getId()));
    }

    /** 修改资产；回收流程中的资产由回收模块独占，不能直接改写。 */
    @Transactional
    public MediaAsset updateAsset(Long id, AssetRequests.AssetSave request) {
        MediaAsset asset = requireAsset(id);
        if ("RETURN_PENDING".equals(asset.getStatus()))
            throw BusinessException.conflict("回收中的资产不能修改");
        apply(asset, request);
        asset.setUpdatedBy(SecurityContextHelper.currentUserId());
        mapper.updateAsset(asset);
        return reveal(mapper.findAsset(id));
    }

    /** 删除未分配资产。 */
    @Transactional
    public void deleteAsset(Long id) {
        requireAsset(id);
        if (mapper.softDeleteAsset(
                        id, System.currentTimeMillis(), SecurityContextHelper.currentUserId())
                != 1) throw BusinessException.conflict("仅可删除未分配资产");
    }

    /** 查询审批配置。 */
    public List<ApprovalConfig> configs() {
        return mapper.findConfigs();
    }

    /** 保存资产类型的审批配置。 */
    @Transactional
    public ApprovalConfig saveConfig(AssetRequests.ApprovalConfigSave request) {
        String type = requireType(request.assetType());
        if (mapper.countActiveUser(request.approverId()) != 1)
            throw BusinessException.conflict("审批人不存在或已停用");
        ApprovalConfig config = new ApprovalConfig();
        config.setAssetType(type);
        config.setApproverId(request.approverId());
        config.setApproverName(request.approverName().trim());
        config.setCcUserIds(request.ccUserIds());
        mapper.upsertConfig(config, SecurityContextHelper.currentUserId());
        return mapper.findConfig(type);
    }

    /** 软删除审批配置，已提交申请继续使用其历史快照。 */
    @Transactional
    public void deleteApprovalConfig(Long id) {
        if (mapper.softDeleteConfig(
                        id, System.currentTimeMillis(), SecurityContextHelper.currentUserId())
                != 1) throw BusinessException.notFound("审批配置");
    }

    /** 查询审批配置分组，包含暂时没有审批配置的空分组。 */
    public List<AssetViews.ApprovalGroupView> approvalGroups() {
        return mapper.findApprovalGroups().stream().map(this::toGroupView).toList();
    }

    /** 新建审批配置分组，新分组默认排在现有分组末尾。 */
    @Transactional
    public AssetViews.ApprovalGroupView createApprovalGroup(
            AssetRequests.ApprovalGroupCreate request) {
        ApprovalGroup group = new ApprovalGroup();
        group.setName(request.name().trim());
        group.setSortOrder(mapper.findMaxApprovalGroupSortOrder() + 10);
        try {
            mapper.insertApprovalGroup(group, SecurityContextHelper.currentUserId());
        } catch (DuplicateKeyException exception) {
            throw BusinessException.conflict("分组名称已存在");
        }
        return toGroupView(requireApprovalGroup(group.getId()));
    }

    /** 保存完整分组顺序；拒绝缺失、重复或已过期的分组 ID，防止并发覆盖。 */
    @Transactional
    public List<AssetViews.ApprovalGroupView> reorderApprovalGroups(
            AssetRequests.ApprovalGroupOrder request) {
        Set<Long> activeIds =
                mapper.findApprovalGroups().stream()
                        .map(ApprovalGroup::getId)
                        .collect(Collectors.toSet());
        LinkedHashSet<Long> requestedIds = new LinkedHashSet<>(request.groupIds());
        if (requestedIds.size() != request.groupIds().size() || !requestedIds.equals(activeIds)) {
            throw BusinessException.conflict("分组数据已变化，请刷新后重试");
        }
        Long operatorId = SecurityContextHelper.currentUserId();
        for (int index = 0; index < request.groupIds().size(); index++) {
            if (mapper.updateApprovalGroupSortOrder(
                            request.groupIds().get(index), (index + 1) * 10, operatorId)
                    != 1) {
                throw BusinessException.conflict("分组数据已变化，请刷新后重试");
            }
        }
        return approvalGroups();
    }

    /** 删除空分组；分组内仍有审批配置时必须先移动配置。 */
    @Transactional
    public void deleteApprovalGroup(Long id) {
        requireApprovalGroup(id);
        if (mapper.countConfigsByGroup(id) > 0) {
            throw BusinessException.conflict("该分组下仍有审批配置，请先移动后再删除");
        }
        if (mapper.softDeleteApprovalGroup(
                        id, System.currentTimeMillis(), SecurityContextHelper.currentUserId())
                != 1) {
            throw BusinessException.notFound("审批分组");
        }
    }

    /** 获取有效审批分组，供审批配置保存时校验并使用服务端标准名称。 */
    public ApprovalGroup requireApprovalGroup(Long id) {
        ApprovalGroup group = id == null ? null : mapper.findApprovalGroup(id);
        if (group == null) throw BusinessException.conflict("审批分组不存在或已删除");
        return group;
    }

    private AssetViews.ApprovalGroupView toGroupView(ApprovalGroup group) {
        return new AssetViews.ApprovalGroupView(
                group.getId().toString(),
                group.getName(),
                group.getSortOrder(),
                group.getUpdatedAt());
    }

    /** 提交当前用户的资源申请。 */
    @Transactional
    public AssetApplication apply(AssetRequests.ApplicationCreate request) {
        String type = requireType(request.assetType());
        ApprovalConfig config = mapper.findConfig(type);
        if (config == null) throw BusinessException.conflict("该资产类型尚未配置审批人");
        CurrentUser user = SecurityContextHelper.currentUser();
        AssetApplication application = new AssetApplication();
        application.setApplicationNo(
                "AST"
                        + LocalDateTime.now()
                                .format(DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS")));
        application.setAssetType(type);
        application.setTitle(request.title().trim());
        application.setQuantity(request.quantity());
        application.setReason(request.reason().trim());
        application.setRequesterId(user.userId());
        application.setRequesterName(user.displayName());
        application.setApproverId(config.getApproverId());
        application.setApproverName(config.getApproverName());
        mapper.insertApplication(application, user.userId());
        mapper.insertApprovalLog(
                application.getId(),
                "SUBMITTED",
                user.userId(),
                user.displayName(),
                request.reason());
        return mapper.findApplication(application.getId());
    }

    /** 查询当前用户发起的申请。 */
    public List<AssetApplication> myApplications() {
        return mapper.findApplications(SecurityContextHelper.currentUserId(), null);
    }

    /** 查询当前用户负责审批的申请。 */
    public List<AssetApplication> approvals() {
        return mapper.findApplications(null, SecurityContextHelper.currentUserId());
    }

    /** 审批通过并原子分配足量库存。 */
    @Transactional
    public AssetApplication approve(Long id, AssetRequests.Decision request) {
        AssetApplication application = requirePendingApprover(id);
        List<MediaAsset> assets =
                mapper.lockAvailableAssets(application.getAssetType(), application.getQuantity());
        if (assets.size() < application.getQuantity())
            throw BusinessException.conflict("可用资产库存不足，当前仅有" + assets.size() + "个");
        Long operatorId = SecurityContextHelper.currentUserId();
        for (MediaAsset asset : assets)
            mapper.assignAsset(
                    asset.getId(),
                    id,
                    application.getRequesterId(),
                    application.getRequesterName(),
                    operatorId);
        decide(application, "APPROVED", request.remark());
        return mapper.findApplication(id);
    }

    /** 驳回资源申请。 */
    @Transactional
    public AssetApplication reject(Long id, AssetRequests.Decision request) {
        AssetApplication application = requirePendingApprover(id);
        decide(application, "REJECTED", request.remark());
        return mapper.findApplication(id);
    }

    private void decide(AssetApplication application, String status, String remark) {
        CurrentUser user = SecurityContextHelper.currentUser();
        if (mapper.decideApplication(application.getId(), status, remark, user.userId()) != 1)
            throw BusinessException.conflict("申请状态已变化，请刷新后重试");
        mapper.insertApprovalLog(
                application.getId(), status, user.userId(), user.displayName(), remark);
    }

    private AssetApplication requirePendingApprover(Long id) {
        AssetApplication value = mapper.findApplication(id);
        if (value == null) throw BusinessException.notFound("申请单");
        if (!"PENDING".equals(value.getStatus())) throw BusinessException.conflict("申请已处理");
        if (!SecurityContextHelper.currentUserId().equals(value.getApproverId()))
            throw BusinessException.conflict("当前用户不是该申请审批人");
        return value;
    }

    private MediaAsset requireAsset(Long id) {
        MediaAsset value = mapper.findAsset(id);
        if (value == null) throw BusinessException.notFound("资产");
        return value;
    }

    private MediaAsset apply(MediaAsset asset, AssetRequests.AssetSave request) {
        asset.setAssetType(requireType(request.assetType()));
        asset.setAssetName(request.assetName().trim());
        asset.setAssetCode(request.assetCode().trim());
        String channelId = textOrNull(request.channelId());
        String channelName = textOrNull(request.channelName());
        if (channelId == null) channelId = textOrNull(request.projectId());
        if (channelName == null) channelName = textOrNull(request.projectName());
        if (requiresChannel(asset.getAssetType(), request.secretData())
                && (channelId == null || channelName == null))
            throw BusinessException.validation("请选择资产归属渠道");
        // 办公资产、TG号和微信号不要求渠道；若调用方只传了一半渠道信息，则统一按未归属处理。
        if (channelId == null || channelName == null) {
            channelId = null;
            channelName = null;
        }
        asset.setChannelId(channelId);
        asset.setChannelName(channelName);
        // 迁移期镜像旧项目字段，确保历史审批分配逻辑仍可识别同一渠道归属。
        asset.setProjectId(channelId);
        asset.setProjectName(channelName);
        asset.setSecretData(
                request.secretData() == null || request.secretData().isBlank()
                        ? null
                        : secretCipher.encrypt(request.secretData()));
        asset.setRemark(request.remark());
        applyManualAssignment(asset, request.status(), request.assigneeId());
        return asset;
    }

    /** 校验手工分配状态，并使用系统用户表中的名称保存资产使用人。 */
    private void applyManualAssignment(MediaAsset asset, String requestedStatus, Long assigneeId) {
        String status =
                requestedStatus == null || requestedStatus.isBlank()
                        ? "AVAILABLE"
                        : requestedStatus.trim().toUpperCase(Locale.ROOT);
        if (!Set.of("AVAILABLE", "ASSIGNED", "DISABLED").contains(status))
            throw BusinessException.validation("库存状态不受支持");

        asset.setStatus(status);
        if (!"ASSIGNED".equals(status)) {
            asset.setApplicationId(null);
            asset.setAssigneeId(null);
            asset.setAssigneeName(null);
            return;
        }
        if (assigneeId == null || assigneeId <= 0) throw BusinessException.validation("请选择使用人");
        String assigneeName = mapper.findActiveUserName(assigneeId);
        if (assigneeName == null || assigneeName.isBlank())
            throw BusinessException.validation("请选择有效使用人");
        asset.setAssigneeId(assigneeId);
        asset.setAssigneeName(assigneeName);
    }

    private boolean requiresChannel(String assetType, String secretData) {
        if (Set.of("TG", "COMPUTER", "MOBILE", "STATIC_IP", "EMAIL").contains(assetType)) {
            return false;
        }
        if (!"PERSONAL".equals(assetType) || secretData == null || secretData.isBlank()) {
            return true;
        }
        Matcher matcher = INVENTORY_SUBTYPE_PATTERN.matcher(secretData);
        return !matcher.find() || !"wechat".equalsIgnoreCase(matcher.group(1).trim());
    }

    private List<MediaAsset> reveal(List<MediaAsset> assets) {
        assets.forEach(this::reveal);
        return assets;
    }

    private MediaAsset reveal(MediaAsset asset) {
        if (asset != null && asset.getSecretData() != null && !asset.getSecretData().isBlank())
            asset.setSecretData(secretCipher.decrypt(asset.getSecretData()));
        return asset;
    }

    private String typeOrNull(String type) {
        return type == null || type.isBlank() ? null : requireType(type);
    }

    private String textOrNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String requireType(String type) {
        String value = type == null ? "" : type.trim().toUpperCase();
        if (!TYPES.contains(value))
            throw BusinessException.validation("资产类型仅支持个号、BM、像素、TG、主页、电脑、手机、静态 IP、邮箱");
        return value;
    }
}
