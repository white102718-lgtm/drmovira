package com.adpulse.system.auth.dto;

import jakarta.validation.constraints.NotBlank;

/** 登录请求。 */
public record LoginRequest(
        @NotBlank(message = "登录账号不能为空") String identifier,
        @NotBlank(message = "密码不能为空") String password) {}
