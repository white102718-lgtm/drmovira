package com.adpulse.system.asset.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import com.adpulse.system.common.exception.BusinessException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;

/** 资产审批节点多人或角色授权测试。 */
@ExtendWith(MockitoExtension.class)
class AssetApprovalPrincipalServiceTest {
    @Mock private JdbcTemplate jdbc;
    private AssetApprovalPrincipalService service;

    @BeforeEach
    void setUp() {
        service = new AssetApprovalPrincipalService(jdbc);
    }

    @Test
    void shouldAllowAnyConfiguredUserToApprove() {
        when(jdbc.queryForList(anyString(), any(Object[].class)))
                .thenReturn(
                        List.of(
                                Map.of("id", 11L, "displayName", "甲"),
                                Map.of("id", 12L, "displayName", "乙")));
        Map<String, Object> node = new LinkedHashMap<>();
        node.put("approverType", "USERS");
        node.put("approverIds", List.of("11", "12"));

        AssetApprovalPrincipalService.NodePrincipal principal = service.normalizeAndResolve(node);

        assertThat(principal.eligibleUserIds()).containsExactly(11L, 12L);
        assertThat(service.canApprove(node, 12L)).isTrue();
        assertThat(node.get("approverName")).isEqualTo("甲、乙");
    }

    @Test
    void shouldResolveCurrentActiveMembersForRoles() {
        when(jdbc.queryForList(anyString(), any(Object[].class)))
                .thenReturn(List.of(Map.of("id", 21L, "roleName", "媒介负责人")));
        when(jdbc.queryForList(anyString(), eq(Long.class), any(Object[].class)))
                .thenReturn(List.of(101L, 102L));
        Map<String, Object> node = new LinkedHashMap<>();
        node.put("approverType", "ROLES");
        node.put("roleIds", List.of("21"));

        AssetApprovalPrincipalService.NodePrincipal principal = service.normalizeAndResolve(node);

        assertThat(principal.eligibleUserIds()).containsExactly(101L, 102L);
        assertThat(service.canApprove(node, 102L)).isTrue();
        assertThat(node.get("approverName")).isEqualTo("角色：媒介负责人（2人）");
    }

    @Test
    void shouldRejectUserOutsideCurrentNodeScope() {
        when(jdbc.queryForList(anyString(), any(Object[].class)))
                .thenReturn(List.of(Map.of("id", 11L, "displayName", "甲")));
        Map<String, Object> node = new LinkedHashMap<>();
        node.put("approverType", "USERS");
        node.put("approverIds", List.of("11"));

        assertThatThrownBy(() -> service.requireCanApprove(node, 99L))
                .isInstanceOf(BusinessException.class)
                .hasMessage("您不是当前节点的审批人或角色成员");
    }
}
