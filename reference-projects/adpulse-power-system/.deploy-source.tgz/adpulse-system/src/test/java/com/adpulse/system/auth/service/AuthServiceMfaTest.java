package com.adpulse.system.auth.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.adpulse.system.auth.dto.LoginRequest;
import com.adpulse.system.auth.dto.LoginResponse;
import com.adpulse.system.auth.mapper.AuthMapper;
import com.adpulse.system.auth.model.ServerSession;
import com.adpulse.system.config.SecurityProperties;
import com.adpulse.system.loginlog.model.LoginAuthStage;
import com.adpulse.system.loginlog.service.LoginLogService;
import com.adpulse.system.user.model.UserAccount;
import java.time.Duration;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.security.crypto.password.PasswordEncoder;

/** 登录MFA分流和正式会话创建时机测试。 */
class AuthServiceMfaTest {

    private final AuthMapper authMapper = mock(AuthMapper.class);
    private final PasswordEncoder passwordEncoder = mock(PasswordEncoder.class);
    private final IpAccessService ipAccessService = mock(IpAccessService.class);
    private final SessionStore sessionStore = mock(SessionStore.class);
    private final JwtService jwtService = mock(JwtService.class);
    private final MfaChallengeStore challengeStore = mock(MfaChallengeStore.class);
    private final MfaSecretCipher secretCipher = mock(MfaSecretCipher.class);
    private final TotpService totpService = mock(TotpService.class);
    private final LoginLogService loginLogService = mock(LoginLogService.class);

    private AuthService service;
    private UserAccount user;

    @BeforeEach
    void setUp() {
        service =
                new AuthService(
                        authMapper,
                        passwordEncoder,
                        ipAccessService,
                        sessionStore,
                        jwtService,
                        new SecurityProperties("jwt-secret", "issuer", Duration.ofHours(8)),
                        challengeStore,
                        secretCipher,
                        totpService,
                        loginLogService);
        user = new UserAccount();
        user.setId(1L);
        user.setUsername("admin");
        user.setPasswordHash("hash");
        user.setDisplayName("系统管理员");
        user.setEnglishNickname("Admin");
        user.setPrimaryDepartmentId(10L);
        user.setStatus(1);
        when(authMapper.findLoginUser("admin")).thenReturn(user);
        when(passwordEncoder.matches("password", "hash")).thenReturn(true);
        when(ipAccessService.isAllowed(user, "127.0.0.1")).thenReturn(true);
    }

    @Test
    void shouldRequireBindingWithoutCreatingFormalSession() {
        user.setMfaStatus(0);
        when(totpService.generateSecret()).thenReturn("BASE32SECRET");
        when(secretCipher.encrypt("BASE32SECRET")).thenReturn("ciphertext");
        when(challengeStore.create(any())).thenReturn("challenge-token");
        when(challengeStore.ttlSeconds()).thenReturn(300L);
        when(totpService.buildOtpAuthUri("admin", "BASE32SECRET")).thenReturn("otpauth://uri");

        LoginResponse response =
                service.login(new LoginRequest("admin", "password"), "127.0.0.1", "test-agent");

        assertThat(response.loginStatus()).isEqualTo("MFA_BIND_REQUIRED");
        assertThat(response.challengeToken()).isEqualTo("challenge-token");
        assertThat(response.mfaSecret()).isEqualTo("BASE32SECRET");
        verify(sessionStore, never()).save(any(ServerSession.class));
        verify(authMapper, never()).recordLoginSuccess(anyLong(), any(), any());
        verify(loginLogService, never()).recordSuccess(any(), any(), any(), any(), any());
    }

    @Test
    void shouldCreateFormalSessionWhenMfaIsDisabled() {
        user.setMfaStatus(-1);
        when(authMapper.findPermissionCodes(1L)).thenReturn(List.of("system:user:list"));
        when(authMapper.findPrimaryDepartmentName(10L)).thenReturn("总部");
        when(authMapper.findActiveRoles(1L))
                .thenReturn(List.of(new AuthMapper.UserRoleView(20L, "admin", "管理员")));
        when(jwtService.issue(anyLong(), any())).thenReturn("jwt");

        LoginResponse response =
                service.login(new LoginRequest("admin", "password"), "127.0.0.1", "test-agent");

        assertThat(response.loginStatus()).isEqualTo("SUCCESS");
        assertThat(response.accessToken()).isEqualTo("jwt");
        ArgumentCaptor<ServerSession> sessionCaptor = ArgumentCaptor.forClass(ServerSession.class);
        verify(sessionStore).save(sessionCaptor.capture());
        ServerSession session = sessionCaptor.getValue();
        assertThat(session.englishNickname()).isEqualTo("Admin");
        assertThat(session.departmentId()).isEqualTo(10L);
        assertThat(session.departmentName()).isEqualTo("总部");
        assertThat(session.roleIds()).containsExactly(20L);
        assertThat(session.roleCodes()).containsExactly("admin");
        assertThat(session.roleNames()).containsExactly("管理员");
        verify(authMapper).recordLoginSuccess(anyLong(), any(), any());
        verify(loginLogService)
                .recordSuccess(user, "admin", LoginAuthStage.PASSWORD, "127.0.0.1", "test-agent");
    }

    @Test
    void shouldRecordPasswordAuthenticationFailure() {
        user.setMfaStatus(-1);
        when(passwordEncoder.matches("wrong-password", "hash")).thenReturn(false);

        assertThatThrownBy(
                        () ->
                                service.login(
                                        new LoginRequest("admin", "wrong-password"),
                                        "127.0.0.1",
                                        "test-agent"))
                .hasMessage("账号或密码错误");

        verify(loginLogService)
                .recordFailure(
                        eq(user),
                        eq("admin"),
                        eq(LoginAuthStage.PASSWORD),
                        any(),
                        eq("127.0.0.1"),
                        eq("test-agent"));
    }
}
