package com.adpulse.system.asset.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.adpulse.system.asset.dto.AssetRequests;
import com.adpulse.system.asset.mapper.AssetMapper;
import com.adpulse.system.asset.model.ApprovalGroup;
import com.adpulse.system.asset.model.MediaAsset;
import com.adpulse.system.auth.service.MfaSecretCipher;
import com.adpulse.system.common.exception.BusinessException;
import com.adpulse.system.common.security.CurrentUser;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

/** 资产与审批配置业务规则测试。 */
@ExtendWith(MockitoExtension.class)
class AssetServiceTest {

    @Mock private AssetMapper mapper;
    @Mock private MfaSecretCipher secretCipher;

    private AssetService service;

    @BeforeEach
    void setUp() {
        CurrentUser user = new CurrentUser(7L, "session", "测试用户", List.of());
        SecurityContextHolder.getContext()
                .setAuthentication(new UsernamePasswordAuthenticationToken(user, "", List.of()));
        service = new AssetService(mapper, secretCipher);
    }

    @AfterEach
    void clearCurrentUser() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void shouldSoftDeleteApprovalConfigWithCurrentOperator() {
        when(mapper.softDeleteConfig(eq(31L), anyLong(), eq(7L))).thenReturn(1);

        service.deleteApprovalConfig(31L);

        verify(mapper).softDeleteConfig(eq(31L), anyLong(), eq(7L));
    }

    @Test
    void shouldRejectDeletingMissingApprovalConfig() {
        when(mapper.softDeleteConfig(eq(31L), anyLong(), eq(7L))).thenReturn(0);

        assertThatThrownBy(() -> service.deleteApprovalConfig(31L))
                .isInstanceOf(BusinessException.class)
                .hasMessage("审批配置不存在");
    }

    @Test
    void shouldRejectDeletingNonEmptyApprovalGroup() {
        ApprovalGroup group = new ApprovalGroup();
        group.setId(8L);
        group.setName("媒介与资源");
        when(mapper.findApprovalGroup(8L)).thenReturn(group);
        when(mapper.countConfigsByGroup(8L)).thenReturn(2);

        assertThatThrownBy(() -> service.deleteApprovalGroup(8L))
                .isInstanceOf(BusinessException.class)
                .hasMessage("该分组下仍有审批配置，请先移动后再删除");
    }

    @Test
    void shouldRejectStaleApprovalGroupOrder() {
        ApprovalGroup group = new ApprovalGroup();
        group.setId(8L);
        when(mapper.findApprovalGroups()).thenReturn(List.of(group));

        assertThatThrownBy(
                        () ->
                                service.reorderApprovalGroups(
                                        new AssetRequests.ApprovalGroupOrder(List.of(8L, 9L))))
                .isInstanceOf(BusinessException.class)
                .hasMessage("分组数据已变化，请刷新后重试");
    }

    @ParameterizedTest
    @ValueSource(
            strings = {
                "PERSONAL",
                "BM",
                "PIXEL",
                "TG",
                "PAGE",
                "COMPUTER",
                "MOBILE",
                "STATIC_IP",
                "EMAIL"
            })
    void shouldSupportAllInventoryAssetTypes(String assetType) {
        when(mapper.findAssets(assetType, null, null)).thenReturn(List.of());

        service.assets(assetType, null);

        verify(mapper).findAssets(assetType, null, null);
    }

    @Test
    void shouldResolveSocialApplicationToInventoryTypeAndSubtype() {
        AssetService.InventorySelection selection =
                service.resolveInventorySelection(
                        "TG",
                        Map.of("socialAssetType", "微信号"),
                        Map.of("assetTypeFieldKey", "socialAssetType"));

        assertThat(selection.assetType()).isEqualTo("PERSONAL");
        assertThat(selection.subtype()).isEqualTo("wechat");
    }

    @Test
    void shouldMatchEncryptedPersonalInventorySubtype() {
        when(secretCipher.decrypt("encrypted")).thenReturn("{\"inventorySubtype\":\"wechat\"}");

        assertThat(service.matchesInventorySubtype("encrypted", "wechat")).isTrue();
        assertThat(service.matchesInventorySubtype("encrypted", "personal")).isFalse();
        assertThat(service.matchesInventorySubtype(null, "personal")).isTrue();
    }

    @ParameterizedTest
    @ValueSource(strings = {"COMPUTER", "MOBILE", "STATIC_IP", "EMAIL", "TG"})
    void shouldCreateChannelIndependentAssetWithoutChannel(String assetType) {
        service.createAsset(
                new AssetRequests.AssetSave(
                        assetType,
                        "E2E测试资产",
                        "E2E-001",
                        null,
                        null,
                        null,
                        null,
                        null,
                        "测试库存",
                        "AVAILABLE",
                        null));

        verify(mapper).insertAsset(any());
    }

    @Test
    void shouldCreateWechatAssetWithoutChannel() {
        when(secretCipher.encrypt("{\"inventorySubtype\":\"wechat\"}")).thenReturn("encrypted");

        service.createAsset(
                new AssetRequests.AssetSave(
                        "PERSONAL",
                        "E2E测试微信",
                        "wechat-e2e-001",
                        null,
                        null,
                        null,
                        null,
                        "{\"inventorySubtype\":\"wechat\"}",
                        "测试库存",
                        "AVAILABLE",
                        null));

        verify(mapper).insertAsset(any());
    }

    @Test
    void shouldStillRequireChannelForPageAsset() {
        assertThatThrownBy(
                        () ->
                                service.createAsset(
                                        new AssetRequests.AssetSave(
                                                "PAGE",
                                                "E2E测试主页",
                                                "page-e2e-001",
                                                null,
                                                null,
                                                null,
                                                null,
                                                null,
                                                "测试库存",
                                                "AVAILABLE",
                                                null)))
                .isInstanceOf(BusinessException.class)
                .hasMessage("请选择资产归属渠道");
    }

    @Test
    void shouldCreateAssignedAssetWithCanonicalActiveUserName() {
        when(mapper.findActiveUserName(12L)).thenReturn("张三");

        service.createAsset(
                new AssetRequests.AssetSave(
                        "COMPUTER",
                        "设计电脑",
                        "PC-001",
                        null,
                        null,
                        null,
                        null,
                        null,
                        "测试库存",
                        "ASSIGNED",
                        12L));

        verify(mapper)
                .insertAsset(
                        org.mockito.ArgumentMatchers.argThat(
                                asset ->
                                        "ASSIGNED".equals(asset.getStatus())
                                                && Long.valueOf(12L).equals(asset.getAssigneeId())
                                                && "张三".equals(asset.getAssigneeName())));
    }

    @Test
    void shouldRejectAssignedAssetWithoutActiveUser() {
        assertThatThrownBy(
                        () ->
                                service.createAsset(
                                        new AssetRequests.AssetSave(
                                                "COMPUTER",
                                                "设计电脑",
                                                "PC-001",
                                                null,
                                                null,
                                                null,
                                                null,
                                                null,
                                                "测试库存",
                                                "ASSIGNED",
                                                12L)))
                .isInstanceOf(BusinessException.class)
                .hasMessage("请选择有效使用人");
    }

    @Test
    void shouldAllowEditingAssignedAssetAndClearUserWhenAvailable() {
        MediaAsset asset = new MediaAsset();
        asset.setId(21L);
        asset.setStatus("ASSIGNED");
        asset.setAssigneeId(12L);
        asset.setAssigneeName("张三");
        when(mapper.findAsset(21L)).thenReturn(asset);

        service.updateAsset(
                21L,
                new AssetRequests.AssetSave(
                        "COMPUTER",
                        "设计电脑",
                        "PC-001",
                        null,
                        null,
                        null,
                        null,
                        null,
                        "测试库存",
                        "AVAILABLE",
                        null));

        verify(mapper)
                .updateAsset(
                        org.mockito.ArgumentMatchers.argThat(
                                value ->
                                        "AVAILABLE".equals(value.getStatus())
                                                && value.getAssigneeId() == null
                                                && value.getAssigneeName() == null));
    }
}
