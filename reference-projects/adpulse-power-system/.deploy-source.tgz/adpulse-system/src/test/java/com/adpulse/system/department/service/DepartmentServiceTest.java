package com.adpulse.system.department.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import com.adpulse.system.department.mapper.DepartmentMapper;
import com.adpulse.system.department.model.Department;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/** 部门树组装测试。 */
@ExtendWith(MockitoExtension.class)
class DepartmentServiceTest {

    @Mock private DepartmentMapper mapper;
    @InjectMocks private DepartmentService service;

    @Test
    void shouldBuildDepartmentTree() {
        Department root = department(1L, 0L, "总部");
        Department child = department(2L, 1L, "增长中心");
        when(mapper.findAllActive()).thenReturn(List.of(root, child));

        List<Department> tree = service.tree();

        assertThat(tree).hasSize(1);
        assertThat(tree.getFirst().getChildren())
                .extracting(Department::getDeptName)
                .containsExactly("增长中心");
    }

    private Department department(Long id, Long parentId, String name) {
        Department department = new Department();
        department.setId(id);
        department.setParentId(parentId);
        department.setDeptName(name);
        return department;
    }
}
