package com.adpulse.system.menu.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.adpulse.system.menu.dto.UserMenuRoute;
import com.adpulse.system.menu.mapper.MenuMapper;
import com.adpulse.system.menu.model.Menu;
import java.util.List;
import org.junit.jupiter.api.Test;

/** 当前用户角色菜单树和前端路由映射测试。 */
class MenuServiceTest {

    private final MenuMapper mapper = mock(MenuMapper.class);
    private final MenuService service = new MenuService(mapper);

    @Test
    void shouldBuildVbenRouteTreeForCurrentUser() {
        Menu root = menu(1L, 0L, 1, "SYSTEM", "系统管理", null, null);
        root.setIcon("lucide:shield-check");
        root.setSortOrder(10);
        Menu child = menu(2L, 1L, 2, "SYSTEM_USER", "用户管理", "/system/user", "system/user/list");
        child.setPermissionCode("system:user:list");
        child.setCacheable(1);
        when(mapper.findAuthorizedNavigationMenus(7L)).thenReturn(List.of(root, child));

        List<UserMenuRoute> routes = service.userMenuTree(7L);

        assertThat(routes).hasSize(1);
        UserMenuRoute rootRoute = routes.getFirst();
        assertThat(rootRoute.path()).isEqualTo("/system");
        assertThat(rootRoute.type()).isEqualTo("catalog");
        assertThat(rootRoute.children()).hasSize(1);
        UserMenuRoute childRoute = rootRoute.children().getFirst();
        assertThat(childRoute.component()).isEqualTo("/system/user/list");
        assertThat(childRoute.authCode()).isEqualTo("system:user:list");
        assertThat(childRoute.meta().keepAlive()).isTrue();
        verify(mapper).findAuthorizedNavigationMenus(7L);
    }

    @Test
    void shouldReturnEmptyRoutesWhenUserHasNoRoleMenus() {
        when(mapper.findAuthorizedNavigationMenus(8L)).thenReturn(List.of());

        assertThat(service.userMenuTree(8L)).isEmpty();
    }

    private Menu menu(
            Long id,
            Long parentId,
            int menuType,
            String menuCode,
            String menuName,
            String routePath,
            String component) {
        Menu menu = new Menu();
        menu.setId(id);
        menu.setParentId(parentId);
        menu.setMenuType(menuType);
        menu.setMenuCode(menuCode);
        menu.setMenuName(menuName);
        menu.setRoutePath(routePath);
        menu.setComponent(component);
        menu.setVisible(1);
        menu.setCacheable(0);
        menu.setSortOrder(0);
        return menu;
    }
}
