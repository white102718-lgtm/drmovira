package com.adpulse.system.user.service;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.adpulse.system.auth.service.SessionStore;
import com.adpulse.system.common.exception.BusinessException;
import com.adpulse.system.common.security.CurrentUser;
import com.adpulse.system.user.dto.UserProfileUpdateRequest;
import com.adpulse.system.user.dto.UserSaveRequest;
import com.adpulse.system.user.mapper.UserMapper;
import com.adpulse.system.user.model.UserAccount;
import java.util.Set;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;

/** 用户保存安全策略测试。 */
@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock private UserMapper mapper;
    @Mock private PasswordEncoder passwordEncoder;
    @Mock private SessionStore sessionStore;
    @InjectMocks private UserService service;

    @BeforeEach
    void setCurrentUser() {
        CurrentUser user = new CurrentUser(7L, "session", "测试用户", Set.of());
        SecurityContextHolder.getContext()
                .setAuthentication(new UsernamePasswordAuthenticationToken(user, "", Set.of()));
    }

    @AfterEach
    void clearCurrentUser() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void shouldRejectGlobalOnlyModeWhenNoGlobalRuleExists() {
        when(mapper.countActiveGlobalIpRules()).thenReturn(0);

        assertThatThrownBy(() -> service.create(requestWithIpMode(1)))
                .isInstanceOf(BusinessException.class)
                .hasMessage("仅通用白名单模式至少需要一条通用IP规则");
    }

    @Test
    void shouldRejectProfilePasswordChangeWhenOldPasswordIsWrong() {
        UserAccount user = new UserAccount();
        user.setId(7L);
        user.setPasswordHash("hash");
        when(mapper.findById(7L)).thenReturn(user);
        when(passwordEncoder.matches("wrong-password", "hash")).thenReturn(false);

        assertThatThrownBy(
                        () ->
                                service.updateCurrentProfile(
                                        new UserProfileUpdateRequest(
                                                "新名称",
                                                null,
                                                null,
                                                null,
                                                null,
                                                "wrong-password",
                                                "new-password")))
                .isInstanceOf(BusinessException.class)
                .hasMessage("旧密码不正确");

        verify(mapper, never()).updateProfile(user);
        verify(sessionStore, never()).revokeUser(7L);
    }

    private UserSaveRequest requestWithIpMode(int ipAccessMode) {
        return new UserSaveRequest(
                "test_user",
                "13800000000",
                "password123",
                "测试用户",
                null,
                null,
                null,
                null,
                null,
                1,
                ipAccessMode,
                null,
                Set.of(),
                Set.of(),
                Set.of());
    }
}
