# AdPulse System Server Agent Rules

Before modifying this repository, read `.codex/skills/adpulse-system-backend/SKILL.md`. Read its referenced architecture or database document when the change touches that area.

Non-negotiable rules:

- Do not add database foreign keys. Enforce references in transactional services.
- Use `deleted_at = 0` for active rows and Unix epoch milliseconds for soft-deleted rows.
- Keep controllers thin and put authorization and business invariants in services.
- Treat JWT as a session credential; every authenticated request must also resolve an active Redis session.
- Add Chinese Javadoc to public types and non-obvious public methods.
- Format Java with Spotless/Google Java Format and keep mapper XML consistently indented.
- Never persist or log plaintext passwords, JWT secrets, MFA secrets, or full tokens.
