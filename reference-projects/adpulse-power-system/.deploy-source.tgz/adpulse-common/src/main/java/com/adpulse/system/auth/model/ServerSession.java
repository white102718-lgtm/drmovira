package com.adpulse.system.auth.model;

import java.time.Instant;
import java.util.Set;

/** Redis 中保存的权威登录会话。 */
public record ServerSession(
        String sessionId,
        Long userId,
        String displayName,
        String englishNickname,
        Long departmentId,
        String departmentName,
        Set<Long> roleIds,
        Set<String> roleCodes,
        Set<String> roleNames,
        String loginIp,
        Set<String> permissions,
        Instant createdAt) {}
