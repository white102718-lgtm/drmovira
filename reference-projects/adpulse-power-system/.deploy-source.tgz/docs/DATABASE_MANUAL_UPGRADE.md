# 数据库手工升级说明

应用不会自动执行数据库结构变更。每次部署新版应用前，数据库管理员必须按版本号审核并手工执行尚未执行的 SQL 脚本。

## V4：删除旧版 MFA 开关

当前认证逻辑只使用 `mfa_status`：

- `-1`：不要求 MFA，密码验证通过后直接登录。
- `0`：要求 MFA，用户尚未绑定。
- `1`：已绑定 MFA，登录时验证动态码。

旧字段 `mfa_enabled` 已不被 Java、Mapper 或接口使用。执行 V3 后，旧字段的数据已经转换到 `mfa_status`，因此可以删除。

### 执行前检查

```sql
SHOW COLUMNS FROM sys_user LIKE 'mfa_status';

SELECT mfa_status, COUNT(*) AS user_count
FROM sys_user
GROUP BY mfa_status
ORDER BY mfa_status;
```

第一条查询必须返回 `mfa_status` 字段，第二条查询中的状态只能是 `-1`、`0`、`1`。建议执行前备份 `sys_user` 表。

### 执行升级

在项目目录执行：

```bash
mysql -h 127.0.0.1 -P 3306 -u adpulse -p adpulse_system \
  < adpulse-system/src/main/resources/db/migration/V4__drop_legacy_mfa_enabled.sql
```

V4 脚本的实际内容是：

```sql
ALTER TABLE sys_user
    DROP CHECK ck_user_mfa_enabled,
    DROP COLUMN mfa_enabled;
```

该脚本只执行一次。已经完成 V1、V2、V3 的现有数据库只需要执行 V4，不要重复执行旧脚本。

### 执行后验证

```sql
SHOW COLUMNS FROM sys_user LIKE 'mfa_enabled';
SHOW COLUMNS FROM sys_user LIKE 'mfa_status';
SHOW CREATE TABLE sys_user;
```

预期结果：第一条查询返回空，第二条返回 `mfa_status`，建表语句中不再出现 `ck_user_mfa_enabled`。

执行完成并验证无误后，再启动或更新 Java 服务。由于当前后端不读取 `mfa_enabled`，删除字段不需要额外修改接口参数。

## V5：增加登录审计日志

执行以下脚本创建 `sys_login_log`、增加 `system:login-log:list` 权限并授权给有效的 `ADMIN` 角色：

```bash
mysql -h 127.0.0.1 -P 3306 -u adpulse -p adpulse_system \
  < adpulse-system/src/main/resources/db/migration/V5__create_login_log.sql
```

执行后验证：

```sql
SHOW CREATE TABLE sys_login_log;

SELECT id, menu_code, permission_code
FROM sys_menu
WHERE menu_code = 'SYSTEM_LOGIN_LOG_LIST'
  AND deleted_at = 0;
```

V5 只执行一次。部署新版 Java 服务后，管理员需要重新登录，使 Redis 会话权限快照包含 `system:login-log:list`。接口字段和查询方式见 `LOGIN_LOG_API.md`。

## V6：增加操作审计日志

部署新版 Java 服务前执行：

```bash
mysql -h 127.0.0.1 -P 3306 -u adpulse -p adpulse_system \
  < adpulse-system/src/main/resources/db/migration/V6__create_operation_log.sql
```

执行后验证：

```sql
SHOW CREATE TABLE sys_operation_log;

SELECT id, menu_code, permission_code
FROM sys_menu
WHERE menu_code = 'SYSTEM_OPERATION_LOG_LIST'
  AND deleted_at = 0;
```

V6 只执行一次。该脚本创建操作审计表、增加 `system:operation-log:list` 权限并授权给有效的 `ADMIN` 角色。执行后管理员需要重新登录。接口说明见 `OPERATION_LOG_API.md`。

## V7：增加字典配置

部署新版 Java 服务前执行：

```bash
mysql -h 127.0.0.1 -P 3306 -u adpulse -p adpulse_system \
  < adpulse-system/src/main/resources/db/migration/V7__create_dictionary_tables.sql
```

执行后验证：

```sql
SHOW CREATE TABLE sys_dict_type;
SHOW CREATE TABLE sys_dict_item;

SELECT dict_code, dict_name, status
FROM sys_dict_type
WHERE dict_code = 'AD_MEDIA' AND deleted_at = 0;

SELECT menu_code, permission_code
FROM sys_menu
WHERE menu_code = 'SYSTEM_DICTIONARY' AND deleted_at = 0;
```

V7 只执行一次。脚本创建字典类型和字典项表，初始化投放媒体示例字典，增加字典管理菜单并授权给有效的 `ADMIN` 角色。执行后管理员需要重新登录，使 Redis 会话权限快照包含 `system:dictionary:list`。接口说明见 `DICTIONARY_API.md`。

## V7：增加资产申请审批流程

部署包含资产管理功能的新版服务前执行：

```bash
mysql -h 127.0.0.1 -P 3306 -u adpulse -p adpulse_system \
  < adpulse-system/src/main/resources/db/migration/V7__create_asset_approval_flow.sql
```

执行后验证：

```sql
SHOW CREATE TABLE media_asset;
SHOW CREATE TABLE media_approval_config;
SHOW CREATE TABLE media_asset_application;
SHOW CREATE TABLE media_asset_approval_log;
```

V7 只执行一次。脚本建立个号、BM、像素、TG 的统一库存、审批配置、申请单和审批轨迹。应用不会自动执行迁移；未手工执行该脚本时 `/asset-flow/**` 接口不可用。

## V8：增加项目管理与代理线

部署主业务服务前，审核并手工执行：

```bash
mysql -h 127.0.0.1 -P 3306 -u adpulse -p adpulse_system \
  < adpulse-main/src/main/resources/db/migration/V8__create_project_management_tables.sql
```

执行后验证：

```sql
SHOW CREATE TABLE pm_project;
SHOW CREATE TABLE pm_agency_line;
SHOW CREATE TABLE pm_project_platform;
SHOW CREATE TABLE pm_project_region;
SHOW CREATE TABLE pm_project_kpi;

SELECT item_value, item_label
FROM sys_dict_item
WHERE dict_type_id = (
    SELECT id FROM sys_dict_type
    WHERE dict_code = 'PROJECT_REGION' AND deleted_at = 0
)
AND deleted_at = 0
ORDER BY sort_order;
```

V8 只执行一次。脚本不创建数据库外键；项目、用户、字典和代理线引用均由事务服务校验。启动 `adpulse-main-server` 后，项目管理接口位于 `/api/main/fusion/**`。

## V9：增加渠道管理

部署主业务服务前，审核并手工执行表结构脚本：

```bash
mysql -h 127.0.0.1 -P 3306 -u adpulse -p adpulse_system \
  < adpulse-main/src/main/resources/db/migration/V9__create_channel_management_tables.sql
```

需要在测试环境初始化联调数据时，再执行演示数据脚本：

```bash
mysql -h 127.0.0.1 -P 3306 -u adpulse -p adpulse_system \
  < adpulse-main/src/main/resources/db/seed/channel_management_demo_data.sql
```

执行后验证：

```sql
SHOW CREATE TABLE media_channel;
SHOW CREATE TABLE media_channel_rate;
SHOW CREATE TABLE media_channel_account_type;
SHOW CREATE TABLE media_channel_account;
SHOW CREATE TABLE media_channel_goods;
SHOW CREATE TABLE media_channel_campaign_spend;

SELECT COUNT(*) FROM media_channel WHERE deleted_at = 0;
SELECT COUNT(*) FROM media_channel_account WHERE deleted_at = 0;
```

V9 只执行一次，不创建数据库外键。演示数据脚本使用 `990xxxx`、`7900xxxx` 等固定测试 ID，可重复执行。启动 `adpulse-main-server` 后，渠道管理接口位于 `/api/main/channels/**`、`/api/main/channel-accounts/**`。

演示数据脚本仅允许在隔离测试环境执行，不得用于共享测试、预发布或生产环境。若历史环境已误执行，部署前审核并手工执行 V18，将四条固定联调渠道停用，避免它们进入“系统渠道”下拉：

```bash
mysql -h 127.0.0.1 -P 3306 -u adpulse -p adpulse_system \
  < adpulse-main/src/main/resources/db/migration/V18__disable_channel_management_demo_channels.sql
```

执行后验证：

```sql
SELECT id, channel_name, channel_code, status
FROM media_channel
WHERE id IN (9900101, 9900102, 9900103, 9900104)
ORDER BY id;
```

四条记录的 `status` 应为 `0`；用户在渠道管理中创建的正常渠道不受影响。
