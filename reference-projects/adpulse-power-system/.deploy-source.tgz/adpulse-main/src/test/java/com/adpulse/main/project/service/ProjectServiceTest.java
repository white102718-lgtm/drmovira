package com.adpulse.main.project.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.when;

import com.adpulse.main.project.dto.ProjectRequests.AgencyLinePatch;
import com.adpulse.main.project.mapper.ProjectMapper;
import com.adpulse.main.project.model.AgencyLine;
import com.adpulse.main.project.model.Project;
import com.adpulse.main.project.model.ProjectOptionRow;
import com.adpulse.main.project.model.ProjectStatisticsRow;
import com.adpulse.system.common.security.CurrentUser;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

/** 项目状态及代理线归属规则测试。 */
@ExtendWith(MockitoExtension.class)
class ProjectServiceTest {
    @Mock private ProjectMapper mapper;

    private ProjectService service;

    @BeforeEach
    void setUp() {
        service = new ProjectService(mapper);
        CurrentUser user = new CurrentUser(9L, "session", "测试用户", List.of());
        SecurityContextHolder.getContext()
                .setAuthentication(new UsernamePasswordAuthenticationToken(user, "", List.of()));
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void shouldRejectBindingsForEndedProject() {
        Project project = project(1L, "ended");
        when(mapper.findProject(1L)).thenReturn(project);

        assertThatThrownBy(
                        () ->
                                service.patchAgencyLines(
                                        1L, new AgencyLinePatch(List.of("2"), List.of(), "r1")))
                .isInstanceOf(ProjectService.ProjectException.class)
                .hasMessageContaining("结束或归档");
    }

    @Test
    void shouldRejectAgencyLineAlreadyOwnedByAnotherProject() {
        Project project = project(1L, "active");
        AgencyLine line = new AgencyLine();
        line.setId(2L);
        line.setProjectId(3L);
        line.setLineName("Facebook主线");
        line.setPlatformValue("facebook");
        when(mapper.findProject(1L)).thenReturn(project);
        when(mapper.findAgencyLine(2L)).thenReturn(line);

        assertThatThrownBy(
                        () ->
                                service.patchAgencyLines(
                                        1L, new AgencyLinePatch(List.of("2"), List.of(), "r1")))
                .isInstanceOf(ProjectService.ProjectException.class)
                .hasMessageContaining("已关联其他项目");
    }

    @Test
    void shouldReturnLightweightProjectContext() {
        ProjectOptionRow facebook = optionRow(1L, "PRJ-1", "项目一", "active", "facebook");
        ProjectOptionRow google = optionRow(1L, "PRJ-1", "项目一", "active", "google");
        ProjectStatisticsRow statistics = new ProjectStatisticsRow();
        statistics.setTotal(4L);
        statistics.setActive(1L);
        statistics.setDraftOrPending(2L);
        statistics.setEndedOrArchived(1L);
        when(mapper.countProjectStatuses()).thenReturn(statistics);
        when(mapper.findProjectOptionRows()).thenReturn(List.of(facebook, google));

        var context = service.getProjectContext();

        assertThat(context.statistics().total()).isEqualTo(4);
        assertThat(context.statistics().draftOrPending()).isEqualTo(2);
        assertThat(context.options()).hasSize(1);
        assertThat(context.options().getFirst().platforms()).containsExactly("facebook", "google");
    }

    private ProjectOptionRow optionRow(
            Long id, String code, String name, String status, String platform) {
        ProjectOptionRow row = new ProjectOptionRow();
        row.setId(id);
        row.setProjectCode(code);
        row.setProjectName(name);
        row.setStatus(status);
        row.setPlatformValue(platform);
        return row;
    }

    private Project project(Long id, String status) {
        Project project = new Project();
        project.setId(id);
        project.setStatus(status);
        return project;
    }
}
