package com.adpulse.main.safeheron.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.adpulse.main.safeheron.dto.SafeheronRequests.ApproverSave;
import com.adpulse.main.safeheron.dto.SafeheronRequests.RuleQuery;
import com.adpulse.main.safeheron.dto.SafeheronRequests.RuleSave;
import com.adpulse.main.safeheron.mapper.SafeheronMapper;
import java.math.BigDecimal;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

/** Safeheron规则引用校验与分页边界测试。 */
@ExtendWith(MockitoExtension.class)
class SafeheronServiceTest {
    @Mock private SafeheronMapper mapper;

    private SafeheronService service;

    @BeforeEach
    void setUp() {
        service = new SafeheronService(mapper);
    }

    @Test
    void shouldNormalizeRulePagination() {
        when(mapper.findRules(0, 500)).thenReturn(List.of());
        when(mapper.countRules()).thenReturn(0L);

        var result = service.listRules(new RuleQuery(0, 9999));

        assertThat(result.page()).isEqualTo(1);
        assertThat(result.pageSize()).isEqualTo(500);
        verify(mapper).findRules(0, 500);
    }

    @Test
    void shouldRejectRuleWhenDepartmentIsUnavailable() {
        RuleSave request =
                new RuleSave(
                        9L,
                        "wallet-1",
                        "USDT_TRC20",
                        BigDecimal.TEN,
                        30,
                        1,
                        BigDecimal.ZERO,
                        BigDecimal.ONE,
                        "审批组",
                        1);

        assertThatThrownBy(() -> service.createRule(request))
                .isInstanceOf(SafeheronService.SafeheronException.class)
                .hasMessageContaining("部门");
        verify(mapper, never()).insertRule(org.mockito.ArgumentMatchers.any());
    }

    @Test
    void shouldValidateAllApproversBeforeUpdatingAnyTeam() {
        when(mapper.findTeam("team-a"))
                .thenReturn(new com.adpulse.main.safeheron.model.SafeheronModels.Team());

        assertThatThrownBy(() -> service.updateApprovers(List.of(new ApproverSave("team-a", 99L))))
                .isInstanceOf(SafeheronService.SafeheronException.class)
                .hasMessageContaining("审批用户");
        verify(mapper, never())
                .updateTeamApprover(
                        org.mockito.ArgumentMatchers.anyString(),
                        org.mockito.ArgumentMatchers.anyLong(),
                        org.mockito.ArgumentMatchers.anyLong());
    }
}
