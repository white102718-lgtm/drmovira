package com.adpulse.main.task.service;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.adpulse.main.task.dto.TaskRequests;
import com.adpulse.main.task.mapper.TaskMapper;
import com.adpulse.main.task.model.TaskModels;
import com.adpulse.system.common.security.CurrentUser;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

/** 任务角色权限和状态迁移测试。 */
@ExtendWith(MockitoExtension.class)
class TaskServiceTest {
    @Mock private TaskMapper mapper;
    private TaskService service;

    @BeforeEach
    void setUp() {
        service = new TaskService(mapper, new ObjectMapper());
        authenticate(9L, "创建者");
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void shouldRejectConfirmationByNonOwner() {
        when(mapper.findTaskForUpdate(1L))
                .thenReturn(task(1L, "DELIVERY", "PENDING_CONFIRMATION", 9L, 10L));

        assertThatThrownBy(() -> service.confirm(1L))
                .isInstanceOf(TaskService.TaskException.class)
                .hasMessageContaining("负责人");
    }

    @Test
    void shouldConfirmByOwnerWithOptimisticVersion() {
        authenticate(10L, "负责人");
        when(mapper.findTaskForUpdate(1L))
                .thenReturn(task(1L, "DELIVERY", "PENDING_CONFIRMATION", 9L, 10L));
        when(mapper.confirmTask(eq(1L), eq(10L), eq(0), any(LocalDateTime.class))).thenReturn(1);
        when(mapper.findTask(1L)).thenReturn(task(1L, "DELIVERY", "PROCESSING", 9L, 10L));
        when(mapper.findDeliveryPlatforms(1L)).thenReturn(List.of());
        when(mapper.findAllocations(1L)).thenReturn(List.of());
        when(mapper.findTaskFiles(1L)).thenReturn(List.of());
        when(mapper.findDeliverySubmissions(1L)).thenReturn(List.of());

        service.confirm(1L);

        verify(mapper).confirmTask(eq(1L), eq(10L), eq(0), any(LocalDateTime.class));
    }

    @Test
    void shouldAssignPendingTaskByCreator() {
        when(mapper.findTaskForUpdate(1L))
                .thenReturn(task(1L, "DELIVERY", "PENDING_ASSIGNMENT", 9L, null));
        when(mapper.findActiveUserName(10L)).thenReturn("负责人");
        when(mapper.assignTask(
                        eq(1L),
                        eq(9L),
                        eq(10L),
                        eq("负责人"),
                        eq(9L),
                        eq("创建者"),
                        any(LocalDateTime.class),
                        eq(0)))
                .thenReturn(1);
        when(mapper.findTask(1L)).thenReturn(task(1L, "DELIVERY", "PENDING_CONFIRMATION", 9L, 10L));
        when(mapper.findDeliveryPlatforms(1L)).thenReturn(List.of());
        when(mapper.findAllocations(1L)).thenReturn(List.of());
        when(mapper.findTaskFiles(1L)).thenReturn(List.of());
        when(mapper.findDeliverySubmissions(1L)).thenReturn(List.of());

        service.assign(1L, new TaskRequests.Assign("10"));

        verify(mapper)
                .assignTask(
                        eq(1L),
                        eq(9L),
                        eq(10L),
                        eq("负责人"),
                        eq(9L),
                        eq("创建者"),
                        any(LocalDateTime.class),
                        eq(0));
    }

    @Test
    void shouldPersistFollowForVisibleTask() {
        when(mapper.findTask(1L)).thenReturn(task(1L, "MATERIAL", "PROCESSING", 9L, 10L));
        when(mapper.countTaskFollow(1L, 9L)).thenReturn(0);

        service.follow(1L);

        verify(mapper).insertTaskFollow(1L, 9L);
    }

    @Test
    void shouldRequireReasonWhenRejectingSubmission() {
        assertThatThrownBy(() -> service.reject(1L, 2L, "delivery", new TaskRequests.Review("  ")))
                .isInstanceOf(TaskService.TaskException.class)
                .hasMessageContaining("原因");
    }

    @Test
    void shouldRejectDuplicateDeliveryTeams() {
        TaskRequests.BaseCreate base =
                new TaskRequests.BaseCreate(
                        "测试投放任务", "说明", "1", "10", "P2", LocalDateTime.now().plusDays(1));
        TaskRequests.DeliveryCreate request =
                new TaskRequests.DeliveryCreate(
                        base,
                        "https://example.com",
                        "US",
                        "获取用户",
                        LocalDateTime.now().plusHours(1),
                        List.of("FACEBOOK"),
                        List.of(
                                new TaskRequests.Allocation("MP", "10", 1, 0),
                                new TaskRequests.Allocation("MP", "11", 0, 1)),
                        List.of(),
                        null);
        when(mapper.findProjectName(1L)).thenReturn("项目");
        when(mapper.findActiveUserName(10L)).thenReturn("负责人");
        when(mapper.countEnabledDictionaryValues("TASK_PRIORITY", List.of("P2"))).thenReturn(1);

        assertThatThrownBy(() -> service.createDelivery(request))
                .isInstanceOf(TaskService.TaskException.class)
                .hasMessageContaining("不能重复");
    }

    private void authenticate(Long userId, String name) {
        CurrentUser user = new CurrentUser(userId, "session", name, List.of());
        SecurityContextHolder.getContext()
                .setAuthentication(new UsernamePasswordAuthenticationToken(user, "", List.of()));
    }

    private TaskModels.Task task(
            Long id, String type, String status, Long creatorId, Long ownerId) {
        TaskModels.Task task = new TaskModels.Task();
        task.setId(id);
        task.setTaskType(type);
        task.setStatus(status);
        task.setCreatorId(creatorId);
        task.setCreatorName("创建者");
        task.setOwnerId(ownerId);
        task.setOwnerName("负责人");
        task.setVersion(0);
        return task;
    }
}
