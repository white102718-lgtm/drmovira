package com.adpulse.main.channel.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.adpulse.main.channel.dto.ChannelRequests.AccountBatch;
import com.adpulse.main.channel.dto.ChannelRequests.AccountImportItem;
import com.adpulse.main.channel.dto.ChannelRequests.AccountQuery;
import com.adpulse.main.channel.dto.ChannelRequests.ChannelSave;
import com.adpulse.main.channel.dto.ChannelRequests.RateSave;
import com.adpulse.main.channel.mapper.ChannelMapper;
import com.adpulse.main.channel.model.ChannelModels.Account;
import com.adpulse.main.channel.model.ChannelModels.AccountType;
import com.adpulse.main.channel.model.ChannelModels.Channel;
import com.adpulse.system.common.security.CurrentUser;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;

/** 渠道费率、批量账户和导入校验测试。 */
@ExtendWith(MockitoExtension.class)
class ChannelServiceTest {
    @Mock private ChannelMapper mapper;
    @Mock private AccountSnapshotProvider accountSnapshotProvider;

    private ChannelService service;

    @BeforeEach
    void setUp() {
        service = new ChannelService(mapper, new ChannelExcelCodec(), accountSnapshotProvider);
        org.mockito.Mockito.lenient()
                .when(accountSnapshotProvider.findByAccountIds(any()))
                .thenReturn(java.util.Map.of());
        CurrentUser user = new CurrentUser(9L, "session", "测试用户", List.of());
        SecurityContextHolder.getContext()
                .setAuthentication(new UsernamePasswordAuthenticationToken(user, "", List.of()));
    }

    @AfterEach
    void tearDown() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void shouldRejectOverlappingRateRange() {
        Channel channel = new Channel();
        channel.setId(1L);
        when(mapper.findChannel(1L)).thenReturn(channel);
        when(mapper.countRateOverlaps(1L, null, LocalDate.of(2026, 8, 1), null)).thenReturn(1);

        RateSave request =
                new RateSave(
                        new BigDecimal("3.5"), new BigDecimal("2"), LocalDate.of(2026, 8, 1), null);

        assertThatThrownBy(() -> service.createRate(1L, request))
                .isInstanceOf(ChannelService.ChannelException.class)
                .hasMessageContaining("重叠");
    }

    @Test
    void shouldBuildPaymentContextFromYesterdaySpendAndChannelAddress() {
        Channel channel = new Channel();
        channel.setId(1L);
        channel.setChannelName("Meta 渠道");
        channel.setPaymentAddress("收款地址快照");
        when(mapper.findChannel(1L)).thenReturn(channel);
        when(mapper.sumChannelSpend(1L, LocalDate.now().minusDays(1)))
                .thenReturn(new BigDecimal("128.50"));

        var result = service.getPaymentContext(1L);

        assertThat(result.channelId()).isEqualTo("1");
        assertThat(result.channelYesterdayCost()).isEqualByComparingTo("128.50");
        assertThat(result.paymentAddress()).isEqualTo("收款地址快照");
    }

    @Test
    void shouldCreateAllBatchAccounts() {
        Channel channel = new Channel();
        channel.setId(1L);
        AccountType type = new AccountType();
        type.setId(2L);
        type.setAccountType("企业户");
        when(mapper.findChannel(1L)).thenReturn(channel);
        when(mapper.findAccountTypeByName("企业户")).thenReturn(type);

        service.batchCreateAccounts(
                new AccountBatch(
                        1L,
                        List.of(
                                new AccountImportItem("123", "企业户"),
                                new AccountImportItem("456", "企业户"))));

        ArgumentCaptor<Account> captor = ArgumentCaptor.forClass(Account.class);
        verify(mapper, org.mockito.Mockito.times(2)).insertAccount(captor.capture());
        assertThat(captor.getAllValues()).allMatch(account -> account.getAccountName() == null);
    }

    @Test
    void shouldEnrichAccountListFromSnapshotProvider() {
        Account account = new Account();
        account.setAccountId("123");
        account.setStatus(1);
        when(mapper.findAccounts(
                        any(),
                        org.mockito.ArgumentMatchers.eq(0),
                        org.mockito.ArgumentMatchers.eq(10)))
                .thenReturn(List.of(account));
        when(mapper.countAccounts(any())).thenReturn(1L);
        when(accountSnapshotProvider.findByAccountIds(List.of("123")))
                .thenReturn(
                        java.util.Map.of(
                                "123",
                                new AccountSnapshotProvider.AccountSnapshot(
                                        "123",
                                        "Mongo账户",
                                        2,
                                        null,
                                        8,
                                        "bm-1",
                                        new BigDecimal("10.50"),
                                        null,
                                        null,
                                        null)));

        var result =
                service.listAccounts(
                        new AccountQuery(
                                1L, null, null, null, null, null, null, null, null, null, null,
                                null, null, null, null, null, 1, 10, null));

        assertThat(result.items())
                .singleElement()
                .satisfies(
                        item -> {
                            assertThat(item.accountName()).isEqualTo("Mongo账户");
                            assertThat(item.status()).isEqualTo(2);
                            assertThat(item.timezone()).isEqualTo(8);
                            assertThat(item.bmId()).isEqualTo("bm-1");
                            assertThat(item.balance()).isEqualByComparingTo("10.50");
                        });
    }

    @Test
    void shouldUpdateAccountWhenItAlreadyBelongsToSameChannel() {
        Channel channel = new Channel();
        channel.setId(1L);
        AccountType type = new AccountType();
        type.setAccountType("企业户");
        Account existing = new Account();
        existing.setId(10L);
        existing.setChannelId(1L);
        when(mapper.findChannel(1L)).thenReturn(channel);
        when(mapper.findAccountTypeByName("企业户")).thenReturn(type);
        when(mapper.findAccount("123")).thenReturn(existing);

        service.batchCreateAccounts(
                new AccountBatch(1L, List.of(new AccountImportItem("act_123", "企业户"))));

        verify(mapper).updateBatchAccount(10L, "企业户", 9L);
        verify(mapper, never()).insertAccount(any());
    }

    @Test
    void shouldReportExistingChannelNameWhenAccountBelongsToAnotherChannel() {
        Channel target = new Channel();
        target.setId(1L);
        Channel occupied = new Channel();
        occupied.setId(2L);
        occupied.setChannelName("旧渠道");
        AccountType type = new AccountType();
        type.setAccountType("企业户");
        Account existing = new Account();
        existing.setId(10L);
        existing.setChannelId(2L);
        when(mapper.findChannel(1L)).thenReturn(target);
        when(mapper.findChannel(2L)).thenReturn(occupied);
        when(mapper.findAccountTypeByName("企业户")).thenReturn(type);
        when(mapper.findAccount("123")).thenReturn(existing);

        assertThatThrownBy(
                        () ->
                                service.batchCreateAccounts(
                                        new AccountBatch(
                                                1L, List.of(new AccountImportItem("123", "企业户")))))
                .isInstanceOf(ChannelService.ChannelException.class)
                .hasMessage("账户[123]在其他渠道[旧渠道]中已存在");
    }

    @Test
    void shouldRejectNormalizedDuplicateAccountIds() {
        Channel channel = new Channel();
        channel.setId(1L);
        AccountType type = new AccountType();
        type.setAccountType("企业户");
        when(mapper.findChannel(1L)).thenReturn(channel);
        when(mapper.findAccountTypeByName("企业户")).thenReturn(type);

        assertThatThrownBy(
                        () ->
                                service.batchCreateAccounts(
                                        new AccountBatch(
                                                1L,
                                                List.of(
                                                        new AccountImportItem("123", "企业户"),
                                                        new AccountImportItem(
                                                                " act_123 ", "企业户")))))
                .isInstanceOf(ChannelService.ChannelException.class)
                .hasMessageContaining("重复的账户ID：123");
    }

    @Test
    void shouldReturnAllImportErrorsBeforeWriting() {
        byte[] template = new ChannelExcelCodec().template();
        when(mapper.findChannel(1L)).thenReturn(null);

        List<String> errors = service.importAccounts(template);

        assertThat(errors).hasSize(1).first().asString().contains("渠道不存在");
        verify(mapper, never()).insertAccount(any());
    }

    @Test
    void shouldRejectIncompleteChannelCreation() {
        ChannelSave request =
                new ChannelSave(
                        "测试渠道",
                        null,
                        null,
                        1,
                        "Mpower",
                        1,
                        "预付",
                        "USD",
                        BigDecimal.ZERO,
                        BigDecimal.ZERO,
                        "address",
                        "https://example.com",
                        null,
                        null,
                        null);

        assertThatThrownBy(() -> service.createChannel(request))
                .isInstanceOf(ChannelService.ChannelException.class)
                .hasMessageContaining("必填信息");
    }

    @Test
    void shouldDefaultMissingChannelAmountsToZero() {
        Channel[] insertedChannel = new Channel[1];
        doAnswer(
                        invocation -> {
                            Channel channel = invocation.getArgument(0);
                            channel.setId(1L);
                            insertedChannel[0] = channel;
                            return 1;
                        })
                .when(mapper)
                .insertChannel(any(Channel.class));
        when(mapper.findChannel(1L)).thenAnswer(invocation -> insertedChannel[0]);
        ChannelSave request =
                new ChannelSave(
                        "测试渠道",
                        "测试",
                        "TEST01",
                        1,
                        "Mpower",
                        1,
                        "预付实消",
                        "USD",
                        null,
                        null,
                        "address",
                        "https://example.com",
                        null,
                        null,
                        null);

        service.createChannel(request);

        assertThat(insertedChannel[0].getBuyoutAmount()).isEqualByComparingTo(BigDecimal.ZERO);
        assertThat(insertedChannel[0].getRechargeAmount()).isEqualByComparingTo(BigDecimal.ZERO);
    }
}
