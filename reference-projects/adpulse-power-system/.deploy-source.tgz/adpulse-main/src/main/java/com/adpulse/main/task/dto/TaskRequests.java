package com.adpulse.main.task.dto;

import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/** 任务中心写入请求。 */
public final class TaskRequests {
    private TaskRequests() {}

    /** 公共任务创建字段。 */
    public record BaseCreate(
            @NotBlank @Size(max = 200) String title,
            @Size(max = 5000) String description,
            @NotBlank String projectId,
            String ownerId,
            @NotBlank @Size(max = 10) String priority,
            @NotNull LocalDateTime dueAt) {}

    /** 投放任务创建请求。 */
    public record DeliveryCreate(
            @NotNull @Valid BaseCreate task,
            @NotBlank @Size(max = 1000) String productUrl,
            @NotBlank @Size(max = 100) String region,
            @NotBlank @Size(max = 1000) String target,
            @NotNull LocalDateTime plannedStartAt,
            @NotEmpty List<@NotBlank @Size(max = 100) String> platforms,
            @NotEmpty List<@Valid Allocation> allocations,
            List<@Valid FileBinding> files,
            String draftId) {}

    /** 团队线路分配。 */
    public record Allocation(
            @NotBlank @Size(max = 30) String teamCode,
            @NotBlank String teamOwnerId,
            @Min(0) int pwaLineCount,
            @Min(0) int h5LineCount) {}

    /** 素材任务创建请求。 */
    public record MaterialCreate(
            @NotNull @Valid BaseCreate task,
            @NotBlank @Size(max = 50) String demandType,
            @NotBlank @Size(max = 100) String languageCode,
            @NotNull Boolean greenMaterial,
            @Size(max = 200) String productSubName,
            @NotEmpty List<@NotBlank @Size(max = 100) String> sizes,
            List<@Size(max = 100) String> countryTags,
            List<@Size(max = 100) String> themeTags,
            List<@Size(max = 100) String> gameplayTags,
            @NotEmpty List<@Valid MaterialRequirement> requirements,
            List<@Valid FileBinding> referenceFiles,
            String draftId) {}

    /** 新建或更新任务草稿请求。 */
    public record DraftSave(
            @NotBlank @Size(max = 20) String taskType,
            @Size(max = 200) String title,
            String projectId,
            @NotNull JsonNode payload) {}

    public record MaterialRequirement(
            @NotBlank @Size(max = 2000) String description,
            @Size(max = 50) String duration,
            @Min(1) int quantity,
            @Size(max = 2000) String link,
            @Size(max = 2000) String remark,
            @Size(max = 2000) String compliance,
            List<@Valid FileBinding> files) {}

    /** 任务负责人分配请求。 */
    public record Assign(@NotBlank String ownerId) {}

    /** 素材任务外部参考链接。 */
    public record ReferenceLink(
            @NotBlank @Size(max = 255) String name, @NotBlank @Size(max = 2000) String url) {}

    /** 文件引用。 */
    public record FileBinding(
            @NotBlank String fileId,
            @NotBlank @Size(max = 30) String usageType,
            @Min(0) int sortOrder) {}

    /** 投放交付请求。 */
    public record DeliverySubmissionCreate(
            @NotBlank @Size(max = 64) String requestId,
            @NotBlank @Size(max = 100) String platform,
            @NotBlank @Size(max = 100) String adAccountId,
            @Size(max = 255) String adAccountName,
            @NotNull LocalDateTime actualStartAt,
            @NotNull @DecimalMin(value = "0", inclusive = false) BigDecimal actualBudget,
            @NotBlank @Size(min = 3, max = 3) String currency,
            @Min(1) int campaignCount,
            @Min(0) int adsetCount,
            @Min(0) int adCount,
            @NotBlank String deliveryStatus,
            @Size(max = 1000) String exceptionNote,
            @Size(max = 5000) String note,
            @NotEmpty List<@Valid DeliveryObject> objects,
            List<@Valid FileBinding> files) {}

    /** 投放交付关联广告对象。 */
    public record DeliveryObject(
            @NotBlank String objectType,
            @NotBlank @Size(max = 200) String objectId,
            @Size(max = 255) String objectName) {}

    /** 素材交付请求。 */
    public record MaterialSubmissionCreate(
            @NotBlank @Size(max = 64) String requestId,
            @Min(1) int deliveredQuantity,
            @Size(max = 5000) String note,
            @NotEmpty List<@Valid FileBinding> files) {}

    /** 验收请求。 */
    public record Review(@Size(max = 1000) String comment) {}

    /** 撤回请求。 */
    public record Withdraw(@NotBlank @Size(max = 500) String reason) {}
}
