package com.adpulse.main.task.dto;

import com.fasterxml.jackson.databind.JsonNode;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/** 任务中心响应模型。 */
public final class TaskViews {
    private TaskViews() {}

    /** 公共任务视图。 */
    public record Task(
            String id,
            String taskCode,
            String taskType,
            String projectId,
            String title,
            String description,
            String creatorId,
            String creatorName,
            String ownerId,
            String ownerName,
            String assignerId,
            String assignerName,
            LocalDateTime assignedAt,
            String priority,
            String status,
            LocalDateTime dueAt,
            LocalDateTime acceptedAt,
            LocalDateTime completedAt,
            LocalDateTime withdrawnAt,
            String withdrawReason,
            int version,
            LocalDateTime createdAt,
            LocalDateTime updatedAt,
            boolean followed) {}

    /** 任务草稿视图。 */
    public record Draft(
            String id,
            String draftCode,
            String taskType,
            String creatorId,
            String creatorName,
            String title,
            String projectId,
            JsonNode payload,
            LocalDateTime createdAt,
            LocalDateTime updatedAt) {}

    /** 与当前用户关联的任务历史动态。 */
    public record Activity(
            String id,
            String taskId,
            String taskType,
            String projectId,
            String taskTitle,
            String eventType,
            String state,
            String actorId,
            String actorName,
            String description,
            LocalDateTime occurredAt) {}

    /** 任务中心左侧导航数量。 */
    public record NavigationCounts(
            long owned,
            long assigned,
            long followed,
            long activities,
            long drafts,
            long all,
            long created,
            long submission,
            long acceptance,
            long completed) {}

    public record Delivery(
            String productUrl, String region, String target, LocalDateTime plannedStartAt) {}

    /** 团队与线路分配。 */
    public record Allocation(
            String id,
            String teamCode,
            String teamOwnerId,
            String teamOwnerName,
            int pwaLineCount,
            int h5LineCount,
            int sortOrder) {}

    /** 素材任务详情。 */
    public record Material(
            String demandType,
            String languageCode,
            boolean greenMaterial,
            String departmentId,
            String departmentName,
            String productSubName,
            int quantity,
            boolean addToLibrary,
            List<String> countryTags,
            List<String> themeTags,
            List<String> gameplayTags) {}

    /** 素材需求描述视图。 */
    public record MaterialRequirement(
            String id,
            int sortOrder,
            String description,
            String duration,
            int quantity,
            String link,
            String remark,
            String compliance) {}

    /** 投放交付视图。 */
    public record DeliverySubmission(
            String id,
            int versionNo,
            String requestId,
            String submittedBy,
            String submittedByName,
            String platform,
            String adAccountId,
            String adAccountName,
            LocalDateTime actualStartAt,
            BigDecimal actualBudget,
            String currency,
            int campaignCount,
            int adsetCount,
            int adCount,
            String deliveryStatus,
            String exceptionNote,
            String submissionNote,
            LocalDateTime submittedAt,
            String reviewStatus,
            String reviewerId,
            String reviewerName,
            String reviewComment,
            LocalDateTime reviewedAt,
            List<DeliveryObject> objects) {}

    /** 投放交付关联的广告对象。 */
    public record DeliveryObject(
            String objectType, String objectId, String objectName, int sortOrder) {}

    /** 素材交付视图。 */
    public record MaterialSubmission(
            String id,
            int versionNo,
            String requestId,
            String submittedBy,
            String submittedByName,
            int deliveredQuantity,
            String submissionNote,
            LocalDateTime submittedAt,
            String reviewStatus,
            String reviewerId,
            String reviewerName,
            String reviewComment,
            LocalDateTime reviewedAt,
            String libraryStatus) {}

    /** 任务详情及其类型化数据。 */
    public record Detail(
            Task task,
            Delivery delivery,
            List<String> platforms,
            List<Allocation> allocations,
            Material material,
            List<String> sizes,
            List<MaterialRequirement> materialRequirements,
            List<ReferenceLink> referenceLinks,
            List<FileView> taskFiles,
            List<DeliverySubmission> deliverySubmissions,
            List<MaterialSubmission> materialSubmissions) {}

    /** 外部参考链接。 */
    public record ReferenceLink(String name, String url, int sortOrder) {}

    /** 任务文件视图。 */
    public record FileView(
            String id,
            String originalName,
            String extension,
            long fileSize,
            String mimeType,
            String targetType,
            String targetId,
            String usageType,
            int sortOrder) {}

    /** 分页响应。 */
    public record Page<T>(List<T> items, long total, int page, int pageSize) {}
}
