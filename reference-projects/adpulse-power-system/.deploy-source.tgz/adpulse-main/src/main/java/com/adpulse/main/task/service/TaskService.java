package com.adpulse.main.task.service;

import com.adpulse.main.task.dto.TaskRequests;
import com.adpulse.main.task.dto.TaskViews;
import com.adpulse.main.task.mapper.TaskMapper;
import com.adpulse.main.task.model.TaskModels;
import com.adpulse.system.common.security.CurrentUser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** 任务创建、确认、类型化交付和验收业务服务。 */
@Service
public class TaskService {
    private static final Set<String> PRIORITIES = Set.of("P0", "P1", "P2");
    private static final Set<String> DELIVERY_STATUSES =
            Set.of("ACTIVE", "PARTIAL", "PAUSED", "FAILED");
    private static final Set<String> OBJECT_TYPES = Set.of("CAMPAIGN", "AD_SET", "AD");
    private static final Set<String> TEAM_CODES = Set.of("MP", "MAD", "MY", "Firefly");
    private static final Set<String> FILE_USAGES =
            Set.of("ATTACHMENT", "REFERENCE", "PROOF", "DATA", "MATERIAL");

    private final TaskMapper mapper;
    private final ObjectMapper objectMapper;

    public TaskService(TaskMapper mapper, ObjectMapper objectMapper) {
        this.mapper = mapper;
        this.objectMapper = objectMapper;
    }

    /** 分页查询当前用户创建或负责的任务。 */
    public TaskViews.Page<TaskViews.Task> list(
            String taskType, String status, String keyword, String scope, int page, int pageSize) {
        int safePage = Math.max(1, page);
        int safeSize = Math.min(100, Math.max(1, pageSize));
        String normalizedType = optionalUpper(taskType);
        String normalizedStatus = optionalUpper(status);
        String normalizedScope = upper(scope);
        if (!Set.of("RELATED", "OWNER", "CREATED", "ASSIGNED", "FOLLOWED")
                .contains(normalizedScope)) {
            throw new TaskException("任务查询范围不合法");
        }
        Long userId = currentUser().userId();
        return new TaskViews.Page<>(
                mapper
                        .findTasks(
                                userId,
                                normalizedScope,
                                normalizedType,
                                normalizedStatus,
                                trimToNull(keyword),
                                (safePage - 1) * safeSize,
                                safeSize)
                        .stream()
                        .map(this::taskView)
                        .toList(),
                mapper.countTasks(
                        userId,
                        normalizedScope,
                        normalizedType,
                        normalizedStatus,
                        trimToNull(keyword)),
                safePage,
                safeSize);
    }

    /** 只查询当前用户任务中心左侧导航数量。 */
    public TaskViews.NavigationCounts navigationCounts() {
        Long userId = currentUser().userId();
        return new TaskViews.NavigationCounts(
                mapper.countTasks(userId, "OWNER", null, null, null),
                mapper.countAssignedTasks(userId),
                mapper.countFollowedTasks(userId),
                mapper.countActivities(userId),
                mapper.countDrafts(userId),
                mapper.countTasks(userId, "RELATED", null, null, null),
                mapper.countTasks(userId, "CREATED", null, null, null),
                mapper.countTasks(userId, "OWNER", null, "PROCESSING", null),
                mapper.countTasks(userId, "CREATED", null, "PENDING_ACCEPTANCE", null),
                mapper.countTasks(userId, "RELATED", null, "COMPLETED", null));
    }

    /** 查询当前用户可见的任务详情。 */
    public TaskViews.Detail get(Long taskId) {
        TaskModels.Task task = requireVisibleTask(taskId);
        return detail(task);
    }

    /** 查询当前用户作为创建者或负责人的任务历史动态。 */
    public List<TaskViews.Activity> listActivities(int limit) {
        int safeLimit = Math.min(200, Math.max(1, limit));
        return mapper.findActivities(currentUser().userId(), safeLimit).stream()
                .map(this::activityView)
                .toList();
    }

    /** 查询当前用户保存的任务草稿。 */
    public List<TaskViews.Draft> listDrafts() {
        return mapper.findDrafts(currentUser().userId()).stream().map(this::draftView).toList();
    }

    /** 查询当前用户的一项任务草稿。 */
    public TaskViews.Draft getDraft(Long draftId) {
        return draftView(requireOwnedDraft(draftId));
    }

    /** 保存一项新的任务草稿。 */
    @Transactional
    public TaskViews.Draft createDraft(TaskRequests.DraftSave request) {
        CurrentUser creator = currentUser();
        TaskModels.Draft draft = buildDraft(null, request, creator);
        draft.setDraftCode(
                "DRAFT-"
                        + java.util
                                .UUID
                                .randomUUID()
                                .toString()
                                .substring(0, 12)
                                .toUpperCase(Locale.ROOT));
        draft.setCreatorId(creator.userId());
        draft.setCreatorName(creator.displayName());
        draft.setCreatedBy(creator.userId());
        mapper.insertDraft(draft);
        return draftView(mapper.findDraft(draft.getId()));
    }

    /** 更新当前用户的一项任务草稿。 */
    @Transactional
    public TaskViews.Draft updateDraft(Long draftId, TaskRequests.DraftSave request) {
        CurrentUser creator = currentUser();
        requireOwnedDraftForUpdate(draftId, creator.userId());
        TaskModels.Draft draft = buildDraft(draftId, request, creator);
        draft.setCreatorId(creator.userId());
        if (mapper.updateDraft(draft) != 1) throw new TaskException("草稿已被删除，请刷新后重试");
        return draftView(mapper.findDraft(draftId));
    }

    /** 软删除当前用户的一项任务草稿。 */
    @Transactional
    public void deleteDraft(Long draftId) {
        Long userId = currentUser().userId();
        requireOwnedDraftForUpdate(draftId, userId);
        mapper.deleteDraft(draftId, userId, System.currentTimeMillis());
    }

    /** 创建投放任务及平台、团队线路和创建附件。 */
    @Transactional
    public TaskViews.Detail createDelivery(TaskRequests.DeliveryCreate request) {
        CurrentUser creator = currentUser();
        CommonCreate common = validateCommon(request.task(), creator);
        List<String> platforms = distinctRequired(request.platforms(), "投放平台");
        if (request.allocations().stream()
                .anyMatch(row -> row.pwaLineCount() + row.h5LineCount() <= 0)) {
            throw new TaskException("每个参与团队的PWA与H5线路数合计必须大于0");
        }
        List<String> teams =
                request.allocations().stream().map(TaskRequests.Allocation::teamCode).toList();
        if (new LinkedHashSet<>(teams).size() != teams.size()) {
            throw new TaskException("同一投放团队不能重复添加");
        }
        for (String team : teams) {
            if (!TEAM_CODES.contains(team)) throw new TaskException("投放团队编码不合法：" + team);
        }
        validateOwnedFiles(request.files(), creator.userId());

        TaskModels.Task task = insertTask("DELIVERY", common, creator);
        TaskModels.DeliveryDetail detail = new TaskModels.DeliveryDetail();
        detail.setTaskId(task.getId());
        detail.setProductUrl(request.productUrl().trim());
        detail.setRegionValue(request.region().trim());
        detail.setTargetDescription(request.target().trim());
        detail.setPlannedStartAt(request.plannedStartAt());
        mapper.insertDeliveryDetail(detail);
        for (int index = 0; index < platforms.size(); index++) {
            mapper.insertDeliveryPlatform(task.getId(), platforms.get(index), index);
        }
        for (int index = 0; index < request.allocations().size(); index++) {
            TaskRequests.Allocation input = request.allocations().get(index);
            Long teamOwnerId = parseId(input.teamOwnerId(), "团队负责人");
            String teamOwnerName = requireActiveUser(teamOwnerId, "团队负责人");
            TaskModels.Allocation allocation = new TaskModels.Allocation();
            allocation.setTaskId(task.getId());
            allocation.setTeamCode(input.teamCode());
            allocation.setTeamOwnerId(teamOwnerId);
            allocation.setTeamOwnerName(teamOwnerName);
            allocation.setPwaLineCount(input.pwaLineCount());
            allocation.setH5LineCount(input.h5LineCount());
            allocation.setSortOrder(index);
            mapper.insertAllocation(allocation);
        }
        bindFiles(task.getId(), task.getId(), "DELIVERY_TASK", request.files(), creator.userId());
        recordActivity(task, "CREATED", task.getStatus(), creator, "创建了投放任务");
        consumeDraft(request.draftId(), "DELIVERY", creator.userId());
        return detail(task);
    }

    /** 创建素材任务及尺寸、参考链接和参考文件。 */
    @Transactional
    public TaskViews.Detail createMaterial(TaskRequests.MaterialCreate request) {
        CurrentUser creator = currentUser();
        CommonCreate common = validateCommon(request.task(), creator);
        List<String> sizes = distinctRequired(request.sizes(), "素材尺寸");
        requireDictionaryValues(
                "MATERIAL_DEMAND_TYPE", List.of(request.demandType().trim()), "素材类型");
        requireDictionaryValues("MATERIAL_SIZE", sizes, "素材尺寸");
        requireDictionaryValues("MATERIAL_LANGUAGE", List.of(request.languageCode().trim()), "语种");
        List<TaskRequests.MaterialRequirement> requirements = request.requirements();
        int quantity =
                requirements.stream().mapToInt(TaskRequests.MaterialRequirement::quantity).sum();
        if (quantity <= 0) throw new TaskException("需求描述交付数量合计必须大于0");
        validateOwnedFiles(request.referenceFiles(), creator.userId());
        if (safe(request.referenceFiles()).stream()
                .anyMatch(file -> !"REFERENCE".equals(upper(file.usageType())))) {
            throw new TaskException("素材参考文件用途必须为REFERENCE");
        }
        for (TaskRequests.MaterialRequirement requirement : requirements) {
            validateOwnedFiles(requirement.files(), creator.userId());
            if (safe(requirement.files()).stream()
                    .anyMatch(file -> !"ATTACHMENT".equals(upper(file.usageType())))) {
                throw new TaskException("需求描述附件用途必须为ATTACHMENT");
            }
        }

        TaskModels.Task task = insertTask("MATERIAL", common, creator);
        TaskModels.DepartmentSnapshot department = mapper.findUserDepartment(creator.userId());
        TaskModels.MaterialDetail detail = new TaskModels.MaterialDetail();
        detail.setTaskId(task.getId());
        detail.setDemandType(request.demandType().trim());
        detail.setLanguageCode(request.languageCode().trim());
        detail.setGreenMaterial(Boolean.TRUE.equals(request.greenMaterial()));
        detail.setDepartmentId(department == null ? null : department.getId());
        detail.setDepartmentName(department == null ? null : department.getName());
        detail.setProductSubName(trimToNull(request.productSubName()));
        detail.setQuantity(quantity);
        detail.setAddToLibrary(false);
        detail.setCountryTags(json(request.countryTags()));
        detail.setThemeTags(json(request.themeTags()));
        detail.setGameplayTags(json(request.gameplayTags()));
        mapper.insertMaterialDetail(detail);
        for (int index = 0; index < sizes.size(); index++) {
            mapper.insertMaterialSize(task.getId(), sizes.get(index), index);
        }
        for (int index = 0; index < requirements.size(); index++) {
            TaskRequests.MaterialRequirement input = requirements.get(index);
            TaskModels.MaterialRequirement requirement = new TaskModels.MaterialRequirement();
            requirement.setTaskId(task.getId());
            requirement.setSortOrder(index);
            requirement.setDescription(input.description().trim());
            requirement.setDurationText(trimToNull(input.duration()));
            requirement.setQuantity(input.quantity());
            requirement.setRelatedLink(trimToNull(input.link()));
            requirement.setRemark(trimToNull(input.remark()));
            requirement.setComplianceRequirement(trimToNull(input.compliance()));
            requirement.setCreatedBy(creator.userId());
            requirement.setUpdatedBy(creator.userId());
            mapper.insertMaterialRequirement(requirement);
            bindFiles(
                    task.getId(),
                    requirement.getId(),
                    "MATERIAL_REQUIREMENT",
                    input.files(),
                    creator.userId());
        }
        bindFiles(
                task.getId(),
                task.getId(),
                "MATERIAL_TASK",
                request.referenceFiles(),
                creator.userId());
        recordActivity(task, "CREATED", task.getStatus(), creator, "创建了素材任务");
        consumeDraft(request.draftId(), "MATERIAL", creator.userId());
        return detail(task);
    }

    /** 查询当前用户关注且仍有权查看的任务ID。 */
    public List<String> listFollowedTaskIds() {
        return mapper.findFollowedTaskIds(currentUser().userId()).stream().map(this::id).toList();
    }

    /** 当前用户关注一项可见任务。 */
    @Transactional
    public void follow(Long taskId) {
        requireVisibleTask(taskId);
        Long userId = currentUser().userId();
        if (mapper.countTaskFollow(taskId, userId) == 0) {
            mapper.insertTaskFollow(taskId, userId);
        }
    }

    /** 当前用户取消关注一项可见任务。 */
    @Transactional
    public void unfollow(Long taskId) {
        requireVisibleTask(taskId);
        mapper.deleteTaskFollow(taskId, currentUser().userId(), System.currentTimeMillis());
    }

    /** 由创建者为待分配任务指定负责人。 */
    @Transactional
    public TaskViews.Detail assign(Long taskId, TaskRequests.Assign request) {
        TaskModels.Task task = requireTaskForUpdate(taskId);
        Long creatorId = currentUser().userId();
        if (!creatorId.equals(task.getCreatorId())) {
            throw new TaskException("只有任务创建者可以分配负责人");
        }
        Long ownerId = parseId(request.ownerId(), "任务负责人");
        String ownerName = requireActiveUser(ownerId, "任务负责人");
        CurrentUser assigner = currentUser();
        if (mapper.assignTask(
                        taskId,
                        creatorId,
                        ownerId,
                        ownerName,
                        assigner.userId(),
                        assigner.displayName(),
                        LocalDateTime.now(),
                        task.getVersion())
                != 1) {
            throw new TaskException("任务已分配或状态已变化，请刷新后重试");
        }
        recordActivity(task, "ASSIGNED", "PENDING_CONFIRMATION", assigner, "将任务分配给" + ownerName);
        return detail(requireTask(taskId));
    }

    /** 由任务负责人确认接收任务。 */
    @Transactional
    public TaskViews.Detail confirm(Long taskId) {
        TaskModels.Task task = requireTaskForUpdate(taskId);
        Long userId = currentUser().userId();
        if (!userId.equals(task.getOwnerId())) throw new TaskException("只有任务负责人可以确认任务");
        if (mapper.confirmTask(taskId, userId, task.getVersion(), LocalDateTime.now()) != 1) {
            throw new TaskException("任务状态已变化，请刷新后重试");
        }
        recordActivity(task, "CONFIRMED", "PROCESSING", currentUser(), "确认接收了任务");
        return detail(requireTask(taskId));
    }

    /** 由创建者撤回尚未进入验收的任务。 */
    @Transactional
    public TaskViews.Detail withdraw(Long taskId, TaskRequests.Withdraw request) {
        TaskModels.Task task = requireTaskForUpdate(taskId);
        Long userId = currentUser().userId();
        if (!userId.equals(task.getCreatorId())) throw new TaskException("只有任务创建者可以撤回任务");
        if (mapper.withdrawTask(
                        taskId,
                        userId,
                        task.getVersion(),
                        request.reason().trim(),
                        LocalDateTime.now())
                != 1) {
            throw new TaskException("当前任务状态不可撤回");
        }
        recordActivity(
                task, "WITHDRAWN", "WITHDRAWN", currentUser(), "撤回了任务：" + request.reason().trim());
        return detail(requireTask(taskId));
    }

    /** 提交一版投放交付并将任务转为待验收。 */
    @Transactional
    public TaskViews.Detail submitDelivery(
            Long taskId, TaskRequests.DeliverySubmissionCreate request) {
        TaskModels.DeliverySubmission existing =
                mapper.findDeliverySubmissionByRequestId(request.requestId().trim());
        if (existing != null) {
            if (!taskId.equals(existing.getTaskId())) throw new TaskException("交付幂等键已被其他任务使用");
            return get(taskId);
        }
        TaskModels.Task task = requireSubmittableTask(taskId, "DELIVERY");
        String platform = request.platform().trim();
        if (!mapper.findDeliveryPlatforms(taskId).contains(platform)) {
            throw new TaskException("实际投放平台不在任务计划平台范围内");
        }
        String deliveryStatus = request.deliveryStatus().trim().toUpperCase(Locale.ROOT);
        if (!DELIVERY_STATUSES.contains(deliveryStatus)) throw new TaskException("投放状态不合法");
        validateDeliveryObjects(request);
        validateOwnedFiles(request.files(), task.getOwnerId());

        LocalDateTime now = LocalDateTime.now();
        TaskModels.DeliverySubmission submission = new TaskModels.DeliverySubmission();
        submission.setTaskId(taskId);
        submission.setVersionNo(mapper.nextDeliveryVersion(taskId));
        submission.setRequestId(request.requestId().trim());
        submission.setSubmittedBy(task.getOwnerId());
        submission.setSubmittedByName(task.getOwnerName());
        submission.setPlatformValue(platform);
        submission.setAdAccountId(request.adAccountId().trim());
        submission.setAdAccountName(trimToNull(request.adAccountName()));
        submission.setActualStartAt(request.actualStartAt());
        submission.setActualBudget(request.actualBudget());
        submission.setCurrency(request.currency().trim().toUpperCase(Locale.ROOT));
        submission.setCampaignCount(request.campaignCount());
        submission.setAdsetCount(request.adsetCount());
        submission.setAdCount(request.adCount());
        submission.setDeliveryStatus(deliveryStatus);
        submission.setExceptionNote(trimToNull(request.exceptionNote()));
        submission.setSubmissionNote(trimToNull(request.note()));
        submission.setSubmittedAt(now);
        mapper.insertDeliverySubmission(submission);
        for (int index = 0; index < request.objects().size(); index++) {
            TaskRequests.DeliveryObject object = request.objects().get(index);
            mapper.insertDeliveryObject(
                    submission.getId(),
                    object.objectType().trim().toUpperCase(Locale.ROOT),
                    object.objectId().trim(),
                    trimToNull(object.objectName()),
                    index);
        }
        bindFiles(
                taskId,
                submission.getId(),
                "DELIVERY_SUBMISSION",
                request.files(),
                task.getOwnerId());
        markPendingAcceptance(task);
        recordActivity(
                task, "DELIVERY_SUBMITTED", "PENDING_ACCEPTANCE", currentUser(), "提交了投放任务交付");
        return detail(requireTask(taskId));
    }

    /** 提交一版素材交付并将任务转为待验收。 */
    @Transactional
    public TaskViews.Detail submitMaterial(
            Long taskId, TaskRequests.MaterialSubmissionCreate request) {
        TaskModels.MaterialSubmission existing =
                mapper.findMaterialSubmissionByRequestId(request.requestId().trim());
        if (existing != null) {
            if (!taskId.equals(existing.getTaskId())) throw new TaskException("交付幂等键已被其他任务使用");
            return get(taskId);
        }
        TaskModels.Task task = requireSubmittableTask(taskId, "MATERIAL");
        List<TaskRequests.FileBinding> files = safe(request.files());
        if (files.stream().anyMatch(file -> !"MATERIAL".equals(upper(file.usageType())))) {
            throw new TaskException("素材交付文件用途必须为MATERIAL");
        }
        validateOwnedFiles(files, task.getOwnerId());
        TaskModels.MaterialDetail material = mapper.findMaterialDetail(taskId);
        if (request.deliveredQuantity() != files.size()) {
            throw new TaskException("交付素材数量必须与交付文件数量一致");
        }
        if (request.deliveredQuantity() < material.getQuantity()) {
            throw new TaskException("交付素材数量不能少于任务要求数量");
        }

        TaskModels.MaterialSubmission submission = new TaskModels.MaterialSubmission();
        submission.setTaskId(taskId);
        submission.setVersionNo(mapper.nextMaterialVersion(taskId));
        submission.setRequestId(request.requestId().trim());
        submission.setSubmittedBy(task.getOwnerId());
        submission.setSubmittedByName(task.getOwnerName());
        submission.setDeliveredQuantity(request.deliveredQuantity());
        submission.setSubmissionNote(trimToNull(request.note()));
        submission.setSubmittedAt(LocalDateTime.now());
        submission.setLibraryStatus(material.getAddToLibrary() ? "PENDING" : "NOT_REQUIRED");
        mapper.insertMaterialSubmission(submission);
        bindFiles(taskId, submission.getId(), "MATERIAL_SUBMISSION", files, task.getOwnerId());
        markPendingAcceptance(task);
        recordActivity(
                task, "DELIVERY_SUBMITTED", "PENDING_ACCEPTANCE", currentUser(), "提交了素材任务交付");
        return detail(requireTask(taskId));
    }

    /** 由创建者验收通过指定类型的当前交付。 */
    @Transactional
    public TaskViews.Detail accept(
            Long taskId, Long submissionId, String type, TaskRequests.Review request) {
        return review(taskId, submissionId, type, "ACCEPTED", trimToNull(request.comment()));
    }

    /** 由创建者打回指定类型的当前交付。 */
    @Transactional
    public TaskViews.Detail reject(
            Long taskId, Long submissionId, String type, TaskRequests.Review request) {
        String comment = trimToNull(request.comment());
        if (comment == null) throw new TaskException("打回任务时必须填写原因");
        return review(taskId, submissionId, type, "REJECTED", comment);
    }

    private TaskViews.Detail review(
            Long taskId, Long submissionId, String type, String result, String comment) {
        TaskModels.Task task = requireTaskForUpdate(taskId);
        CurrentUser reviewer = currentUser();
        if (!reviewer.userId().equals(task.getCreatorId())) {
            throw new TaskException("只有任务创建者可以验收任务");
        }
        if (!"PENDING_ACCEPTANCE".equals(task.getStatus())) {
            throw new TaskException("当前任务不在待验收状态");
        }
        String normalizedType = upper(type);
        if (!normalizedType.equals(task.getTaskType())) throw new TaskException("交付类型与任务类型不一致");
        LocalDateTime now = LocalDateTime.now();
        int changed;
        if ("DELIVERY".equals(normalizedType)) {
            changed =
                    mapper.reviewDeliverySubmission(
                            submissionId,
                            taskId,
                            result,
                            reviewer.userId(),
                            reviewer.displayName(),
                            comment,
                            now);
        } else {
            TaskModels.MaterialDetail material = mapper.findMaterialDetail(taskId);
            String libraryStatus =
                    "ACCEPTED".equals(result) && material.getAddToLibrary()
                            ? "PENDING"
                            : "NOT_REQUIRED";
            changed =
                    mapper.reviewMaterialSubmission(
                            submissionId,
                            taskId,
                            result,
                            reviewer.userId(),
                            reviewer.displayName(),
                            comment,
                            libraryStatus,
                            now);
        }
        if (changed != 1) throw new TaskException("交付记录不存在或已完成验收");
        int taskChanged =
                "ACCEPTED".equals(result)
                        ? mapper.acceptTask(taskId, reviewer.userId(), task.getVersion(), now)
                        : mapper.rejectTask(taskId, reviewer.userId(), task.getVersion());
        if (taskChanged != 1) throw new TaskException("任务状态已变化，请刷新后重试");
        recordActivity(
                task,
                "ACCEPTED".equals(result) ? "ACCEPTED" : "REJECTED",
                "ACCEPTED".equals(result) ? "COMPLETED" : "PROCESSING",
                reviewer,
                "ACCEPTED".equals(result) ? "验收通过了任务交付" : "打回了任务交付：" + comment);
        return detail(requireTask(taskId));
    }

    private TaskModels.Task requireSubmittableTask(Long taskId, String type) {
        TaskModels.Task task = requireTaskForUpdate(taskId);
        CurrentUser user = currentUser();
        if (!user.userId().equals(task.getOwnerId())) throw new TaskException("只有任务负责人可以提交交付");
        if (!type.equals(task.getTaskType())) throw new TaskException("交付类型与任务类型不一致");
        if (!"PROCESSING".equals(task.getStatus())) throw new TaskException("当前任务不可提交交付");
        return task;
    }

    private void markPendingAcceptance(TaskModels.Task task) {
        if (mapper.markPendingAcceptance(task.getId(), task.getOwnerId(), task.getVersion()) != 1) {
            throw new TaskException("任务状态已变化，请刷新后重试");
        }
    }

    private TaskModels.Task insertTask(String type, CommonCreate common, CurrentUser creator) {
        TaskModels.Task task = new TaskModels.Task();
        task.setTaskCode(
                "TASK-"
                        + type.charAt(0)
                        + "-"
                        + java.util
                                .UUID
                                .randomUUID()
                                .toString()
                                .substring(0, 12)
                                .toUpperCase(Locale.ROOT));
        task.setTaskType(type);
        task.setProjectId(common.projectId());
        task.setTitle(common.request().title().trim());
        task.setDescription(trimToNull(common.request().description()));
        task.setCreatorId(creator.userId());
        task.setCreatorName(creator.displayName());
        task.setOwnerId(common.ownerId());
        task.setOwnerName(common.ownerName());
        task.setPriority(common.priority());
        task.setStatus(common.ownerId() == null ? "PENDING_ASSIGNMENT" : "PENDING_CONFIRMATION");
        task.setDueAt(common.request().dueAt());
        task.setVersion(0);
        task.setCreatedBy(creator.userId());
        task.setUpdatedBy(creator.userId());
        mapper.insertTask(task);
        return task;
    }

    private CommonCreate validateCommon(TaskRequests.BaseCreate request, CurrentUser creator) {
        Long projectId = parseId(request.projectId(), "项目");
        if (mapper.findProjectName(projectId) == null) throw new TaskException("项目不存在或已删除");
        Long ownerId =
                request.ownerId() == null || request.ownerId().isBlank()
                        ? null
                        : parseId(request.ownerId(), "任务负责人");
        String ownerName = ownerId == null ? null : requireActiveUser(ownerId, "任务负责人");
        String priority = upper(request.priority());
        if (!PRIORITIES.contains(priority)) throw new TaskException("任务优先级不合法");
        requireDictionaryValues("TASK_PRIORITY", List.of(priority), "任务优先级");
        if (request.dueAt().isBefore(LocalDateTime.now()))
            throw new TaskException("任务截止时间不能早于当前时间");
        return new CommonCreate(request, projectId, ownerId, ownerName, priority);
    }

    private TaskViews.Detail detail(TaskModels.Task task) {
        boolean delivery = "DELIVERY".equals(task.getTaskType());
        TaskModels.DeliveryDetail deliveryDetail =
                delivery ? mapper.findDeliveryDetail(task.getId()) : null;
        TaskModels.MaterialDetail materialDetail =
                delivery ? null : mapper.findMaterialDetail(task.getId());
        return new TaskViews.Detail(
                taskView(task),
                deliveryDetail == null
                        ? null
                        : new TaskViews.Delivery(
                                deliveryDetail.getProductUrl(), deliveryDetail.getRegionValue(),
                                deliveryDetail.getTargetDescription(),
                                        deliveryDetail.getPlannedStartAt()),
                delivery ? mapper.findDeliveryPlatforms(task.getId()) : List.of(),
                delivery
                        ? mapper.findAllocations(task.getId()).stream()
                                .map(this::allocationView)
                                .toList()
                        : List.of(),
                materialDetail == null ? null : materialView(materialDetail),
                delivery ? List.of() : mapper.findMaterialSizes(task.getId()),
                delivery
                        ? List.of()
                        : mapper.findMaterialRequirements(task.getId()).stream()
                                .map(this::materialRequirementView)
                                .toList(),
                delivery ? List.of() : mapper.findReferenceLinks(task.getId()),
                mapper.findTaskFiles(task.getId()),
                delivery
                        ? mapper.findDeliverySubmissions(task.getId()).stream()
                                .map(this::deliverySubmissionView)
                                .toList()
                        : List.of(),
                delivery
                        ? List.of()
                        : mapper.findMaterialSubmissions(task.getId()).stream()
                                .map(this::materialSubmissionView)
                                .toList());
    }

    private TaskViews.Task taskView(TaskModels.Task row) {
        return new TaskViews.Task(
                id(row.getId()),
                row.getTaskCode(),
                row.getTaskType(),
                id(row.getProjectId()),
                row.getTitle(),
                row.getDescription(),
                id(row.getCreatorId()),
                row.getCreatorName(),
                id(row.getOwnerId()),
                row.getOwnerName(),
                id(row.getAssignerId()),
                row.getAssignerName(),
                row.getAssignedAt(),
                row.getPriority(),
                row.getStatus(),
                row.getDueAt(),
                row.getAcceptedAt(),
                row.getCompletedAt(),
                row.getWithdrawnAt(),
                row.getWithdrawReason(),
                row.getVersion(),
                row.getCreatedAt(),
                row.getUpdatedAt(),
                Boolean.TRUE.equals(row.getFollowed()));
    }

    private TaskViews.Activity activityView(TaskModels.Activity row) {
        return new TaskViews.Activity(
                id(row.getId()),
                id(row.getTaskId()),
                row.getTaskType(),
                id(row.getProjectId()),
                row.getTaskTitle(),
                row.getEventType(),
                row.getState(),
                id(row.getActorId()),
                row.getActorName(),
                row.getDescription(),
                row.getCreatedAt());
    }

    private void recordActivity(
            TaskModels.Task task,
            String eventType,
            String state,
            CurrentUser actor,
            String description) {
        TaskModels.Activity activity = new TaskModels.Activity();
        activity.setTaskId(task.getId());
        activity.setEventType(eventType);
        activity.setState(state);
        activity.setActorId(actor.userId());
        activity.setActorName(actor.displayName());
        activity.setDescription(description);
        mapper.insertActivity(activity);
    }

    private TaskModels.Draft buildDraft(
            Long id, TaskRequests.DraftSave request, CurrentUser creator) {
        String taskType = upper(request.taskType());
        if (!Set.of("DELIVERY", "MATERIAL").contains(taskType)) {
            throw new TaskException("草稿任务类型不合法");
        }
        Long projectId =
                request.projectId() == null || request.projectId().isBlank()
                        ? null
                        : parseId(request.projectId(), "项目");
        if (projectId != null && mapper.findProjectName(projectId) == null) {
            throw new TaskException("项目不存在或已删除");
        }
        TaskModels.Draft draft = new TaskModels.Draft();
        draft.setId(id);
        draft.setTaskType(taskType);
        draft.setTitle(trimToNull(request.title()));
        draft.setProjectId(projectId);
        try {
            draft.setPayloadJson(objectMapper.writeValueAsString(request.payload()));
        } catch (JsonProcessingException exception) {
            throw new TaskException("草稿内容格式不正确");
        }
        draft.setUpdatedBy(creator.userId());
        return draft;
    }

    private TaskViews.Draft draftView(TaskModels.Draft row) {
        try {
            return new TaskViews.Draft(
                    id(row.getId()),
                    row.getDraftCode(),
                    row.getTaskType(),
                    id(row.getCreatorId()),
                    row.getCreatorName(),
                    row.getTitle(),
                    id(row.getProjectId()),
                    objectMapper.readTree(row.getPayloadJson()),
                    row.getCreatedAt(),
                    row.getUpdatedAt());
        } catch (JsonProcessingException exception) {
            throw new IllegalStateException("任务草稿数据格式错误", exception);
        }
    }

    private TaskModels.Draft requireOwnedDraft(Long draftId) {
        TaskModels.Draft draft = mapper.findDraft(draftId);
        if (draft == null || !currentUser().userId().equals(draft.getCreatorId())) {
            throw new TaskException("草稿不存在或无权访问");
        }
        return draft;
    }

    private TaskModels.Draft requireOwnedDraftForUpdate(Long draftId, Long userId) {
        TaskModels.Draft draft = mapper.findDraftForUpdate(draftId);
        if (draft == null || !userId.equals(draft.getCreatorId())) {
            throw new TaskException("草稿不存在或无权访问");
        }
        return draft;
    }

    private void consumeDraft(String draftId, String taskType, Long userId) {
        if (draftId == null || draftId.isBlank()) return;
        Long id = parseId(draftId, "草稿");
        TaskModels.Draft draft = requireOwnedDraftForUpdate(id, userId);
        if (!taskType.equals(draft.getTaskType())) throw new TaskException("草稿任务类型不匹配");
        mapper.deleteDraft(id, userId, System.currentTimeMillis());
    }

    private TaskViews.Allocation allocationView(TaskModels.Allocation row) {
        return new TaskViews.Allocation(
                id(row.getId()),
                row.getTeamCode(),
                id(row.getTeamOwnerId()),
                row.getTeamOwnerName(),
                row.getPwaLineCount(),
                row.getH5LineCount(),
                row.getSortOrder());
    }

    private TaskViews.Material materialView(TaskModels.MaterialDetail row) {
        return new TaskViews.Material(
                row.getDemandType(),
                row.getLanguageCode(),
                Boolean.TRUE.equals(row.getGreenMaterial()),
                id(row.getDepartmentId()),
                row.getDepartmentName(),
                row.getProductSubName(),
                row.getQuantity(),
                row.getAddToLibrary(),
                jsonList(row.getCountryTags()),
                jsonList(row.getThemeTags()),
                jsonList(row.getGameplayTags()));
    }

    private TaskViews.MaterialRequirement materialRequirementView(
            TaskModels.MaterialRequirement row) {
        return new TaskViews.MaterialRequirement(
                id(row.getId()),
                row.getSortOrder(),
                row.getDescription(),
                row.getDurationText(),
                row.getQuantity(),
                row.getRelatedLink(),
                row.getRemark(),
                row.getComplianceRequirement());
    }

    private TaskViews.DeliverySubmission deliverySubmissionView(TaskModels.DeliverySubmission row) {
        return new TaskViews.DeliverySubmission(
                id(row.getId()),
                row.getVersionNo(),
                row.getRequestId(),
                id(row.getSubmittedBy()),
                row.getSubmittedByName(),
                row.getPlatformValue(),
                row.getAdAccountId(),
                row.getAdAccountName(),
                row.getActualStartAt(),
                row.getActualBudget(),
                row.getCurrency(),
                row.getCampaignCount(),
                row.getAdsetCount(),
                row.getAdCount(),
                row.getDeliveryStatus(),
                row.getExceptionNote(),
                row.getSubmissionNote(),
                row.getSubmittedAt(),
                row.getReviewStatus(),
                id(row.getReviewerId()),
                row.getReviewerName(),
                row.getReviewComment(),
                row.getReviewedAt(),
                mapper.findDeliveryObjects(row.getId()));
    }

    private TaskViews.MaterialSubmission materialSubmissionView(TaskModels.MaterialSubmission row) {
        return new TaskViews.MaterialSubmission(
                id(row.getId()),
                row.getVersionNo(),
                row.getRequestId(),
                id(row.getSubmittedBy()),
                row.getSubmittedByName(),
                row.getDeliveredQuantity(),
                row.getSubmissionNote(),
                row.getSubmittedAt(),
                row.getReviewStatus(),
                id(row.getReviewerId()),
                row.getReviewerName(),
                row.getReviewComment(),
                row.getReviewedAt(),
                row.getLibraryStatus());
    }

    private List<String> jsonList(String value) {
        if (value == null || value.isBlank()) return List.of();
        try {
            return objectMapper.readValue(
                    value,
                    objectMapper
                            .getTypeFactory()
                            .constructCollectionType(List.class, String.class));
        } catch (JsonProcessingException exception) {
            throw new IllegalStateException("任务标签数据格式错误", exception);
        }
    }

    private String id(Long value) {
        return value == null ? null : value.toString();
    }

    private void validateDeliveryObjects(TaskRequests.DeliverySubmissionCreate request) {
        for (TaskRequests.DeliveryObject object : request.objects()) {
            if (!OBJECT_TYPES.contains(upper(object.objectType()))) {
                throw new TaskException("广告对象类型不合法");
            }
        }
        long campaigns =
                request.objects().stream()
                        .filter(row -> "CAMPAIGN".equals(upper(row.objectType())))
                        .count();
        long adsets =
                request.objects().stream()
                        .filter(row -> "AD_SET".equals(upper(row.objectType())))
                        .count();
        long ads =
                request.objects().stream()
                        .filter(row -> "AD".equals(upper(row.objectType())))
                        .count();
        if (campaigns != request.campaignCount()
                || adsets != request.adsetCount()
                || ads != request.adCount()) {
            throw new TaskException("广告对象明细数量与交付汇总数量不一致");
        }
    }

    private void validateOwnedFiles(List<TaskRequests.FileBinding> inputs, Long uploaderId) {
        List<TaskRequests.FileBinding> files = safe(inputs);
        if (files.isEmpty()) return;
        List<Long> ids =
                files.stream().map(file -> parseId(file.fileId(), "文件")).distinct().toList();
        if (ids.size() != files.size()) throw new TaskException("同一文件不能重复绑定");
        if (mapper.countOwnedFiles(ids, uploaderId) != ids.size()) {
            throw new TaskException("文件不存在、已删除或不属于当前提交用户");
        }
        for (TaskRequests.FileBinding file : files) {
            if (!FILE_USAGES.contains(upper(file.usageType()))) throw new TaskException("文件用途不合法");
        }
    }

    private void bindFiles(
            Long taskId,
            Long targetId,
            String targetType,
            List<TaskRequests.FileBinding> inputs,
            Long userId) {
        for (TaskRequests.FileBinding input : safe(inputs)) {
            mapper.insertFileBinding(
                    taskId,
                    parseId(input.fileId(), "文件"),
                    targetType,
                    targetId,
                    upper(input.usageType()),
                    input.sortOrder(),
                    userId);
        }
    }

    private TaskModels.Task requireVisibleTask(Long id) {
        TaskModels.Task task = requireTask(id);
        Long userId = currentUser().userId();
        if (!userId.equals(task.getCreatorId())
                && !userId.equals(task.getOwnerId())
                && !userId.equals(task.getAssignerId())) {
            throw new TaskException("没有权限查看该任务");
        }
        return task;
    }

    private TaskModels.Task requireTask(Long id) {
        TaskModels.Task task = mapper.findTask(id);
        if (task == null) throw new TaskException("任务不存在或已删除");
        return task;
    }

    private TaskModels.Task requireTaskForUpdate(Long id) {
        TaskModels.Task task = mapper.findTaskForUpdate(id);
        if (task == null) throw new TaskException("任务不存在或已删除");
        return task;
    }

    private String requireActiveUser(Long id, String label) {
        String name = mapper.findActiveUserName(id);
        if (name == null) throw new TaskException(label + "不存在或已停用");
        return name;
    }

    private List<String> distinctRequired(List<String> values, String label) {
        List<String> normalized =
                values.stream()
                        .map(String::trim)
                        .filter(value -> !value.isEmpty())
                        .distinct()
                        .toList();
        if (normalized.isEmpty()) throw new TaskException("请至少选择一个" + label);
        if (normalized.size() != values.size()) throw new TaskException(label + "不能重复");
        return normalized;
    }

    private void requireDictionaryValues(String dictCode, List<String> values, String label) {
        List<String> distinct = values.stream().distinct().toList();
        if (mapper.countEnabledDictionaryValues(dictCode, distinct) != distinct.size()) {
            throw new TaskException(label + "包含不存在或已停用的字典值");
        }
    }

    private String json(List<String> values) {
        try {
            return objectMapper.writeValueAsString(values == null ? List.of() : values);
        } catch (JsonProcessingException exception) {
            throw new TaskException("素材标签格式不正确");
        }
    }

    private CurrentUser currentUser() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (!(principal instanceof CurrentUser user)) throw new TaskException("当前会话未认证");
        return user;
    }

    private Long parseId(String value, String label) {
        try {
            long id = Long.parseLong(value == null ? "" : value.trim());
            if (id <= 0) throw new NumberFormatException();
            return id;
        } catch (NumberFormatException exception) {
            throw new TaskException(label + "ID格式不正确");
        }
    }

    private String optionalUpper(String value) {
        return value == null || value.isBlank() ? null : upper(value);
    }

    private String upper(String value) {
        return value.trim().toUpperCase(Locale.ROOT);
    }

    private String trimToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private <T> List<T> safe(List<T> values) {
        return values == null ? List.of() : values;
    }

    private record CommonCreate(
            TaskRequests.BaseCreate request,
            Long projectId,
            Long ownerId,
            String ownerName,
            String priority) {}

    /** 可安全展示给前端的任务业务异常。 */
    public static class TaskException extends RuntimeException {
        public TaskException(String message) {
            super(message);
        }
    }
}
