package com.adpulse.main.project.service;

import com.adpulse.main.project.dto.ProjectRequests;
import com.adpulse.main.project.dto.ProjectRequests.AgencyLinePatch;
import com.adpulse.main.project.dto.ProjectRequests.AgencyLineSave;
import com.adpulse.main.project.dto.ProjectRequests.ProjectSave;
import com.adpulse.main.project.dto.ProjectViews;
import com.adpulse.main.project.dto.ProjectViews.AgencyLineDetail;
import com.adpulse.main.project.dto.ProjectViews.Kpi;
import com.adpulse.main.project.dto.ProjectViews.ProjectDetail;
import com.adpulse.main.project.mapper.ProjectMapper;
import com.adpulse.main.project.model.AgencyLine;
import com.adpulse.main.project.model.Project;
import com.adpulse.main.project.model.ProjectOptionRow;
import com.adpulse.main.project.model.ProjectStatisticsRow;
import com.adpulse.system.common.security.CurrentUser;
import java.math.BigDecimal;
import java.net.URI;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** 项目及其代理线的业务服务。 */
@Service
public class ProjectService {
    private static final Set<String> TERMINAL_STATUSES = Set.of("ended", "archived");
    private static final Set<String> PROJECT_STATUSES =
            Set.of("draft", "pending", "active", "paused", "ended", "archived");
    private static final Set<String> PRIORITIES = Set.of("low", "normal", "high");
    private static final Set<String> COMPARATORS = Set.of(">=", "<=", "=");
    private final ProjectMapper mapper;

    public ProjectService(ProjectMapper mapper) {
        this.mapper = mapper;
    }

    /** 分页查询项目。 */
    public ProjectViews.Page<ProjectDetail> listProjects(
            String keyword, String status, String platform, int page, int pageSize) {
        int safePage = Math.max(1, page);
        int safeSize = Math.min(1000, Math.max(1, pageSize));
        String normalizedStatus = optionalLower(status);
        String normalizedPlatform = optionalLower(platform);
        List<ProjectDetail> items =
                mapper
                        .findProjects(
                                trimToNull(keyword),
                                normalizedStatus,
                                normalizedPlatform,
                                (safePage - 1) * safeSize,
                                safeSize)
                        .stream()
                        .map(this::detail)
                        .toList();
        return new ProjectViews.Page<>(
                items,
                mapper.countProjects(trimToNull(keyword), normalizedStatus, normalizedPlatform),
                safePage,
                safeSize);
    }

    /** 返回项目页面统计和轻量项目选项。 */
    public ProjectViews.ProjectContext getProjectContext() {
        ProjectStatisticsRow counts = mapper.countProjectStatuses();
        ProjectViews.ProjectStatistics statistics =
                new ProjectViews.ProjectStatistics(
                        counts.getTotal(),
                        counts.getActive(),
                        counts.getDraftOrPending(),
                        counts.getEndedOrArchived());
        Map<Long, ProjectOptionBuilder> options = new LinkedHashMap<>();
        for (ProjectOptionRow row : mapper.findProjectOptionRows()) {
            ProjectOptionBuilder option =
                    options.computeIfAbsent(
                            row.getId(),
                            ignored ->
                                    new ProjectOptionBuilder(
                                            row.getId(),
                                            row.getProjectName(),
                                            row.getProjectCode(),
                                            row.getStatus()));
            if (row.getPlatformValue() != null) {
                option.platforms.add(row.getPlatformValue());
            }
        }
        return new ProjectViews.ProjectContext(
                statistics, options.values().stream().map(ProjectOptionBuilder::view).toList());
    }

    /** 查询项目详情。 */
    public ProjectDetail getProject(Long id) {
        return detail(requireProject(id));
    }

    /** 创建项目。 */
    @Transactional
    public ProjectDetail createProject(ProjectSave request) {
        Project project = new Project();
        project.setProjectCode(normalizeProjectCode(request.projectCode()));
        apply(project, request);
        Long operatorId = currentUserId();
        project.setCreatedBy(operatorId);
        project.setUpdatedBy(operatorId);
        try {
            mapper.insertProject(project);
            replaceChildren(project.getId(), request, operatorId);
        } catch (DuplicateKeyException exception) {
            throw new ProjectException("项目编码已存在，请使用其他编码");
        }
        return getProject(project.getId());
    }

    /** 修改非结束、非归档项目。 */
    @Transactional
    public ProjectDetail updateProject(Long id, ProjectSave request) {
        Project project = requireMutableProject(id);
        Set<String> requestedPlatforms = new HashSet<>(distinctLower(request.platforms()));
        boolean hasUnsupportedBoundLine =
                mapper.findAgencyLines(null, null, id, 0, Integer.MAX_VALUE).stream()
                        .anyMatch(line -> !requestedPlatforms.contains(line.getPlatformValue()));
        if (hasUnsupportedBoundLine) {
            throw new ProjectException("请先解绑不属于新投放平台范围的代理线");
        }
        apply(project, request);
        project.setUpdatedBy(currentUserId());
        mapper.updateProject(project);
        replaceChildren(id, request, project.getUpdatedBy());
        return getProject(id);
    }

    /** 增量绑定或解绑代理线。 */
    @Transactional
    public ProjectDetail patchAgencyLines(Long projectId, AgencyLinePatch request) {
        Project project = requireMutableProject(projectId);
        Set<Long> add = parseIds(request.add());
        Set<Long> remove = parseIds(request.remove());
        if (add.stream().anyMatch(remove::contains)) {
            throw new ProjectException("同一代理线不能同时绑定和解绑");
        }
        Long operatorId = currentUserId();
        for (Long lineId : remove) {
            requireAgencyLine(lineId);
            mapper.unbindAgencyLine(lineId, projectId, operatorId);
        }
        for (Long lineId : add) {
            bind(project, requireAgencyLine(lineId), operatorId);
        }
        return getProject(projectId);
    }

    /** 使用代理线ID集合覆盖项目当前绑定。 */
    @Transactional
    public ProjectDetail replaceAgencyLines(Long projectId, List<String> lineIds) {
        Project project = requireMutableProject(projectId);
        Set<Long> requested = parseIds(lineIds);
        Long operatorId = currentUserId();
        for (AgencyLine current :
                mapper.findAgencyLines(null, null, projectId, 0, Integer.MAX_VALUE)) {
            if (!requested.contains(current.getId())) {
                mapper.unbindAgencyLine(current.getId(), projectId, operatorId);
            }
        }
        for (Long lineId : requested) {
            bind(project, requireAgencyLine(lineId), operatorId);
        }
        return getProject(projectId);
    }

    /** 返回尚未接入经营域时的空经营概览。 */
    public ProjectViews.OperatingOverview operatingOverview(Long id) {
        ProjectDetail project = getProject(id);
        return new ProjectViews.OperatingOverview(
                project,
                BigDecimal.ZERO,
                BigDecimal.ZERO,
                "USD",
                "unsettled",
                false,
                LocalDateTime.now().toString(),
                0,
                List.of(),
                0,
                List.of(),
                0,
                0,
                "missing",
                "项目经营指标暂未接入，当前仅展示项目主数据。");
    }

    /** 分页查询代理线。 */
    public ProjectViews.Page<AgencyLineDetail> listAgencyLines(
            String keyword, String platform, Long projectId, int page, int pageSize) {
        int safePage = Math.max(1, page);
        int safeSize = Math.min(1000, Math.max(1, pageSize));
        String normalizedPlatform = optionalLower(platform);
        List<AgencyLineDetail> items =
                mapper
                        .findAgencyLines(
                                trimToNull(keyword),
                                normalizedPlatform,
                                projectId,
                                (safePage - 1) * safeSize,
                                safeSize)
                        .stream()
                        .map(this::detail)
                        .toList();
        return new ProjectViews.Page<>(
                items,
                mapper.countAgencyLines(trimToNull(keyword), normalizedPlatform, projectId),
                safePage,
                safeSize);
    }

    /** 查询单条代理线。 */
    public AgencyLineDetail getAgencyLine(Long id) {
        return detail(requireAgencyLine(id));
    }

    /** 创建代理线并可选绑定一个项目。 */
    @Transactional
    public AgencyLineDetail createAgencyLine(
            AgencyLineSave request, String wrapperProjectId, String requestId) {
        String normalizedRequestId = trimToNull(requestId);
        if (normalizedRequestId != null) {
            AgencyLine existing = mapper.findAgencyLineByRequestId(normalizedRequestId);
            if (existing != null) {
                return detail(existing);
            }
        }
        AgencyLine line = new AgencyLine();
        apply(line, request, wrapperProjectId);
        line.setRequestId(normalizedRequestId);
        Long operatorId = currentUserId();
        line.setCreatedBy(operatorId);
        line.setUpdatedBy(operatorId);
        try {
            mapper.insertAgencyLine(line);
        } catch (DuplicateKeyException exception) {
            AgencyLine existing =
                    normalizedRequestId == null
                            ? null
                            : mapper.findAgencyLineByRequestId(normalizedRequestId);
            if (existing != null) {
                return detail(existing);
            }
            throw new ProjectException("代理线名称已存在，请使用其他名称");
        }
        return getAgencyLine(line.getId());
    }

    /** 修改代理线；所属项目结束或归档后禁止修改。 */
    @Transactional
    public AgencyLineDetail updateAgencyLine(Long id, AgencyLineSave request) {
        AgencyLine line = requireAgencyLine(id);
        requireLineMutable(line);
        apply(line, request, request.projectId());
        line.setUpdatedBy(currentUserId());
        try {
            mapper.updateAgencyLine(line);
        } catch (DuplicateKeyException exception) {
            throw new ProjectException("代理线名称已存在，请使用其他名称");
        }
        return getAgencyLine(id);
    }

    /** 软删除代理线。 */
    @Transactional
    public void deleteAgencyLine(Long id) {
        AgencyLine line = requireAgencyLine(id);
        requireLineMutable(line);
        mapper.softDeleteAgencyLine(id, System.currentTimeMillis(), currentUserId());
    }

    private void apply(Project project, ProjectSave request) {
        validateUserPair(request.amUserId(), request.amName(), "AM");
        validateUserPair(request.deliveryLeaderId(), request.deliveryLeaderName(), "投放负责人");
        String status = lower(request.status());
        if (!PROJECT_STATUSES.contains(status)) {
            throw new ProjectException("项目状态不合法");
        }
        String priority = lower(request.priority());
        if (!PRIORITIES.contains(priority)) {
            throw new ProjectException("项目优先级不合法");
        }
        request.kpiRequirements()
                .forEach(
                        kpi -> {
                            if (!COMPARATORS.contains(kpi.comparator())) {
                                throw new ProjectException("KPI比较符不合法");
                            }
                        });
        request.platforms().forEach(value -> requireDictionaryValue("AD_MEDIA", value));
        request.countryRegions().forEach(value -> requireDictionaryValue("PROJECT_REGION", value));
        project.setProjectName(request.name().trim());
        project.setResponsibleTeam(request.responsibleTeam().trim());
        project.setAmUserId(optionalId(request.amUserId(), "AM用户ID"));
        project.setAmName(trimToNull(request.amName()));
        project.setDeliveryLeaderId(optionalId(request.deliveryLeaderId(), "投放负责人ID"));
        project.setDeliveryLeaderName(trimToNull(request.deliveryLeaderName()));
        project.setOutsourced(request.isOutsourced());
        project.setPriority(priority);
        project.setServiceFeePercent(request.serviceFeePercent());
        project.setStatus(status);
        project.setProductInfo(request.productInfo().trim());
        project.setCustomerDailyReportUrl(validateUrl(request.customerDailyReportUrl()));
    }

    private void apply(AgencyLine line, AgencyLineSave request, String wrapperProjectId) {
        Long projectId = optionalId(firstNonBlank(request.projectId(), wrapperProjectId), "项目ID");
        Project project = projectId == null ? null : requireMutableProject(projectId);
        String platform = lower(request.platform());
        requireDictionaryValue("AD_MEDIA", platform);
        if (project != null && !mapper.findPlatforms(projectId).contains(platform)) {
            throw new ProjectException("代理线平台不在项目投放范围内");
        }
        Long optimizerId = requiredId(request.optimizerId(), "优化师ID");
        if (mapper.countActiveUser(optimizerId) != 1) {
            throw new ProjectException("优化师不存在或已停用");
        }
        line.setProjectId(projectId);
        line.setLineName(request.name().trim());
        line.setPlatformValue(platform);
        line.setDeliveryUrl(validateUrl(request.deliveryUrl()));
        line.setPixelName(request.pixelName().trim());
        line.setOptimizerId(optimizerId);
        line.setOptimizerName(request.optimizerName().trim());
    }

    private void replaceChildren(Long id, ProjectSave request, Long operatorId) {
        long deletedAt = System.currentTimeMillis();
        mapper.softDeletePlatforms(id, deletedAt);
        mapper.softDeleteRegions(id, deletedAt);
        mapper.softDeleteKpis(id, deletedAt, operatorId);
        distinctLower(request.platforms())
                .forEach(value -> mapper.insertPlatform(id, value, operatorId));
        distinctTrimmed(request.countryRegions())
                .forEach(value -> mapper.insertRegion(id, value, operatorId));
        for (int index = 0; index < request.kpiRequirements().size(); index++) {
            ProjectRequests.KpiSave kpi = request.kpiRequirements().get(index);
            mapper.insertKpi(
                    id, kpi.metric().trim(), kpi.comparator(), kpi.target(), index, operatorId);
        }
    }

    private void bind(Project project, AgencyLine line, Long operatorId) {
        if (line.getProjectId() != null && !line.getProjectId().equals(project.getId())) {
            throw new ProjectException("代理线“" + line.getLineName() + "”已关联其他项目");
        }
        if (!mapper.findPlatforms(project.getId()).contains(line.getPlatformValue())) {
            throw new ProjectException("代理线“" + line.getLineName() + "”的平台不在项目投放范围内");
        }
        if (mapper.bindAgencyLine(line.getId(), project.getId(), operatorId) != 1) {
            throw new ProjectException("代理线绑定状态已变化，请刷新后重试");
        }
    }

    private ProjectDetail detail(Project project) {
        List<Kpi> kpis = mapper.findKpis(project.getId());
        List<AgencyLine> lines =
                mapper.findAgencyLines(null, null, project.getId(), 0, Integer.MAX_VALUE);
        String productName =
                project.getProductInfo().length() > 80
                        ? project.getProductInfo().substring(0, 80)
                        : project.getProductInfo();
        return new ProjectDetail(
                project.getId().toString(),
                project.getProjectCode(),
                project.getProjectName(),
                productName,
                project.getProductInfo(),
                project.getResponsibleTeam(),
                string(project.getAmUserId()),
                project.getAmName(),
                string(project.getDeliveryLeaderId()),
                project.getDeliveryLeaderName(),
                Boolean.TRUE.equals(project.getOutsourced()),
                project.getPriority(),
                mapper.findPlatforms(project.getId()),
                mapper.findRegions(project.getId()),
                project.getServiceFeePercent(),
                project.getStatus(),
                project.getCustomerDailyReportUrl(),
                kpis,
                kpis.isEmpty() ? "" : kpis.getFirst().metric(),
                lines.stream().map(line -> line.getId().toString()).toList(),
                lines.stream().map(AgencyLine::getLineName).toList(),
                List.of(),
                0,
                0,
                BigDecimal.ZERO,
                "USD",
                "",
                "UTC+8",
                LocalDate.now().toString(),
                List.of(),
                "",
                false,
                project.getUpdatedAt());
    }

    private AgencyLineDetail detail(AgencyLine line) {
        return new AgencyLineDetail(
                line.getId().toString(),
                string(line.getProjectId()),
                line.getLineName(),
                line.getPlatformValue(),
                line.getDeliveryUrl() == null ? "" : line.getDeliveryUrl(),
                line.getPixelName(),
                line.getOptimizerId().toString(),
                line.getOptimizerName(),
                true,
                false,
                false,
                "",
                "",
                "",
                "",
                line.getUpdatedAt());
    }

    private Project requireProject(Long id) {
        Project project = mapper.findProject(id);
        if (project == null) {
            throw new ProjectException("项目不存在或已被删除");
        }
        return project;
    }

    private Project requireMutableProject(Long id) {
        Project project = requireProject(id);
        if (TERMINAL_STATUSES.contains(project.getStatus())) {
            throw new ProjectException("结束或归档项目不允许修改或绑定代理线");
        }
        return project;
    }

    private AgencyLine requireAgencyLine(Long id) {
        AgencyLine line = mapper.findAgencyLine(id);
        if (line == null) {
            throw new ProjectException("代理线不存在或已被删除");
        }
        return line;
    }

    private void requireLineMutable(AgencyLine line) {
        if (line.getProjectId() != null) {
            requireMutableProject(line.getProjectId());
        }
    }

    private void validateUserPair(String rawId, String name, String label) {
        boolean hasId = rawId != null && !rawId.isBlank();
        boolean hasName = name != null && !name.isBlank();
        if (hasId != hasName) {
            throw new ProjectException(label + "必须同时保存用户ID和姓名");
        }
        if (hasId && mapper.countActiveUser(requiredId(rawId, label + "用户ID")) != 1) {
            throw new ProjectException(label + "用户不存在或已停用");
        }
    }

    private void requireDictionaryValue(String dictCode, String value) {
        if (mapper.countEnabledDictionaryValue(dictCode, value.trim()) != 1) {
            throw new ProjectException("字典“" + dictCode + "”中不存在启用值：" + value);
        }
    }

    private Set<Long> parseIds(List<String> ids) {
        Set<Long> result = new HashSet<>();
        if (ids != null) {
            ids.forEach(value -> result.add(requiredId(value, "代理线ID")));
        }
        return result;
    }

    private Long optionalId(String value, String label) {
        return value == null || value.isBlank() ? null : requiredId(value, label);
    }

    private Long requiredId(String value, String label) {
        try {
            return Long.valueOf(value.trim());
        } catch (RuntimeException exception) {
            throw new ProjectException(label + "格式不正确");
        }
    }

    private String validateUrl(String raw) {
        String value = trimToNull(raw);
        if (value == null) {
            return null;
        }
        try {
            String scheme = URI.create(value).getScheme();
            if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme)) {
                throw new IllegalArgumentException();
            }
            return value;
        } catch (RuntimeException exception) {
            throw new ProjectException("链接必须是有效的http(s)地址");
        }
    }

    private List<String> distinctLower(List<String> values) {
        return values.stream().map(this::lower).distinct().toList();
    }

    private List<String> distinctTrimmed(List<String> values) {
        return values.stream().map(String::trim).distinct().toList();
    }

    private String normalizeProjectCode(String value) {
        return value.trim().toUpperCase(Locale.ROOT);
    }

    private String lower(String value) {
        return value.trim().toLowerCase(Locale.ROOT);
    }

    private String optionalLower(String value) {
        return value == null || value.isBlank() ? null : lower(value);
    }

    private String trimToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String firstNonBlank(String first, String second) {
        return first != null && !first.isBlank() ? first : second;
    }

    private String string(Long value) {
        return value == null ? null : value.toString();
    }

    private Long currentUserId() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (!(principal instanceof CurrentUser user)) {
            throw new ProjectException("当前会话未认证");
        }
        return user.userId();
    }

    private static final class ProjectOptionBuilder {
        private final Long id;
        private final String name;
        private final String projectCode;
        private final String status;
        private final List<String> platforms = new java.util.ArrayList<>();

        private ProjectOptionBuilder(Long id, String name, String projectCode, String status) {
            this.id = id;
            this.name = name;
            this.projectCode = projectCode;
            this.status = status;
        }

        private ProjectViews.ProjectOption view() {
            return new ProjectViews.ProjectOption(
                    id.toString(), name, projectCode, status, List.copyOf(platforms));
        }
    }

    /** 可安全展示给前端的项目业务异常。 */
    public static class ProjectException extends RuntimeException {
        public ProjectException(String message) {
            super(message);
        }
    }
}
