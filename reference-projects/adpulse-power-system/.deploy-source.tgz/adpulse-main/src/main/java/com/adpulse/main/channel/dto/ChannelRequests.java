package com.adpulse.main.channel.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;

/** 渠道管理写入与查询请求。 */
public final class ChannelRequests {
    private ChannelRequests() {}

    /** 渠道列表查询。 */
    public record ChannelQuery(
            String channelName,
            String status,
            String belongTeam,
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate,
            Integer page,
            Integer pageSize) {}

    /** 渠道保存请求；修改时未传字段保持原值。 */
    public record ChannelSave(
            @Size(max = 50) String channelName,
            @Size(max = 15) String channelShortName,
            @Size(max = 10) String channelCode,
            Integer channelType,
            @Size(max = 50) String belongTeam,
            Integer status,
            @Size(max = 50) String settlementMethod,
            @Size(max = 10) String settlementCurrency,
            @DecimalMin("0") BigDecimal buyoutAmount,
            @DecimalMin("0") BigDecimal rechargeAmount,
            @Size(max = 1000) String paymentAddress,
            @Size(max = 1000) String loginUrl,
            @Size(max = 500) String remark,
            String tgGroupId,
            @Size(max = 100) String tgGroupName) {}

    /** 费率保存请求。 */
    public record RateSave(
            @NotNull @DecimalMin("0") BigDecimal serviceFee,
            @NotNull @DecimalMin("0") BigDecimal rebateRate,
            @NotNull LocalDate effectiveDate,
            LocalDate expiryDate) {}

    /** 账户类型保存请求。 */
    public record AccountTypeSave(
            @NotBlank @Size(max = 15) String accountType,
            @NotBlank @Size(max = 10) String accountTypeCode) {}

    /** 渠道账户分页查询。 */
    public record AccountQuery(
            Long channelId,
            String accountType,
            List<String> accountIds,
            String bmId,
            String subjectName,
            String operatorName,
            Long belongTeamId,
            Integer timezone,
            Integer status,
            Integer usageStatus,
            BigDecimal consumptionMin,
            BigDecimal consumptionMax,
            BigDecimal balanceMin,
            BigDecimal balanceMax,
            LocalDate startDate,
            LocalDate endDate,
            Integer page,
            Integer pageSize,
            List<String> includeFields) {}

    /** 修改账户使用状态。 */
    public record AccountUsageSave(@NotNull Integer usageStatus) {}

    /** 批量分配投手。 */
    public record AccountAssign(
            @NotEmpty List<@NotBlank String> accountIds, @NotNull Long operatorId) {}

    /** 单个账户批量导入项。 */
    public record AccountImportItem(
            @NotBlank @Size(max = 64) String accountId,
            @NotBlank @Size(max = 15) String accountType) {}

    /** 批量新增渠道账户。 */
    public record AccountBatch(
            @NotNull Long channelId, @NotEmpty List<@Valid AccountImportItem> accounts) {}

    /** 渠道商品保存请求。 */
    public record GoodsSave(
            @NotBlank @Size(max = 100) String goodsName,
            @Size(max = 500) String launchRegion,
            @NotNull @DecimalMin("1") Integer minBuyLimit,
            @NotNull @DecimalMin("0") BigDecimal rebateRate,
            @Size(max = 500) String remark,
            @NotNull @DecimalMin("0") BigDecimal serviceFeeRatio,
            @NotNull @DecimalMin("1") Integer stockNum,
            @Size(max = 500) String timezone) {}

    /** 商品上下架请求。 */
    public record PutawaySave(@NotNull Integer putawayStatus) {}
}
