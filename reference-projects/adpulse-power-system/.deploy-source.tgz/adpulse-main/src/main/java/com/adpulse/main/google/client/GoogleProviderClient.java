package com.adpulse.main.google.client;

import com.adpulse.main.google.config.GoogleIntegrationProperties;
import com.adpulse.main.google.dto.GoogleDtos.DriveFile;
import com.adpulse.main.google.dto.GoogleDtos.SheetTab;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestClient;
import org.springframework.web.util.UriComponentsBuilder;

/** Google OAuth、Drive和Sheets REST客户端。 */
@Component
public class GoogleProviderClient {
    private final GoogleIntegrationProperties properties;
    private final RestClient client = RestClient.create();

    public GoogleProviderClient(GoogleIntegrationProperties properties) {
        this.properties = properties;
    }

    /** 生成Google OAuth授权地址。 */
    public String authorizeUrl(String state) {
        requireConfigured();
        return UriComponentsBuilder.fromUriString("https://accounts.google.com/o/oauth2/v2/auth")
                .queryParam("client_id", properties.clientId())
                .queryParam("redirect_uri", properties.redirectUri())
                .queryParam("response_type", "code")
                .queryParam(
                        "scope",
                        "openid email profile https://www.googleapis.com/auth/drive.readonly https://www.googleapis.com/auth/spreadsheets.readonly")
                .queryParam("access_type", "offline")
                .queryParam("prompt", "consent")
                .queryParam("state", state)
                .build()
                .encode()
                .toUriString();
    }

    /** 使用授权码交换访问令牌。 */
    public Token exchange(String code) {
        requireConfigured();
        var form = new LinkedMultiValueMap<String, String>();
        form.add("code", code);
        form.add("client_id", properties.clientId());
        form.add("client_secret", properties.clientSecret());
        form.add("redirect_uri", properties.redirectUri());
        form.add("grant_type", "authorization_code");
        return token(
                client.post()
                        .uri("https://oauth2.googleapis.com/token")
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                        .body(form)
                        .retrieve()
                        .body(Map.class));
    }

    /** 使用刷新令牌获取新的访问令牌。 */
    public Token refresh(String refreshToken) {
        requireConfigured();
        var form = new LinkedMultiValueMap<String, String>();
        form.add("refresh_token", refreshToken);
        form.add("client_id", properties.clientId());
        form.add("client_secret", properties.clientSecret());
        form.add("grant_type", "refresh_token");
        return token(
                client.post()
                        .uri("https://oauth2.googleapis.com/token")
                        .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                        .body(form)
                        .retrieve()
                        .body(Map.class));
    }

    /** 查询Google用户稳定标识与展示资料。 */
    public UserInfo userInfo(String accessToken) {
        Map<?, ?> data = get("https://www.googleapis.com/oauth2/v3/userinfo", accessToken);
        return new UserInfo(
                text(data.get("sub")), text(data.get("email")), text(data.get("picture")));
    }

    /** 查询账号可访问的Google Sheets文件。 */
    public List<DriveFile> files(String accessToken, String keyword) {
        String q = "mimeType='application/vnd.google-apps.spreadsheet' and trashed=false";
        if (keyword != null && !keyword.isBlank())
            q += " and name contains '" + keyword.replace("'", "\\'") + "'";
        URI uri =
                UriComponentsBuilder.fromUriString("https://www.googleapis.com/drive/v3/files")
                        .queryParam("q", q)
                        .queryParam("fields", "files(id,name,modifiedTime)")
                        .queryParam("pageSize", 100)
                        .build()
                        .encode()
                        .toUri();
        Map<?, ?> data = get(uri.toString(), accessToken);
        List<DriveFile> result = new ArrayList<>();
        for (Object value : list(data.get("files"))) {
            Map<?, ?> item = map(value);
            if (item != null)
                result.add(
                        new DriveFile(
                                text(item.get("id")),
                                text(item.get("name")),
                                text(item.get("modifiedTime"))));
        }
        return result;
    }

    /** 查询Spreadsheet全部Sheet名称。 */
    public List<SheetTab> sheets(String accessToken, String fileId) {
        Map<?, ?> data =
                get(
                        "https://sheets.googleapis.com/v4/spreadsheets/"
                                + fileId
                                + "?fields=sheets.properties.title",
                        accessToken);
        List<SheetTab> result = new ArrayList<>();
        for (Object value : list(data.get("sheets"))) {
            Map<?, ?> sheet = map(value);
            Map<?, ?> props = sheet == null ? null : map(sheet.get("properties"));
            if (props != null) result.add(new SheetTab(text(props.get("title"))));
        }
        return result;
    }

    /** 查询Sheet第一行作为字段名称。 */
    public List<String> columns(String accessToken, String fileId, String sheetName) {
        String range =
                UriComponentsBuilder.newInstance()
                        .pathSegment(sheetName + "!1:1")
                        .build()
                        .encode()
                        .toUriString();
        Map<?, ?> data =
                get(
                        "https://sheets.googleapis.com/v4/spreadsheets/"
                                + fileId
                                + "/values/"
                                + range,
                        accessToken);
        List<?> rows = list(data.get("values"));
        if (rows.isEmpty()) return List.of();
        return list(rows.getFirst()).stream().map(this::text).toList();
    }

    private Map<?, ?> get(String uri, String token) {
        Map<?, ?> result =
                client.get()
                        .uri(uri)
                        .header("Authorization", "Bearer " + token)
                        .retrieve()
                        .body(Map.class);
        if (result == null) throw new GoogleProviderException("Google接口无响应");
        return result;
    }

    private Token token(Map<?, ?> data) {
        if (data == null || data.get("access_token") == null)
            throw new GoogleProviderException("Google未返回访问令牌");
        return new Token(
                text(data.get("access_token")),
                text(data.get("refresh_token")),
                number(data.get("expires_in")));
    }

    private void requireConfigured() {
        if (properties.clientId() == null
                || properties.clientId().isBlank()
                || properties.clientSecret() == null
                || properties.clientSecret().isBlank()
                || properties.redirectUri() == null
                || properties.redirectUri().isBlank())
            throw new GoogleProviderException("测试环境尚未配置Google OAuth凭证");
    }

    private Map<?, ?> map(Object value) {
        return value instanceof Map<?, ?> result ? result : null;
    }

    private List<?> list(Object value) {
        return value instanceof List<?> result ? result : List.of();
    }

    private String text(Object value) {
        return value == null ? "" : value.toString();
    }

    private long number(Object value) {
        return value instanceof Number number ? number.longValue() : 3600;
    }

    /** Google令牌响应。 */
    public record Token(String accessToken, String refreshToken, long expiresIn) {}

    /** Google用户资料。 */
    public record UserInfo(String subject, String email, String picture) {}

    /** Google开放平台调用异常。 */
    public static class GoogleProviderException extends RuntimeException {
        /** 创建Google开放平台调用异常。 */
        public GoogleProviderException(String message) {
            super(message);
        }
    }
}
