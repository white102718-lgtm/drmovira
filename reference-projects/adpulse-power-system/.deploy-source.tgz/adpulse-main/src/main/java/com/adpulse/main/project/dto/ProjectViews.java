package com.adpulse.main.project.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/** 项目管理接口响应模型。 */
public final class ProjectViews {
    private ProjectViews() {}

    /** KPI响应。 */
    public record Kpi(String metric, String comparator, BigDecimal target) {}

    /** 项目详情，保留少量前端兼容投影但不持久化未来字段。 */
    public record ProjectDetail(
            String id,
            String projectCode,
            String name,
            String productName,
            String productInfo,
            String responsibleTeam,
            String amUserId,
            String amName,
            String deliveryLeaderId,
            String deliveryLeaderName,
            boolean isOutsourced,
            String priority,
            List<String> platforms,
            List<String> countryRegions,
            BigDecimal serviceFeePercent,
            String status,
            String customerDailyReportUrl,
            List<Kpi> kpiRequirements,
            String primaryKpi,
            List<String> agencyLineIds,
            List<String> agentLines,
            List<Object> deliveryLines,
            int adAccountCount,
            int materialCount,
            BigDecimal dailyBudget,
            String currency,
            String attributionWindow,
            String timezone,
            String startDate,
            List<String> mediaChannelIds,
            String dataSpecialist,
            boolean createWallet,
            LocalDateTime updatedAt) {}

    /** 代理线详情。 */
    public record AgencyLineDetail(
            String id,
            String projectId,
            String name,
            String platform,
            String deliveryUrl,
            String pixelName,
            String optimizerId,
            String optimizerName,
            boolean enabled,
            boolean autoRun,
            boolean isSend,
            String objective,
            String packageName,
            String packageType,
            String pageId,
            LocalDateTime updatedAt) {}

    /** 分页响应。 */
    public record Page<T>(List<T> items, long total, int page, int pageSize) {}

    /** 项目页面初始化所需的轻量上下文。 */
    public record ProjectContext(ProjectStatistics statistics, List<ProjectOption> options) {}

    /** 项目状态统计。 */
    public record ProjectStatistics(
            long total, long active, long draftOrPending, long endedOrArchived) {}

    /** 代理线筛选及创建所需的轻量项目选项。 */
    public record ProjectOption(
            String id, String name, String projectCode, String status, List<String> platforms) {}

    /** 暂未接入经营数据时的稳定空概览。 */
    public record OperatingOverview(
            ProjectDetail project,
            BigDecimal actualSpend,
            BigDecimal settledAmount,
            String currency,
            String settlementStatus,
            boolean attributionCompleted,
            String metricCutoff,
            int completedPlanCount,
            List<Object> completedPlans,
            int completedTaskCount,
            List<Object> completedTasks,
            int totalPlanCount,
            int totalTaskCount,
            String dataQualityStatus,
            String dataQualityNote) {}
}
