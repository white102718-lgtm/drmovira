package com.adpulse.main.channel.service;

import com.adpulse.main.channel.dto.ChannelRequests;
import com.adpulse.main.channel.dto.ChannelRequests.AccountBatch;
import com.adpulse.main.channel.dto.ChannelRequests.AccountImportItem;
import com.adpulse.main.channel.dto.ChannelRequests.AccountQuery;
import com.adpulse.main.channel.dto.ChannelRequests.AccountTypeSave;
import com.adpulse.main.channel.dto.ChannelRequests.ChannelQuery;
import com.adpulse.main.channel.dto.ChannelRequests.ChannelSave;
import com.adpulse.main.channel.dto.ChannelRequests.GoodsSave;
import com.adpulse.main.channel.dto.ChannelRequests.RateSave;
import com.adpulse.main.channel.dto.ChannelViews;
import com.adpulse.main.channel.mapper.ChannelMapper;
import com.adpulse.main.channel.model.ChannelModels.Account;
import com.adpulse.main.channel.model.ChannelModels.AccountType;
import com.adpulse.main.channel.model.ChannelModels.Aggregate;
import com.adpulse.main.channel.model.ChannelModels.Channel;
import com.adpulse.main.channel.model.ChannelModels.Department;
import com.adpulse.main.channel.model.ChannelModels.Goods;
import com.adpulse.main.channel.model.ChannelModels.Rate;
import com.adpulse.system.common.security.CurrentUser;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/** 渠道、费率、关联账户与上架信息业务服务。 */
@Service
public class ChannelService {
    private static final BigDecimal ZERO = BigDecimal.ZERO;
    private final ChannelMapper mapper;
    private final ChannelExcelCodec excelCodec;
    private final AccountSnapshotProvider accountSnapshotProvider;

    public ChannelService(
            ChannelMapper mapper,
            ChannelExcelCodec excelCodec,
            AccountSnapshotProvider accountSnapshotProvider) {
        this.mapper = mapper;
        this.excelCodec = excelCodec;
        this.accountSnapshotProvider = accountSnapshotProvider;
    }

    /** 分页查询渠道。 */
    public ChannelViews.Page<ChannelViews.ChannelDetail> listChannels(ChannelQuery query) {
        int page = safePage(query.page());
        int size = safeSize(query.pageSize());
        List<ChannelViews.ChannelDetail> items =
                mapper.findChannels(query, (page - 1) * size, size).stream()
                        .map(this::channelView)
                        .toList();
        return new ChannelViews.Page<>(items, mapper.countChannels(query), page, size);
    }

    /** 查询渠道汇总。 */
    public ChannelViews.ChannelSummary summarizeChannels(ChannelQuery query) {
        Aggregate value = mapper.summarizeChannels(query);
        return new ChannelViews.ChannelSummary(
                longValue(value == null ? null : value.getChannelCount()),
                longValue(value == null ? null : value.getAccountCount()),
                money(value == null ? null : value.getTotalConsumption()),
                money(value == null ? null : value.getRechargeAmount()),
                money(value == null ? null : value.getTotalBalance()));
    }

    /** 分页查询账户类型维度汇总。 */
    public ChannelViews.Page<ChannelViews.ChannelTypeSummary> listTypeSummaries(
            ChannelQuery query) {
        int page = safePage(query.page());
        int size = safeSize(query.pageSize());
        var items =
                mapper.findTypeSummaries(query, (page - 1) * size, size).stream()
                        .map(
                                item ->
                                        new ChannelViews.ChannelTypeSummary(
                                                stringId(item.getId()),
                                                item.getAccountType(),
                                                item.getAccountTypeCode(),
                                                item.getSubjectName(),
                                                item.getChannelName(),
                                                item.getChannelType(),
                                                money(item.getTotalConsumption()),
                                                item.getUsageStatus()))
                        .toList();
        return new ChannelViews.Page<>(items, mapper.countTypeSummaries(query), page, size);
    }

    /** 查询渠道详情。 */
    public ChannelViews.ChannelDetail getChannel(Long id) {
        return channelView(requireChannel(id));
    }

    /**
     * 查询打款申请所需的渠道快照。
     *
     * <p>昨日消耗按广告系列日花费汇总，收款地址读取渠道当前配置；申请提交时仍会把返回值固化到申请快照。
     */
    public ChannelViews.ChannelPaymentContext getPaymentContext(Long id) {
        Channel channel = requireChannel(id);
        BigDecimal yesterdaySpend = mapper.sumChannelSpend(id, LocalDate.now().minusDays(1));
        return new ChannelViews.ChannelPaymentContext(
                stringId(channel.getId()),
                channel.getChannelName(),
                money(yesterdaySpend),
                channel.getPaymentAddress());
    }

    /** 创建渠道。 */
    @Transactional
    public ChannelViews.ChannelDetail createChannel(ChannelSave request) {
        validateRequiredChannel(request);
        Channel channel = new Channel();
        mergeChannel(channel, request);
        channel.setPutawayStatus(0);
        channel.setBuyoutAmount(money(request.buyoutAmount()));
        channel.setRechargeAmount(money(request.rechargeAmount()));
        channel.setCreatedBy(actorId());
        channel.setUpdatedBy(actorId());
        try {
            mapper.insertChannel(channel);
        } catch (DuplicateKeyException exception) {
            throw new ChannelException("渠道编码或名称已存在");
        }
        return getChannel(channel.getId());
    }

    /** 修改渠道，未传字段保持原值。 */
    @Transactional
    public ChannelViews.ChannelDetail updateChannel(Long id, ChannelSave request) {
        Channel channel = requireChannel(id);
        mergeChannel(channel, request);
        channel.setUpdatedBy(actorId());
        try {
            mapper.updateChannel(channel);
        } catch (DuplicateKeyException exception) {
            throw new ChannelException("渠道编码或名称已存在");
        }
        return getChannel(id);
    }

    /** 软删除渠道；存在有效账户时拒绝删除。 */
    @Transactional
    public void deleteChannel(Long id) {
        requireChannel(id);
        AccountQuery query =
                new AccountQuery(
                        id, null, null, null, null, null, null, null, null, null, null, null, null,
                        null, null, null, 1, 1, null);
        if (mapper.countAccounts(query) > 0) {
            throw new ChannelException("渠道仍有关联账户，不能删除");
        }
        mapper.softDeleteChannel(id, System.currentTimeMillis(), actorId());
    }

    /** 分页查询渠道费率。 */
    public ChannelViews.Page<ChannelViews.Rate> listRates(Long channelId, int page, int pageSize) {
        requireChannel(channelId);
        int safePage = safePage(page);
        int safeSize = safeSize(pageSize);
        var items =
                mapper.findRates(channelId, (safePage - 1) * safeSize, safeSize).stream()
                        .map(this::rateView)
                        .toList();
        return new ChannelViews.Page<>(items, mapper.countRates(channelId), safePage, safeSize);
    }

    /** 创建渠道费率，生效区间不可重叠。 */
    @Transactional
    public ChannelViews.Rate createRate(Long channelId, RateSave request) {
        requireChannel(channelId);
        validateRate(channelId, null, request);
        Rate rate = new Rate();
        rate.setChannelId(channelId);
        applyRate(rate, request);
        rate.setCreatedBy(actorId());
        rate.setUpdatedBy(actorId());
        mapper.insertRate(rate);
        return rateView(Objects.requireNonNull(mapper.findRate(rate.getId())));
    }

    /** 修改渠道费率。 */
    @Transactional
    public ChannelViews.Rate updateRate(Long channelId, Long rateId, RateSave request) {
        Rate rate = mapper.findRate(rateId);
        if (rate == null || !channelId.equals(rate.getChannelId())) {
            throw new ChannelException("费率不存在");
        }
        validateRate(channelId, rateId, request);
        applyRate(rate, request);
        rate.setUpdatedBy(actorId());
        mapper.updateRate(rate);
        return rateView(Objects.requireNonNull(mapper.findRate(rateId)));
    }

    /** 查询全部账户类型。 */
    public List<ChannelViews.AccountType> listAccountTypes() {
        return mapper.findAccountTypes().stream().map(this::accountTypeView).toList();
    }

    /** 新增账户类型。 */
    @Transactional
    public ChannelViews.AccountType createAccountType(AccountTypeSave request) {
        AccountType model = new AccountType();
        model.setAccountType(request.accountType().trim());
        model.setAccountTypeCode(request.accountTypeCode().trim());
        model.setCreatedBy(actorId());
        try {
            mapper.insertAccountType(model);
        } catch (DuplicateKeyException exception) {
            throw new ChannelException("账户类型名称或编码已存在");
        }
        return accountTypeView(Objects.requireNonNull(mapper.findAccountType(model.getId())));
    }

    /** 删除账户类型并将已绑定账户改为未分类。 */
    @Transactional
    public void deleteAccountType(Long id) {
        AccountType type = mapper.findAccountType(id);
        if (type == null) throw new ChannelException("账户类型不存在");
        mapper.detachAccountType(type.getAccountType(), actorId());
        mapper.softDeleteAccountType(id, System.currentTimeMillis());
    }

    /** 分页查询渠道账户。 */
    public ChannelViews.Page<ChannelViews.Account> listAccounts(AccountQuery query) {
        int page = safePage(query.page());
        int size = safeSize(query.pageSize());
        List<Account> accounts = mapper.findAccounts(query, (page - 1) * size, size);
        enrichAccountSnapshots(accounts);
        var items = accounts.stream().map(this::accountView).toList();
        return new ChannelViews.Page<>(items, mapper.countAccounts(query), page, size);
    }

    /** 查询账户金额汇总。 */
    public ChannelViews.AccountStatistics summarizeAccounts(AccountQuery query) {
        Aggregate value = mapper.summarizeAccounts(query);
        return new ChannelViews.AccountStatistics(
                money(value == null ? null : value.getOpeningBalance()),
                money(value == null ? null : value.getByBalance()),
                money(value == null ? null : value.getByBalanceU()),
                money(value == null ? null : value.getConsumption()),
                money(value == null ? null : value.getBalance()),
                money(value == null ? null : value.getActualDeduction()),
                money(value == null ? null : value.getAmountSpent()),
                money(value == null ? null : value.getRemainingSpendCap()));
    }

    /** 查询渠道账户状态数量。 */
    public ChannelViews.AccountCounts countAccountStatuses(Long channelId) {
        requireChannel(channelId);
        Aggregate value = mapper.countAccountStatuses(channelId);
        return new ChannelViews.AccountCounts(
                longValue(value.getAllCount()),
                longValue(value.getActiveCount()),
                longValue(value.getClosedCount()),
                longValue(value.getUnusedCount()),
                longValue(value.getUsingCount()),
                longValue(value.getStopCount()),
                longValue(value.getRecycledCount()),
                longValue(value.getIdleCount()));
    }

    /** 修改账户使用状态。 */
    @Transactional
    public void updateAccountUsage(String accountId, Integer usageStatus) {
        if (usageStatus == null || usageStatus < 0 || usageStatus > 4) {
            throw new ChannelException("账户使用状态不合法");
        }
        requireAccount(accountId);
        mapper.updateAccountUsage(accountId, usageStatus, actorId());
    }

    /** 删除渠道账户。 */
    @Transactional
    public void deleteAccount(String accountId) {
        requireAccount(accountId);
        mapper.softDeleteAccount(accountId, System.currentTimeMillis(), actorId());
    }

    /** 批量分配账户给系统用户。 */
    @Transactional
    public void assignAccounts(ChannelRequests.AccountAssign request) {
        var pitcher = mapper.findPitcher(request.operatorId());
        if (pitcher == null) throw new ChannelException("投手不存在或已停用");
        int updated =
                mapper.assignAccounts(
                        request.accountIds(),
                        request.operatorId(),
                        pitcher.getNickName(),
                        actorId());
        if (updated != request.accountIds().size()) {
            throw new ChannelException("部分账户不存在，请刷新后重试");
        }
    }

    /** 批量新增渠道账户。 */
    @Transactional
    public void batchCreateAccounts(AccountBatch request) {
        requireChannel(request.channelId());
        var accountIds = new java.util.HashSet<String>();
        for (AccountImportItem item : request.accounts()) {
            String accountId = normalizeAccountId(item.accountId());
            if (accountId.isEmpty()) {
                throw new ChannelException("账户ID不能为空");
            }
            if (!accountIds.add(accountId)) {
                throw new ChannelException("账户列表中不允许有重复的账户ID：" + accountId);
            }
            if (mapper.findAccountTypeByName(item.accountType()) == null) {
                throw new ChannelException("账户类型不存在：" + item.accountType());
            }
            Account existing = mapper.findAccount(accountId);
            if (existing == null) {
                insertAccount(
                        request.channelId(),
                        new AccountImportItem(accountId, item.accountType()),
                        null);
            } else if (request.channelId().equals(existing.getChannelId())) {
                mapper.updateBatchAccount(existing.getId(), item.accountType(), actorId());
            } else {
                Channel existingChannel = mapper.findChannel(existing.getChannelId());
                if (existingChannel == null
                        || trimToNull(existingChannel.getChannelName()) == null) {
                    throw new ChannelException("账户[" + accountId + "]在其他渠道中已存在");
                }
                throw new ChannelException(
                        "账户[" + accountId + "]在其他渠道[" + existingChannel.getChannelName() + "]中已存在");
            }
        }
    }

    /** 导入账户工作簿，返回逐行校验错误。 */
    @Transactional
    public List<String> importAccounts(byte[] content) {
        List<ChannelExcelCodec.ImportRow> rows = excelCodec.read(content);
        List<String> errors = new ArrayList<>();
        var fileAccountIds = new java.util.HashSet<String>();
        for (ChannelExcelCodec.ImportRow row : rows) {
            String error = validateImportRow(row, fileAccountIds);
            if (error != null) errors.add("第" + row.rowNumber() + "行：" + error);
        }
        if (!errors.isEmpty()) return errors;
        rows.forEach(
                row ->
                        insertAccount(
                                Long.valueOf(row.channelId()),
                                new AccountImportItem(row.accountId(), row.accountType()),
                                row));
        return List.of();
    }

    private String validateImportRow(
            ChannelExcelCodec.ImportRow row, java.util.Set<String> fileAccountIds) {
        try {
            Long channelId = Long.valueOf(row.channelId());
            if (mapper.findChannel(channelId) == null) return "渠道不存在：" + row.channelId();
            if (row.accountId().isBlank()) return "账户ID不能为空";
            if (!fileAccountIds.add(row.accountId())) return "文件内账户ID重复：" + row.accountId();
            if (mapper.findAccount(row.accountId()) != null) return "账户ID已存在：" + row.accountId();
            if (mapper.findAccountTypeByName(row.accountType()) == null) {
                return "账户类型不存在：" + row.accountType();
            }
            if (row.status() < 1 || row.status() > 2) return "账户状态只能为1或2";
            if (row.usageStatus() < 0 || row.usageStatus() > 4) return "使用状态只能为0至4";
            return null;
        } catch (NumberFormatException exception) {
            return "渠道ID格式不正确";
        } catch (RuntimeException exception) {
            return exception.getMessage();
        }
    }

    /** 生成账户导入模板。 */
    public byte[] accountTemplate() {
        return excelCodec.template();
    }

    /** 导出查询到的全部账户。 */
    public byte[] exportAccounts(AccountQuery query) {
        AccountQuery exportQuery =
                new AccountQuery(
                        query.channelId(),
                        query.accountType(),
                        query.accountIds(),
                        query.bmId(),
                        query.subjectName(),
                        query.operatorName(),
                        query.belongTeamId(),
                        query.timezone(),
                        query.status(),
                        query.usageStatus(),
                        query.consumptionMin(),
                        query.consumptionMax(),
                        query.balanceMin(),
                        query.balanceMax(),
                        query.startDate(),
                        query.endDate(),
                        1,
                        1_000_000,
                        query.includeFields());
        return excelCodec.write(listAccounts(exportQuery).items());
    }

    /** 查询渠道上架信息。 */
    public ChannelViews.Goods getGoods(Long channelId) {
        requireChannel(channelId);
        Goods goods = mapper.findGoods(channelId);
        return goods == null ? null : goodsView(goods);
    }

    /** 保存渠道上架信息。 */
    @Transactional
    public ChannelViews.Goods saveGoods(Long channelId, GoodsSave request) {
        requireChannel(channelId);
        Goods goods = mapper.findGoods(channelId);
        boolean insert = goods == null;
        if (insert) {
            goods = new Goods();
            goods.setChannelId(channelId);
            goods.setPutawayStatus(0);
            goods.setCreatedBy(actorId());
        }
        goods.setGoodsName(request.goodsName());
        goods.setLaunchRegion(request.launchRegion());
        goods.setMinBuyLimit(request.minBuyLimit());
        goods.setRebateRate(request.rebateRate());
        goods.setRemark(request.remark());
        goods.setServiceFeeRatio(request.serviceFeeRatio());
        goods.setStockNum(request.stockNum());
        goods.setTimezone(request.timezone());
        goods.setUpdatedBy(actorId());
        if (insert) mapper.insertGoods(goods);
        else mapper.updateGoods(goods);
        return goodsView(Objects.requireNonNull(mapper.findGoods(channelId)));
    }

    /** 修改商品上下架状态。 */
    @Transactional
    public void setPutaway(Long channelId, Integer status) {
        if (status == null || status < 0 || status > 2) {
            throw new ChannelException("上下架状态不合法");
        }
        if (mapper.findGoods(channelId) == null) throw new ChannelException("请先维护上架信息");
        mapper.updateGoodsPutaway(channelId, status, actorId());
        mapper.updateChannelPutaway(channelId, status, actorId());
    }

    /** 分页查询账户广告系列花费。 */
    public ChannelViews.Page<ChannelViews.CampaignSpend> listCampaigns(
            String accountId,
            String campaignName,
            LocalDate startDate,
            LocalDate endDate,
            int page,
            int pageSize) {
        requireAccount(accountId);
        int safePage = safePage(page);
        int safeSize = safeSize(pageSize);
        var items =
                mapper
                        .findCampaigns(
                                accountId,
                                trimToNull(campaignName),
                                startDate,
                                endDate,
                                (safePage - 1) * safeSize,
                                safeSize)
                        .stream()
                        .map(
                                item ->
                                        new ChannelViews.CampaignSpend(
                                                item.getCampaignId(),
                                                item.getCampaignName(),
                                                money(item.getSpendAmount()),
                                                money(item.getReturnAmount())))
                        .toList();
        return new ChannelViews.Page<>(
                items,
                mapper.countCampaigns(accountId, trimToNull(campaignName), startDate, endDate),
                safePage,
                safeSize);
    }

    /** 查询可分配投手。 */
    public ChannelViews.Page<ChannelViews.Pitcher> listPitchers(
            String keyword, int page, int pageSize) {
        int safePage = safePage(page);
        int safeSize = safeSize(pageSize);
        var items =
                mapper
                        .findPitchers(trimToNull(keyword), (safePage - 1) * safeSize, safeSize)
                        .stream()
                        .map(
                                item ->
                                        new ChannelViews.Pitcher(
                                                stringId(item.getUserId()),
                                                item.getUserName(),
                                                item.getNickName()))
                        .toList();
        return new ChannelViews.Page<>(
                items, mapper.countPitchers(trimToNull(keyword)), safePage, safeSize);
    }

    /** 查询系统部门树。 */
    public List<ChannelViews.Department> departmentTree() {
        List<Department> departments = mapper.findDepartments();
        Map<Long, List<Department>> grouped = new HashMap<>();
        departments.forEach(
                item ->
                        grouped.computeIfAbsent(item.getParentId(), ignored -> new ArrayList<>())
                                .add(item));
        return buildDepartments(0L, grouped);
    }

    private List<ChannelViews.Department> buildDepartments(
            Long parentId, Map<Long, List<Department>> grouped) {
        return grouped.getOrDefault(parentId, List.of()).stream()
                .map(
                        item ->
                                new ChannelViews.Department(
                                        stringId(item.getId()),
                                        item.getLabel(),
                                        item.getStatus() == null || item.getStatus() != 1,
                                        buildDepartments(item.getId(), grouped)))
                .toList();
    }

    private void insertAccount(
            Long channelId, AccountImportItem item, ChannelExcelCodec.ImportRow importRow) {
        requireChannel(channelId);
        if (mapper.findAccountTypeByName(item.accountType()) == null) {
            throw new ChannelException("账户类型不存在：" + item.accountType());
        }
        Account account = new Account();
        account.setChannelId(channelId);
        account.setAccountId(normalizeAccountId(item.accountId()));
        account.setFbAccountId(account.getAccountId());
        account.setAccountType(item.accountType());
        account.setAccountName(importRow == null ? null : importRow.accountName());
        account.setSubjectName(importRow == null ? null : importRow.subjectName());
        account.setTimezone(importRow == null ? 0 : importRow.timezone());
        account.setStatus(importRow == null ? 1 : importRow.status());
        account.setUsageStatus(importRow == null ? 0 : importRow.usageStatus());
        account.setBalance(importRow == null ? ZERO : importRow.balance());
        account.setConsumption(importRow == null ? ZERO : importRow.consumption());
        account.setOpeningBalance(ZERO);
        account.setByBalance(ZERO);
        account.setByBalanceU(ZERO);
        account.setActualDeduction(ZERO);
        account.setAmountSpent(account.getConsumption());
        account.setRemainingSpendCap(ZERO);
        account.setRemark(importRow == null ? null : importRow.remark());
        account.setCreatedBy(actorId());
        account.setUpdatedBy(actorId());
        try {
            mapper.insertAccount(account);
        } catch (DuplicateKeyException exception) {
            throw new ChannelException("账户ID已存在：" + account.getAccountId());
        }
    }

    private String normalizeAccountId(String accountId) {
        return accountId.trim().replaceFirst("^act_", "");
    }

    private Channel requireChannel(Long id) {
        Channel channel = mapper.findChannel(id);
        if (channel == null) throw new ChannelException("渠道不存在");
        return channel;
    }

    private Account requireAccount(String id) {
        Account account = mapper.findAccount(id);
        if (account == null) throw new ChannelException("渠道账户不存在");
        return account;
    }

    private void validateRequiredChannel(ChannelSave value) {
        if (trimToNull(value.channelName()) == null
                || trimToNull(value.channelCode()) == null
                || value.channelType() == null
                || trimToNull(value.belongTeam()) == null
                || value.status() == null
                || trimToNull(value.settlementMethod()) == null
                || trimToNull(value.settlementCurrency()) == null
                || trimToNull(value.paymentAddress()) == null
                || trimToNull(value.loginUrl()) == null) {
            throw new ChannelException("渠道必填信息不完整");
        }
    }

    private void mergeChannel(Channel model, ChannelSave value) {
        if (value.channelName() != null) model.setChannelName(value.channelName().trim());
        if (value.channelShortName() != null)
            model.setChannelShortName(value.channelShortName().trim());
        if (value.channelCode() != null) model.setChannelCode(value.channelCode().trim());
        if (value.channelType() != null) model.setChannelType(value.channelType());
        if (value.belongTeam() != null) model.setBelongTeam(value.belongTeam());
        if (value.status() != null) model.setStatus(value.status());
        if (value.settlementMethod() != null) model.setSettlementMethod(value.settlementMethod());
        if (value.settlementCurrency() != null)
            model.setSettlementCurrency(value.settlementCurrency());
        if (value.buyoutAmount() != null) model.setBuyoutAmount(value.buyoutAmount());
        if (value.rechargeAmount() != null) model.setRechargeAmount(value.rechargeAmount());
        if (value.paymentAddress() != null) model.setPaymentAddress(value.paymentAddress());
        if (value.loginUrl() != null) model.setLoginUrl(value.loginUrl());
        if (value.remark() != null) model.setRemark(value.remark());
        if (value.tgGroupId() != null) model.setTgGroupId(value.tgGroupId());
        if (value.tgGroupName() != null) model.setTgGroupName(value.tgGroupName());
    }

    private void validateRate(Long channelId, Long excludedId, RateSave request) {
        if (request.expiryDate() != null
                && request.expiryDate().isBefore(request.effectiveDate())) {
            throw new ChannelException("失效日期不能早于生效日期");
        }
        if (mapper.countRateOverlaps(
                        channelId, excludedId, request.effectiveDate(), request.expiryDate())
                > 0) {
            throw new ChannelException("费率生效区间与已有记录重叠");
        }
    }

    private void applyRate(Rate rate, RateSave request) {
        rate.setServiceFee(request.serviceFee());
        rate.setRebateRate(request.rebateRate());
        rate.setEffectiveDate(request.effectiveDate());
        rate.setExpiryDate(request.expiryDate());
        LocalDate today = LocalDate.now();
        rate.setStatus(
                !today.isBefore(request.effectiveDate())
                                && (request.expiryDate() == null
                                        || !today.isAfter(request.expiryDate()))
                        ? 1
                        : 0);
    }

    private ChannelViews.ChannelDetail channelView(Channel item) {
        return new ChannelViews.ChannelDetail(
                stringId(item.getId()),
                item.getChannelName(),
                item.getChannelShortName(),
                item.getChannelCode(),
                item.getChannelType(),
                item.getBelongTeam(),
                item.getStatus(),
                item.getPutawayStatus(),
                item.getSettlementMethod(),
                item.getSettlementCurrency(),
                money(item.getBuyoutAmount()),
                money(item.getRechargeAmount()),
                item.getPaymentAddress(),
                item.getLoginUrl(),
                item.getRemark(),
                item.getTgGroupId(),
                item.getTgGroupName(),
                money(item.getServiceFee()),
                money(item.getRebateRate()),
                money(item.getTotalConsumption()),
                money(item.getTotalBalance()),
                money(item.getActivationFee()),
                money(item.getTotalByBalance()),
                money(item.getTotalByBalanceU()),
                item.getUsageStatus(),
                item.getCreatedAt(),
                item.getUpdatedAt());
    }

    private ChannelViews.Rate rateView(Rate item) {
        return new ChannelViews.Rate(
                stringId(item.getId()),
                stringId(item.getChannelId()),
                item.getServiceFee(),
                item.getRebateRate(),
                item.getEffectiveDate(),
                item.getExpiryDate(),
                item.getStatus(),
                item.getCreatedAt(),
                item.getUpdatedAt());
    }

    private ChannelViews.AccountType accountTypeView(AccountType item) {
        return new ChannelViews.AccountType(
                stringId(item.getId()),
                item.getAccountType(),
                item.getAccountTypeCode(),
                item.getCreatedAt());
    }

    private ChannelViews.Account accountView(Account item) {
        return new ChannelViews.Account(
                item.getAccountId(),
                item.getAccountName(),
                item.getAccountType(),
                item.getFbAccountId(),
                item.getTakeTime(),
                item.getTimezone(),
                item.getBmId(),
                item.getBmFromFeishu(),
                money(item.getOpeningBalance()),
                money(item.getByBalance()),
                money(item.getByBalanceU()),
                money(item.getConsumption()),
                money(item.getBalance()),
                money(item.getActualDeduction()),
                money(item.getAmountSpent()),
                money(item.getRemainingSpendCap()),
                item.getStatus(),
                item.getUsageStatus(),
                item.getSubjectName(),
                stringId(item.getOperatorId()),
                item.getOperatorName(),
                item.getBelongTeam(),
                stringId(item.getBelongTeamId()),
                item.getOpenDate(),
                item.getCreatedAt(),
                item.getAssignTime(),
                item.getRemark());
    }

    private void enrichAccountSnapshots(List<Account> accounts) {
        Map<String, AccountSnapshotProvider.AccountSnapshot> snapshots =
                accountSnapshotProvider.findByAccountIds(
                        accounts.stream().map(Account::getAccountId).toList());
        for (Account account : accounts) {
            AccountSnapshotProvider.AccountSnapshot snapshot =
                    snapshots.get(account.getAccountId());
            if (snapshot == null) continue;
            if (snapshot.accountName() != null) account.setAccountName(snapshot.accountName());
            if (snapshot.status() != null) account.setStatus(snapshot.status());
            if (snapshot.takeTime() != null) account.setTakeTime(snapshot.takeTime());
            if (snapshot.timezone() != null) account.setTimezone(snapshot.timezone());
            if (snapshot.bmId() != null) account.setBmId(snapshot.bmId());
            if (snapshot.balance() != null) account.setBalance(snapshot.balance());
            if (snapshot.amountSpent() != null) account.setAmountSpent(snapshot.amountSpent());
            if (snapshot.remainingSpendCap() != null) {
                account.setRemainingSpendCap(snapshot.remainingSpendCap());
            }
            if (snapshot.subjectName() != null) account.setSubjectName(snapshot.subjectName());
        }
    }

    private ChannelViews.Goods goodsView(Goods item) {
        return new ChannelViews.Goods(
                stringId(item.getChannelId()),
                item.getGoodsName(),
                item.getLaunchRegion(),
                item.getMinBuyLimit(),
                item.getRebateRate(),
                item.getRemark(),
                item.getServiceFeeRatio(),
                item.getStockNum(),
                item.getTimezone(),
                item.getPutawayStatus());
    }

    private int safePage(Integer value) {
        return Math.max(1, value == null ? 1 : value);
    }

    private int safeSize(Integer value) {
        return Math.min(1_000_000, Math.max(1, value == null ? 20 : value));
    }

    private long longValue(Long value) {
        return value == null ? 0L : value;
    }

    private BigDecimal money(BigDecimal value) {
        return value == null ? ZERO : value;
    }

    private String stringId(Long value) {
        return value == null ? null : value.toString();
    }

    private String trimToNull(String value) {
        if (value == null || value.isBlank()) return null;
        return value.trim();
    }

    private Long actorId() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof CurrentUser currentUser) return currentUser.userId();
        throw new ChannelException("登录状态无效");
    }

    /** 可直接展示的渠道业务异常。 */
    public static class ChannelException extends RuntimeException {
        public ChannelException(String message) {
            super(message);
        }
    }
}
