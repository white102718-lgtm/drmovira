package com.adpulse.main.google.mapper;

import com.adpulse.main.google.model.GoogleModels.Account;
import com.adpulse.main.google.model.GoogleModels.Mapping;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/** Google账号与Sheets映射持久化接口。 */
@Mapper
public interface GoogleIntegrationMapper {
    /** 查询全部有效Google账号。 */
    List<Account> findAccounts();

    /** 按ID查询Google账号。 */
    Account findAccount(@Param("id") Long id);

    /** 按Google subject查询账号。 */
    Account findAccountBySubject(@Param("subject") String subject);

    /** 新增Google账号。 */
    int insertAccount(Account account);

    /** 更新Google账号及加密令牌。 */
    int updateAccount(Account account);

    /** 更新账号授权状态。 */
    int updateAccountStatus(
            @Param("id") Long id, @Param("status") Integer status, @Param("actorId") Long actorId);

    /** 软删除Google账号。 */
    int deleteAccount(
            @Param("id") Long id,
            @Param("deletedAt") long deletedAt,
            @Param("actorId") Long actorId);

    /** 查询账号映射。 */
    List<Mapping> findMappingsByAccount(@Param("accountId") Long accountId);

    /** 按ID查询映射。 */
    Mapping findMapping(@Param("id") Long id);

    /** 新增映射。 */
    int insertMapping(Mapping mapping);

    /** 更新映射。 */
    int updateMapping(Mapping mapping);

    /** 更新映射状态。 */
    int updateMappingStatus(
            @Param("id") Long id,
            @Param("enableFlag") Integer enableFlag,
            @Param("actorId") Long actorId);

    /** 软删除映射。 */
    int deleteMapping(
            @Param("id") Long id,
            @Param("deletedAt") long deletedAt,
            @Param("actorId") Long actorId);

    /** 软删除账号全部映射。 */
    int deleteMappingsByAccount(
            @Param("accountId") Long accountId,
            @Param("deletedAt") long deletedAt,
            @Param("actorId") Long actorId);

    /** 写入Google映射同步队列。 */
    int insertSyncJob(
            @Param("businessId") String businessId, @Param("requestedBy") Long requestedBy);
}
