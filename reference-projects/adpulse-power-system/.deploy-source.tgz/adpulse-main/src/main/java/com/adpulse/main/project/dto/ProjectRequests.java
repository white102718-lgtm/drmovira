package com.adpulse.main.project.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.math.BigDecimal;
import java.util.List;

/** 项目管理写入请求。 */
public final class ProjectRequests {
    private ProjectRequests() {}

    /** 项目保存请求。 */
    public record ProjectSave(
            @NotBlank @Size(max = 50) String projectCode,
            @NotBlank @Size(max = 100) String name,
            @NotBlank @Size(max = 100) String responsibleTeam,
            String amUserId,
            @Size(max = 100) String amName,
            String deliveryLeaderId,
            @Size(max = 100) String deliveryLeaderName,
            @NotNull Boolean isOutsourced,
            @NotBlank String priority,
            @NotEmpty List<@NotBlank String> platforms,
            @NotEmpty List<@NotBlank String> countryRegions,
            @NotNull @DecimalMin("0") @DecimalMax("100") BigDecimal serviceFeePercent,
            @NotBlank String status,
            @NotBlank @Size(max = 500) String productInfo,
            @Size(max = 1000) String customerDailyReportUrl,
            @NotEmpty List<@Valid KpiSave> kpiRequirements) {}

    /** KPI保存请求。 */
    public record KpiSave(
            @NotBlank @Size(max = 100) String metric,
            @NotBlank String comparator,
            @NotNull @DecimalMin("0") BigDecimal target) {}

    /** 全量代理线绑定请求。 */
    public record AgencyLineReplace(@NotNull List<String> agencyLineIds) {}

    /** 增量代理线绑定请求。 */
    public record AgencyLinePatch(
            List<String> add, List<String> remove, @Size(max = 200) String requestId) {}

    /** 代理线保存请求，兼容前端的agencyLine包装。 */
    public record AgencyLineCreate(@NotNull @Valid AgencyLineSave agencyLine, String projectId) {}

    /** 代理线字段。 */
    public record AgencyLineSave(
            String id,
            String projectId,
            @NotBlank @Size(max = 80) String name,
            @NotBlank @Size(max = 100) String platform,
            @Size(max = 1000) String deliveryUrl,
            @NotBlank @Size(max = 255) String pixelName,
            @NotBlank String optimizerId,
            @NotBlank @Size(max = 100) String optimizerName) {}
}
