package com.adpulse.main.channel.mongo;

import com.adpulse.main.channel.service.AccountSnapshotProvider;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

/** 使用 MongoDB 的 fb_ad_account 集合补充账户列表展示字段。 */
@Component
public class MongoAccountSnapshotProvider implements AccountSnapshotProvider {
    private static final int QUERY_BATCH_SIZE = 500;
    private static final Logger LOGGER =
            LoggerFactory.getLogger(MongoAccountSnapshotProvider.class);

    private final MongoTemplate mongoTemplate;
    private final boolean enabled;
    private final String collection;

    public MongoAccountSnapshotProvider(
            MongoTemplate mongoTemplate,
            @Value("${adpulse.mongo.account.enabled:false}") boolean enabled,
            @Value("${adpulse.mongo.account.collection:fb_ad_account}") String collection) {
        this.mongoTemplate = mongoTemplate;
        this.enabled = enabled;
        this.collection = collection;
    }

    /** 批量查询当前页账户，MongoDB 异常时降级为不补充字段。 */
    @Override
    public Map<String, AccountSnapshot> findByAccountIds(List<String> accountIds) {
        if (!enabled || accountIds.isEmpty()) return Map.of();
        List<String> distinctAccountIds = accountIds.stream().distinct().toList();
        Map<String, AccountSnapshot> result = new LinkedHashMap<>();
        try {
            for (int start = 0; start < distinctAccountIds.size(); start += QUERY_BATCH_SIZE) {
                int end = Math.min(start + QUERY_BATCH_SIZE, distinctAccountIds.size());
                findBatch(distinctAccountIds.subList(start, end), result);
            }
            return result;
        } catch (RuntimeException exception) {
            LOGGER.warn("MongoDB账户信息查询失败，本次列表使用MySQL字段: {}", exception.getMessage());
            return Map.of();
        }
    }

    private void findBatch(List<String> accountIds, Map<String, AccountSnapshot> result) {
        Query query =
                new Query(
                        new Criteria()
                                .orOperator(
                                        Criteria.where("account_id").in(accountIds),
                                        Criteria.where("accountId").in(accountIds),
                                        Criteria.where("_id").in(accountIds)));
        query.fields()
                .include("account_id")
                .include("accountId")
                .include("account_name")
                .include("accountName")
                .include("account_status")
                .include("accountStatus")
                .include("take_time")
                .include("takeTime")
                .include("timezone_offset_hours_utc")
                .include("timezoneOffsetHoursUtc")
                .include("bm_id")
                .include("bmId")
                .include("balance")
                .include("amount_spent")
                .include("amountSpent")
                .include("remaining_spend_cap")
                .include("remainingSpendCap")
                .include("business_name")
                .include("businessName");
        for (Document document : mongoTemplate.find(query, Document.class, collection)) {
            AccountSnapshot snapshot = toSnapshot(document);
            if (snapshot.accountId() != null) result.put(snapshot.accountId(), snapshot);
        }
    }

    private AccountSnapshot toSnapshot(Document value) {
        return new AccountSnapshot(
                text(value, "account_id", "accountId", "_id"),
                text(value, "account_name", "accountName"),
                integer(value, "account_status", "accountStatus"),
                dateTime(value, "take_time", "takeTime", "update_time", "updatedAt"),
                timezone(value),
                text(value, "bm_id", "bmId"),
                decimal(value, "balance"),
                decimal(value, "amount_spent", "amountSpent"),
                decimal(value, "remaining_spend_cap", "remainingSpendCap"),
                text(value, "business_name", "businessName"));
    }

    private Object first(Document value, String... names) {
        for (String name : names) {
            Object found = value.get(name);
            if (found != null) return found;
        }
        return null;
    }

    private String text(Document value, String... names) {
        Object found = first(value, names);
        return found == null ? null : found.toString();
    }

    private Integer integer(Document value, String... names) {
        Object found = first(value, names);
        if (found instanceof Number number) return number.intValue();
        try {
            return found == null ? null : Integer.valueOf(found.toString());
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    private BigDecimal decimal(Document value, String... names) {
        Object found = first(value, names);
        try {
            return found == null ? null : new BigDecimal(found.toString());
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    private LocalDateTime dateTime(Document value, String... names) {
        Object found = first(value, names);
        if (found instanceof Date date) {
            return LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
        }
        if (found instanceof Instant instant) {
            return LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
        }
        return null;
    }

    private Integer timezone(Document value) {
        String timezone =
                text(value, "timezone", "timezone_offset_hours_utc", "timezoneOffsetHoursUtc");
        if (timezone == null) return null;
        try {
            return Integer.valueOf(timezone.replace("UTC", "").replace("+", "").trim());
        } catch (NumberFormatException ignored) {
            return null;
        }
    }
}
