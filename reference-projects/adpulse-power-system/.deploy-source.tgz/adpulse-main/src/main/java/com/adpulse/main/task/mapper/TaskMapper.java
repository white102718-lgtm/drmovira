package com.adpulse.main.task.mapper;

import com.adpulse.main.task.dto.TaskViews;
import com.adpulse.main.task.model.TaskModels;
import java.time.LocalDateTime;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/** 任务、专业详情、交付和文件绑定持久化接口。 */
@Mapper
public interface TaskMapper {
    TaskModels.Draft findDraft(@Param("id") Long id);

    TaskModels.Draft findDraftForUpdate(@Param("id") Long id);

    List<TaskModels.Draft> findDrafts(@Param("creatorId") Long creatorId);

    void insertDraft(TaskModels.Draft draft);

    int updateDraft(TaskModels.Draft draft);

    int deleteDraft(
            @Param("id") Long id,
            @Param("creatorId") Long creatorId,
            @Param("deletedAt") long deletedAt);

    void insertActivity(TaskModels.Activity activity);

    List<TaskModels.Activity> findActivities(
            @Param("userId") Long userId, @Param("limit") int limit);

    TaskModels.Task findTask(@Param("id") Long id);

    TaskModels.Task findTaskForUpdate(@Param("id") Long id);

    List<TaskModels.Task> findTasks(
            @Param("userId") Long userId,
            @Param("scope") String scope,
            @Param("taskType") String taskType,
            @Param("status") String status,
            @Param("keyword") String keyword,
            @Param("offset") int offset,
            @Param("limit") int limit);

    long countTasks(
            @Param("userId") Long userId,
            @Param("scope") String scope,
            @Param("taskType") String taskType,
            @Param("status") String status,
            @Param("keyword") String keyword);

    long countFollowedTasks(@Param("userId") Long userId);

    long countAssignedTasks(@Param("userId") Long userId);

    long countActivities(@Param("userId") Long userId);

    long countDrafts(@Param("creatorId") Long creatorId);

    List<Long> findFollowedTaskIds(@Param("userId") Long userId);

    int countTaskFollow(@Param("taskId") Long taskId, @Param("userId") Long userId);

    void insertTaskFollow(@Param("taskId") Long taskId, @Param("userId") Long userId);

    int deleteTaskFollow(
            @Param("taskId") Long taskId,
            @Param("userId") Long userId,
            @Param("deletedAt") long deletedAt);

    String findProjectName(@Param("id") Long id);

    String findActiveUserName(@Param("id") Long id);

    int countOwnedFiles(@Param("ids") List<Long> ids, @Param("uploaderId") Long uploaderId);

    void insertTask(TaskModels.Task task);

    void insertDeliveryDetail(TaskModels.DeliveryDetail detail);

    void insertDeliveryPlatform(
            @Param("taskId") Long taskId,
            @Param("platform") String platform,
            @Param("sortOrder") int sortOrder);

    void insertAllocation(TaskModels.Allocation allocation);

    void insertMaterialDetail(TaskModels.MaterialDetail detail);

    void insertMaterialRequirement(TaskModels.MaterialRequirement requirement);

    void insertMaterialSize(
            @Param("taskId") Long taskId,
            @Param("size") String size,
            @Param("sortOrder") int sortOrder);

    void insertReferenceLink(
            @Param("taskId") Long taskId,
            @Param("name") String name,
            @Param("url") String url,
            @Param("sortOrder") int sortOrder);

    void insertFileBinding(
            @Param("taskId") Long taskId,
            @Param("fileId") Long fileId,
            @Param("targetType") String targetType,
            @Param("targetId") Long targetId,
            @Param("usageType") String usageType,
            @Param("sortOrder") int sortOrder,
            @Param("boundBy") Long boundBy);

    TaskModels.DeliveryDetail findDeliveryDetail(@Param("taskId") Long taskId);

    List<String> findDeliveryPlatforms(@Param("taskId") Long taskId);

    List<TaskModels.Allocation> findAllocations(@Param("taskId") Long taskId);

    TaskModels.MaterialDetail findMaterialDetail(@Param("taskId") Long taskId);

    List<TaskModels.MaterialRequirement> findMaterialRequirements(@Param("taskId") Long taskId);

    int countEnabledDictionaryValues(
            @Param("dictCode") String dictCode, @Param("values") List<String> values);

    TaskModels.DepartmentSnapshot findUserDepartment(@Param("userId") Long userId);

    List<String> findMaterialSizes(@Param("taskId") Long taskId);

    List<TaskViews.ReferenceLink> findReferenceLinks(@Param("taskId") Long taskId);

    List<TaskViews.FileView> findTaskFiles(@Param("taskId") Long taskId);

    List<TaskModels.DeliverySubmission> findDeliverySubmissions(@Param("taskId") Long taskId);

    List<TaskViews.DeliveryObject> findDeliveryObjects(@Param("submissionId") Long submissionId);

    List<TaskModels.MaterialSubmission> findMaterialSubmissions(@Param("taskId") Long taskId);

    TaskModels.DeliverySubmission findDeliverySubmissionByRequestId(
            @Param("requestId") String requestId);

    TaskModels.MaterialSubmission findMaterialSubmissionByRequestId(
            @Param("requestId") String requestId);

    int nextDeliveryVersion(@Param("taskId") Long taskId);

    int nextMaterialVersion(@Param("taskId") Long taskId);

    void insertDeliverySubmission(TaskModels.DeliverySubmission submission);

    void insertDeliveryObject(
            @Param("submissionId") Long submissionId,
            @Param("objectType") String objectType,
            @Param("objectId") String objectId,
            @Param("objectName") String objectName,
            @Param("sortOrder") int sortOrder);

    void insertMaterialSubmission(TaskModels.MaterialSubmission submission);

    int confirmTask(
            @Param("id") Long id,
            @Param("ownerId") Long ownerId,
            @Param("version") int version,
            @Param("now") LocalDateTime now);

    int assignTask(
            @Param("id") Long id,
            @Param("creatorId") Long creatorId,
            @Param("ownerId") Long ownerId,
            @Param("ownerName") String ownerName,
            @Param("assignerId") Long assignerId,
            @Param("assignerName") String assignerName,
            @Param("assignedAt") LocalDateTime assignedAt,
            @Param("version") int version);

    int markPendingAcceptance(
            @Param("id") Long id, @Param("ownerId") Long ownerId, @Param("version") int version);

    int acceptTask(
            @Param("id") Long id,
            @Param("creatorId") Long creatorId,
            @Param("version") int version,
            @Param("now") LocalDateTime now);

    int rejectTask(
            @Param("id") Long id,
            @Param("creatorId") Long creatorId,
            @Param("version") int version);

    int withdrawTask(
            @Param("id") Long id,
            @Param("creatorId") Long creatorId,
            @Param("version") int version,
            @Param("reason") String reason,
            @Param("now") LocalDateTime now);

    int reviewDeliverySubmission(
            @Param("id") Long id,
            @Param("taskId") Long taskId,
            @Param("result") String result,
            @Param("reviewerId") Long reviewerId,
            @Param("reviewerName") String reviewerName,
            @Param("comment") String comment,
            @Param("now") LocalDateTime now);

    int reviewMaterialSubmission(
            @Param("id") Long id,
            @Param("taskId") Long taskId,
            @Param("result") String result,
            @Param("reviewerId") Long reviewerId,
            @Param("reviewerName") String reviewerName,
            @Param("comment") String comment,
            @Param("libraryStatus") String libraryStatus,
            @Param("now") LocalDateTime now);
}
