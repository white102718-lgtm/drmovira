package com.adpulse.main.project.model;

import java.time.LocalDateTime;
import lombok.Data;

/** 代理线持久化模型。 */
@Data
public class AgencyLine {
    private Long id;
    private Long projectId;
    private String requestId;
    private String lineName;
    private String platformValue;
    private String deliveryUrl;
    private String pixelName;
    private Long optimizerId;
    private String optimizerName;
    private Long createdBy;
    private Long updatedBy;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
