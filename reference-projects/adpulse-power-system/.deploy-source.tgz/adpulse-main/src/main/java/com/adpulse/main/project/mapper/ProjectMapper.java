package com.adpulse.main.project.mapper;

import com.adpulse.main.project.dto.ProjectViews.Kpi;
import com.adpulse.main.project.model.AgencyLine;
import com.adpulse.main.project.model.Project;
import com.adpulse.main.project.model.ProjectOptionRow;
import com.adpulse.main.project.model.ProjectStatisticsRow;
import java.math.BigDecimal;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/** 项目与代理线持久化接口。 */
@Mapper
public interface ProjectMapper {
    ProjectStatisticsRow countProjectStatuses();

    List<ProjectOptionRow> findProjectOptionRows();

    List<Project> findProjects(
            @Param("keyword") String keyword,
            @Param("status") String status,
            @Param("platform") String platform,
            @Param("offset") int offset,
            @Param("pageSize") int pageSize);

    long countProjects(
            @Param("keyword") String keyword,
            @Param("status") String status,
            @Param("platform") String platform);

    Project findProject(@Param("id") Long id);

    int insertProject(Project project);

    int updateProject(Project project);

    int countActiveUser(@Param("id") Long id);

    int countEnabledDictionaryValue(
            @Param("dictCode") String dictCode, @Param("value") String value);

    void softDeletePlatforms(
            @Param("projectId") Long projectId, @Param("deletedAt") long deletedAt);

    void softDeleteRegions(@Param("projectId") Long projectId, @Param("deletedAt") long deletedAt);

    void softDeleteKpis(
            @Param("projectId") Long projectId,
            @Param("deletedAt") long deletedAt,
            @Param("updatedBy") Long updatedBy);

    void insertPlatform(
            @Param("projectId") Long projectId,
            @Param("value") String value,
            @Param("createdBy") Long createdBy);

    void insertRegion(
            @Param("projectId") Long projectId,
            @Param("value") String value,
            @Param("createdBy") Long createdBy);

    void insertKpi(
            @Param("projectId") Long projectId,
            @Param("metric") String metric,
            @Param("comparator") String comparator,
            @Param("target") BigDecimal target,
            @Param("sortOrder") int sortOrder,
            @Param("operatorId") Long operatorId);

    List<String> findPlatforms(@Param("projectId") Long projectId);

    List<String> findRegions(@Param("projectId") Long projectId);

    List<Kpi> findKpis(@Param("projectId") Long projectId);

    List<AgencyLine> findAgencyLines(
            @Param("keyword") String keyword,
            @Param("platform") String platform,
            @Param("projectId") Long projectId,
            @Param("offset") int offset,
            @Param("pageSize") int pageSize);

    long countAgencyLines(
            @Param("keyword") String keyword,
            @Param("platform") String platform,
            @Param("projectId") Long projectId);

    AgencyLine findAgencyLine(@Param("id") Long id);

    AgencyLine findAgencyLineByRequestId(@Param("requestId") String requestId);

    int insertAgencyLine(AgencyLine line);

    int updateAgencyLine(AgencyLine line);

    int bindAgencyLine(
            @Param("id") Long id,
            @Param("projectId") Long projectId,
            @Param("updatedBy") Long updatedBy);

    int unbindAgencyLine(
            @Param("id") Long id,
            @Param("projectId") Long projectId,
            @Param("updatedBy") Long updatedBy);

    int softDeleteAgencyLine(
            @Param("id") Long id,
            @Param("deletedAt") long deletedAt,
            @Param("updatedBy") Long updatedBy);
}
